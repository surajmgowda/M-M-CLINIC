
/* ============================= STATE ============================= */
let state = {
  loading: true,
  loadError: null, // set when the initial fetch of clinic data fails
  saveError: null,
  data: null,
  session: { staffName: null },
  route: 'dashboard',
  routeParams: {},
  search: '',
  loginError: '',
  loginMode: 'login', // 'login' | 'addFromLogin'
  draftVisit: null,
  apptDate: null, // selected day on the Appointments screen, defaults to today
  draftAppt: null,
  apptPatientSearch: '',
  apptError: '',
  auditSearch: '',
  dashboardMineOnly: false, // "My patients today" toggle, doctor dashboard
  billingUnpaidOnly: false,
  loginSelectedName: '',
  ui: { editingPatient: false, resetConfirmText: '', editingStaffName: null },
  regDupeAcknowledged: false, // set once staff confirms a phone-match warning isn't the same person
  mergeUI: null // { aId, bId, searchA, searchB, choices } — active on the Merge patients screen
};

function defaultData(){
  return {
    clinicInfo: { name: 'Male Madeshwara Clinic', shortName: 'MMC', address: '', phone: '', logo: '' },
    nextPatientSeq: 1,
    nextCertSeq: 1,
    nextTokenSeq: 1,
    tokenDate: '', // resets token counter each calendar day
    patients: [],
    staff: [],
    customMedicines: [], // clinic-added medicines: {name, dosages:[...]}
    appointments: [], // booked slots: {id, patientId|null, name, phone, date, time, doctorName, notes, status}
    auditLog: [], // who changed what and when: {ts, staff, action, details}
    rxTemplates: [] // reusable prescriptions: {id, name, prescriptions:[...], investigations:[...], createdAt}
  };
}

function esc(str){
  if(str===undefined||str===null) return '';
  return String(str)
    .replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')
    .replaceAll('"','&quot;').replaceAll("'",'&#39;');
}

function clinicLogoHTML(ci){
  if(ci && ci.logo){
    return `<img class="letterhead-logo" src="${esc(ci.logo)}" alt="">`;
  }
  return `<div class="letterhead-mark">MMC</div>`;
}
function letterheadHTML(ci, extraHtml){
  ci = ci || (state.data && state.data.clinicInfo) || {};
  return `<div class="letterhead">
    <div class="letterhead-row">
      ${clinicLogoHTML(ci)}
      <div class="letterhead-text">
        <div class="clinic-name">${esc(ci.name||'Male Madeshwara Clinic')}</div>
        <div class="clinic-meta">${esc(ci.address||'')}${ci.address&&ci.phone?' · ':''}${esc(ci.phone||'')}</div>
        ${extraHtml||''}
      </div>
    </div>
  </div>`;
}
function patientSafetyStripHTML(p){
  if(!p) return '';
  const parts = [];
  if(p.allergies) parts.push(`⚠ Allergies: ${esc(p.allergies)}`);
  if(p.chronicIllness) parts.push(`Chronic illness: ${esc(p.chronicIllness)}`);
  if(!parts.length) return '';
  const cls = p.allergies ? '' : ' has-chronic-only';
  return `<div class="patient-safety${cls}">${parts.join(' · ')}</div>`;
}
function patientSafetyBannerHTML(p){
  if(!p) return '';
  const parts = [];
  if(p.allergies) parts.push(`<strong>⚠ Known allergies:</strong> ${esc(p.allergies)}`);
  if(p.chronicIllness) parts.push(`<strong>Chronic illness:</strong> ${esc(p.chronicIllness)}`);
  if(!parts.length) return '';
  const danger = !!p.allergies;
  return `<div class="banner" style="background:${danger?'var(--danger-tint)':'var(--primary-tint)'};color:${danger?'var(--danger)':'var(--primary-dark)'};">${parts.join('<br>')}</div>`;
}
function certPatientFacts(p){
  return (p.allergies?`<p><strong>Known allergies:</strong> ${esc(p.allergies)}</p>`:'')
    + (p.chronicIllness?`<p><strong>Known chronic illness:</strong> ${esc(p.chronicIllness)}</p>`:'');
}

/* ---- Allergy class matching + simple drug–drug flags (heuristic, not a formulary) ---- */
const ALLERGY_ALIASES = [
  {keys:['penicillin','penicillins','amoxicillin','ampicillin','augmentin','clavulan','cloxacillin','piperacillin','flucloxacillin'], label:'penicillin-class antibiotic'},
  {keys:['sulfa','sulpha','sulfonamide','sulfamethoxazole','cotrimoxazole','co-trimoxazole','septran','bactrim','septra'], label:'sulfa drug'},
  {keys:['nsaid','ibuprofen','diclofenac','aceclofenac','nimesulide','ketorolac','mefenamic','naproxen','aspirin','mefenamic acid'], label:'NSAID'},
  {keys:['aspirin','disprin','ecosprin','acetylsalicylic'], label:'aspirin'},
  {keys:['paracetamol','acetaminophen','dolo','crocin'], label:'paracetamol'},
  {keys:['azithromycin','macrolide','erythromycin','clarithromycin'], label:'macrolide antibiotic'},
  {keys:['quinolone','ciprofloxacin','ofloxacin','norfloxacin','levofloxacin'], label:'fluoroquinolone'},
  {keys:['cephalosporin','cefixime','cefpodoxime','ceftriaxone','cephalexin','cefalexin','cefotaxime'], label:'cephalosporin'},
  {keys:['metronidazole','flagyl','tinidazole','ornidazole'], label:'nitroimidazole'},
  {keys:['codeine','tramadol','opioid','morphine'], label:'opioid'},
  {keys:['iodine','contrast'], label:'iodine / contrast'},
  {keys:['phenytoin','dilantin'], label:'phenytoin'},
  {keys:['nsaid','nsaids'], label:'NSAID'}
];
const DRUG_CLASS_TOKENS = {
  nsaid: ['ibuprofen','diclofenac','aceclofenac','nimesulide','aspirin','ketorolac','mefenamic','naproxen','ecosprin','disprin'],
  anticoagulant: ['warfarin','acenocoumarol','heparin'],
  antiplatelet: ['aspirin','clopidogrel','ecosprin','disprin'],
  aceArb: ['telmisartan','losartan','enalapril','ramipril','olmesartan','losartan'],
  potassium: ['spironolactone','potassium'],
  statin: ['atorvastatin','rosuvastatin','simvastatin'],
  macrolide: ['azithromycin','erythromycin','clarithromycin'],
  tramadol: ['tramadol'],
  ssri: ['sertraline','fluoxetine','escitalopram']
};
const INTERACTION_RULES = [
  {a:'nsaid', b:'nsaid', msg:'Two NSAIDs together increase gastric-bleed and kidney risk.'},
  {a:'nsaid', b:'anticoagulant', msg:'NSAID + anticoagulant: high bleeding risk.'},
  {a:'nsaid', b:'antiplatelet', msg:'NSAID + antiplatelet (e.g. aspirin/clopidogrel): increased bleeding risk.'},
  {a:'aceArb', b:'potassium', msg:'ARB/ACE inhibitor + potassium-sparing agent: hyperkalaemia risk.'},
  {a:'statin', b:'macrolide', msg:'Macrolide may raise statin levels (myopathy risk).'},
  {a:'tramadol', b:'ssri', msg:'Tramadol + SSRI: serotonin syndrome risk.'}
];
function medClassHits(medicineName){
  const med = (medicineName||'').toLowerCase();
  const hits = [];
  Object.entries(DRUG_CLASS_TOKENS).forEach(([cls, tokens])=>{
    if(tokens.some(t=> med.includes(t))) hits.push(cls);
  });
  return hits;
}
function findDrugInteractions(prescriptions){
  const meds = (prescriptions||[]).filter(r=>r && r.medicine);
  const warnings = [];
  for(let i=0;i<meds.length;i++){
    const aHits = medClassHits(meds[i].medicine);
    for(let j=i+1;j<meds.length;j++){
      const bHits = medClassHits(meds[j].medicine);
      INTERACTION_RULES.forEach(rule=>{
        const match = (aHits.includes(rule.a) && bHits.includes(rule.b)) || (aHits.includes(rule.b) && bHits.includes(rule.a));
        if(match){
          warnings.push(`${meds[i].medicine} + ${meds[j].medicine}: ${rule.msg}`);
        }
      });
    }
  }
  return [...new Set(warnings)];
}

function todayStr(){ return new Date().toISOString().slice(0,10); }
function nowTimeStr(){
  const d = new Date();
  return d.toTimeString().slice(0,5);
}
function fmtDate(d){
  if(!d) return '';
  const dt = new Date(d+'T00:00:00');
  if(isNaN(dt)) return d;
  return dt.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'});
}
// Computes age as of today from a YYYY-MM-DD date of birth.
function ageFromDob(dob){
  if(!dob) return null;
  const b = new Date(dob+'T00:00:00');
  if(isNaN(b)) return null;
  const now = new Date();
  if(b > now) return null;
  let years = now.getFullYear() - b.getFullYear();
  let months = now.getMonth() - b.getMonth();
  let days = now.getDate() - b.getDate();
  if(days < 0){
    months--;
    // Borrow the number of days in the calendar month just before "now" —
    // correctly handles 28/29/30/31-day months instead of assuming 30.
    const prevMonthLastDay = new Date(now.getFullYear(), now.getMonth(), 0).getDate();
    days += prevMonthLastDay;
  }
  if(months < 0){ years--; months += 12; }
  const totalMonths = years*12 + months;
  const totalDays = Math.round((now - b) / (1000*60*60*24));
  const weeks = Math.floor(Math.max(days,0) / 7);
  const remDays = Math.max(days,0) % 7;
  let display;
  if(years >= 2) display = months ? `${years}y ${months}m` : `${years}y`;
  else if(years >= 1) display = months ? `${years}y ${months}m` : `${years}y`;
  else if(totalMonths >= 1) display = weeks ? `${totalMonths}m ${weeks}w` : `${totalMonths}m`;
  else if(totalDays >= 7) display = remDays ? `${weeks}w ${remDays}d` : `${weeks}w`;
  else display = `${Math.max(days,0)}d`;
  return {years, months, days, totalMonths, totalDays, weeks, remDays, display, full: formatAgeYMD(years, months, days)};
}
// OPD card age line — explicit rules from clinic:
// ≥1 year → years + months; <1 year → months + weeks; <1 month → weeks + days.
function opdAgeDisplay(p){
  if(p && p.dob){
    const a = ageFromDob(p.dob);
    if(a){
      if(a.years >= 1){
        return a.months ? `${a.years} year${a.years===1?'':'s'}, ${a.months} month${a.months===1?'':'s'}` : `${a.years} year${a.years===1?'':'s'}`;
      }
      if(a.totalMonths >= 1){
        const w = a.weeks;
        return w ? `${a.totalMonths} month${a.totalMonths===1?'':'s'}, ${w} week${w===1?'':'s'}` : `${a.totalMonths} month${a.totalMonths===1?'':'s'}`;
      }
      const w = Math.floor(a.totalDays / 7);
      const d = a.totalDays % 7;
      if(w >= 1) return d ? `${w} week${w===1?'':'s'}, ${d} day${d===1?'':'s'}` : `${w} week${w===1?'':'s'}`;
      return `${Math.max(a.totalDays,0)} day${a.totalDays===1?'':'s'}`;
    }
  }
  return (p && p.age) || '—';
}
// True when patient is under 16 years (pediatric OPD cohort).
function isPediatricPatient(p){
  if(!p) return false;
  if(p.dob){
    const a = ageFromDob(p.dob);
    if(a) return a.years < 16;
  }
  // Fallback: try to parse free-text age like "5y", "8 years", "10"
  const m = String(p.age||'').match(/(\d+)/);
  if(m) return parseInt(m[1],10) < 16;
  return false;
}
function pediatricPatients(){
  return (state.data.patients||[]).filter(isPediatricPatient)
    .sort((a,b)=> (b.registeredDate||'').localeCompare(a.registeredDate||''));
}
// "23 years, 6 months, and 16 days" — full-precision exact age, e.g. for a
// patient's profile where there's room, vs. the compact `display`/`full`
// pairing above which fits list rows and print sheets.
function formatAgeYMD(years, months, days){
  const parts = [];
  if(years > 0) parts.push(`${years} year${years===1?'':'s'}`);
  if(months > 0) parts.push(`${months} month${months===1?'':'s'}`);
  if(days > 0 || parts.length===0) parts.push(`${days} day${days===1?'':'s'}`);
  if(parts.length === 1) return parts[0];
  if(parts.length === 2) return parts.join(' and ');
  return parts.slice(0,-1).join(', ') + ', and ' + parts[parts.length-1];
}
function updateAgePreview(inputEl, previewId){
  const el = document.getElementById(previewId);
  if(!el) return;
  const a = ageFromDob(inputEl.value);
  el.textContent = a ? `Age: ${a.full}` : '';
}
// Patients registered with a DOB get an always-current age; older records
// that only have the legacy free-text age field fall back to that.
function displayAge(p){
  if(p && p.dob){ const a = ageFromDob(p.dob); if(a) return a.display; }
  return (p && p.age) || '';
}
// Formats chief complaints for the OPD card: each item gets a "C/O " prefix.
// "Fever × 3days, Cough" → "C/O Fever × 3days\nC/O Cough"
function formatComplaintsForOpd(raw){
  if(!raw || !String(raw).trim()) return '—';
  return String(raw).split(/[,;\n]+/).map(s=>s.trim()).filter(Boolean).map(s=>{
    // Avoid double-prefixing if doctor already typed C/O
    if(/^c\/?o\b/i.test(s)) return s.replace(/^c\/?o\.?\s*/i, 'C/O ');
    return 'C/O ' + s;
  }).join('\n');
}

// BMI classification:
// Adults (≥16y): Consensus / WHO-Asian cut-offs widely used in India
//   <18.5 Underweight · 18.5–22.9 Normal · 23–24.9 Overweight · ≥25 Obese
// Pediatrics (<16y): IAP-oriented age-band screening (confirm with growth chart)
function calcBMI(weightKg, heightCm, ageYears){
  const w = parseFloat(weightKg), h = parseFloat(heightCm);
  if(!w || !h || h <= 0) return null;
  const m = h / 100;
  const bmi = w / (m * m);
  const value = Math.round(bmi * 10) / 10;
  const age = (ageYears != null && ageYears !== '') ? parseFloat(ageYears) : null;
  const pediatric = age != null && !isNaN(age) && age < 16;

  let label, standard;
  if(pediatric){
    standard = 'Indian pediatric (IAP-oriented)';
    // Approximate age-banded screening thresholds for South Asian children
    let uw, ow, ob;
    if(age < 5){ uw = 14; ow = 17; ob = 19; }
    else if(age < 11){ uw = 14.5; ow = 18; ob = 21; }
    else { uw = 16; ow = 22; ob = 25; } // 11–15y approaches adult Asian cut-offs
    if(bmi < uw) label = 'Underweight';
    else if(bmi < ow) label = 'Normal';
    else if(bmi < ob) label = 'Overweight';
    else label = 'Obese';
  } else {
    standard = 'Indian adult (Asian cut-offs)';
    if(bmi < 18.5) label = 'Underweight';
    else if(bmi < 23) label = 'Normal';
    else if(bmi < 25) label = 'Overweight';
    else if(bmi < 30) label = 'Obese';
    else label = 'Obese (class II)';
  }
  return { value, label, standard, pediatric: !!pediatric };
}
function patientAgeYearsForBmi(p){
  if(!p) return null;
  if(p.dob){
    const a = ageFromDob(p.dob);
    if(a) return a.years + (a.months||0)/12;
  }
  const m = String(p.age||'').match(/(\d+)/);
  return m ? parseInt(m[1],10) : null;
}
function updateBmiPreview(){
  const w = document.getElementById('v-weight');
  const h = document.getElementById('v-height');
  const el = document.getElementById('v-bmi-preview');
  if(!el) return;
  let ageY = null;
  if(state.draftVisit && state.draftVisit.patientId){
    const p = state.data.patients.find(x=>x.id===state.draftVisit.patientId);
    ageY = patientAgeYearsForBmi(p);
  }
  const r = calcBMI(w && w.value, h && h.value, ageY);
  if(!r){ el.textContent = ''; return; }
  el.textContent = `BMI: ${r.value} (${r.label}) · ${r.standard}`;
}

function normalizeComplaintsInput(raw){
  // Store without forcing C/O in the form — formatting is applied on the card.
  return (raw||'').trim();
}
function newPatientId(){
  const seq = state.data.nextPatientSeq;
  state.data.nextPatientSeq = seq + 1;
  return 'MMC' + String(seq).padStart(4,'0');
}
function newVisitId(){ return 'V' + Date.now().toString(36).toUpperCase(); }
// Token number for waiting-room queue (resets each calendar day)
function nextTokenNumber(){
  const today = todayStr();
  if(state.data.tokenDate !== today){
    state.data.tokenDate = today;
    state.data.nextTokenSeq = 1;
  }
  const n = state.data.nextTokenSeq || 1;
  state.data.nextTokenSeq = n + 1;
  return n;
}


/* ============================= STORAGE (server API) ============================= */
let dataVersion = 0;

const DATA_KEY = 'mmc_clinic_data';

function migrateClinicData(){
  if(!state.data.customMedicines) state.data.customMedicines = [];
  if(!state.data.appointments) state.data.appointments = [];
  if(!state.data.auditLog) state.data.auditLog = [];
  if(!state.data.rxTemplates) state.data.rxTemplates = [];
  if(!state.data.clinicInfo) state.data.clinicInfo = defaultData().clinicInfo;
  if(state.data.clinicInfo.logo === undefined) state.data.clinicInfo.logo = '';
  (state.data.patients||[]).forEach(p=>{
    if(p.chronicIllness == null) p.chronicIllness = '';
    if(p.allergies == null) p.allergies = '';
  });
}

async function seedDemoClinic(){
  const pin = await hashPin('1234');
  const today = todayStr();
  const follow = new Date(); follow.setDate(follow.getDate()+3);
  const followStr = follow.toISOString().slice(0,10);
  state.data.clinicInfo = {
    name: 'Male Madeshwara Clinic',
    shortName: 'MMC',
    address: 'Main Road, Kollegal, Chamarajanagar Dist., Karnataka',
    phone: '08224-252 180',
    logo: ''
  };
  state.data.staff = [
    {name:'Dr. R. Sharma', role:'Doctor', pin, owner:true, qualification:'M.B.B.S., M.D. (Paediatrics)'},
    {name:'Priya N.', role:'Receptionist', pin, owner:false, qualification:''}
  ];
  state.data.nextPatientSeq = 4;
  state.data.nextCertSeq = 1;
  state.data.nextTokenSeq = 3;
  state.data.tokenDate = today;
  state.data.demoSeeded = true;
  state.data.patients = [
    {
      id:'MMC0001', name:'Lakshmi Rao', dob:'1984-03-12', age:'', sex:'Female',
      phone:'9876543210', address:'2nd Cross, College Road, Kollegal',
      allergies:'Penicillin', chronicIllness:'Type 2 diabetes, Hypertension',
      registeredDate: today, visits:[{
        id:'VDEMO1', token:1, date:today, time:'10:15',
        doctorName:'Dr. R. Sharma',
        vitals:{bp:'128/82', pulse:'88', temp:'99.4°F', weight:'64', height:'158'},
        complaints:'Fever × 3 days, Body ache',
        examination:'Throat congested. No rash. Chest clear.',
        diagnosis:'Acute febrile illness / Viral fever',
        notes:'',
        followUpDate: followStr,
        assignedDoctor:'', referredTo:'', referralReason:'',
        prescriptions:[
          {medicine:'Tab. Paracetamol', dosage:'650mg', frequency:'1-1-1', duration:'5 days', instructions:'After food'},
          {medicine:'Tab. Cetirizine', dosage:'10mg', frequency:'0-0-1', duration:'5 days', instructions:'At night'}
        ],
        investigations:[{
          test:'Complete Blood Count (CBC)', notes:'',
          result:'Mild neutrophilic leucocytosis',
          components:{Hb:'11.2', PCV:'34', RBC:'4.1', TLC:'12400', Neutrophils:'78', Lymphocytes:'16', Eosinophils:'3', Monocytes:'3', Platelets:'210000'}
        }],
        status:'completed',
        billing:{fee:'300', charges:[], paid:true, mode:'UPI'}
      }],
      growthRecords:[], vaccinations:[]
    },
    {
      id:'MMC0002', name:'Arjun K', dob:'2021-06-18', age:'', sex:'Male',
      phone:'9845011122', address:'Temple Street, Kollegal',
      allergies:'', chronicIllness:'',
      registeredDate: today, visits:[], growthRecords:[], vaccinations:[]
    },
    {
      id:'MMC0003', name:'Suresh Gowda', dob:'1968-01-20', age:'', sex:'Male',
      phone:'9742012345', address:'Bus Stand Road, Kollegal',
      allergies:'Sulfa', chronicIllness:'COPD',
      registeredDate: today, visits:[{
        id:'VDEMO2', token:2, date:today, time:'11:40',
        doctorName:'Dr. R. Sharma',
        vitals:{bp:'138/86', pulse:'92', temp:'98.4°F', weight:'71', height:'168'},
        complaints:'Cough × 1 week, Breathlessness',
        examination:'Bilateral wheeze. No cyanosis.',
        diagnosis:'Acute exacerbation of COPD',
        notes:'Advised nebulisation and review.',
        followUpDate: followStr,
        assignedDoctor:'', referredTo:'', referralReason:'',
        prescriptions:[
          {medicine:'Tab. Azithromycin', dosage:'500mg', frequency:'1-0-0', duration:'3 days', instructions:'After food'},
          {medicine:'Syp. Ambroxol (Cough)', dosage:'15mg/5ml', frequency:'1-1-1', duration:'5 days', instructions:''}
        ],
        investigations:[{
          test:'Liver Function Test (LFT)', notes:'',
          result:'',
          components:{TBili:'0.8', DBili:'0.2', AST:'38', ALT:'72', ALP:'96', Protein:'7.1', Albumin:'4.2'}
        }],
        status:'completed',
        billing:{fee:'400', charges:[{label:'Nebulisation', amount:'150'}], paid:false, mode:''}
      }],
      growthRecords:[], vaccinations:[]
    }
  ];
  logAudit('Demo clinic seeded', 'Sample patients and visits for first-run preview', 'System');
}

async function persistLocal(){
  localStorage.setItem(DATA_KEY, JSON.stringify({version: dataVersion, data: state.data}));
}

async function loadData(){
  try{
    const raw = localStorage.getItem(DATA_KEY);
    if(raw){
      const json = JSON.parse(raw);
      state.data = json.data || json;
      dataVersion = json.version || 1;
    } else {
      state.data = defaultData();
      dataVersion = 1;
      await seedDemoClinic();
      await persistLocal();
    }
    migrateClinicData();
    state.loadError = null;
    ensureOwnerExists();
  } catch(e){
    state.loadError = 'Could not load clinic records on this device. Try reloading the page.';
  }
  state.loading = false;
  render();
}

// Saves state.data to the server. Returns true on success, false if the
// save failed or was superseded by another device's more recent save
// (in which case state.data is refreshed with the server's latest copy).
async function saveData(){
  try{
    dataVersion = (dataVersion||0) + 1;
    await persistLocal();
    state.saveError = null;
    return true;
  } catch(e){
    state.saveError = 'Could not save on this device — storage may be full or blocked.';
    return false;
  }
}

/* ============================= NAV ============================= */
function go(route, params){
  state.route = route;
  state.routeParams = params || {};
  state.search = '';
  state.ui.editingPatient = false;
  if(route === 'newVisit'){
    let existingVisit = null;
    if(state.routeParams.editVisitId && state.routeParams.patientId){
      const p = state.data.patients.find(p=>p.id===state.routeParams.patientId);
      existingVisit = p ? (p.visits||[]).find(v=>v.id===state.routeParams.editVisitId) : null;
    }
    initDraftVisit(state.routeParams.patientId || null, existingVisit);
    if(!existingVisit) restoreVisitDraftIfAny();
  }
  if(route === 'newAppointment'){
    initDraftAppt();
  }
  if(route === 'newPatient'){
    state.regDupeAcknowledged = false;
  }
  if(route === 'mergePatients'){
    initMergeUI();
  }
  render();
}

/* ============================= AUTH ============================= */
// Staff PINs are stored as SHA-256 hashes, not plain text (matters since
// the data backup export makes the raw record easy to open). Accounts
// created before this existed still have a plain 4-digit PIN on file;
// verifyPin() accepts either, and silently upgrades a legacy account to a
// hash the next time that PIN is used successfully.
async function hashPin(pin){
  const enc = new TextEncoder().encode(pin);
  const buf = await crypto.subtle.digest('SHA-256', enc);
  return Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
}
function looksHashed(pin){ return typeof pin === 'string' && pin.length === 64 && /^[0-9a-f]+$/.test(pin); }
async function verifyPin(staff, enteredPin){
  if(looksHashed(staff.pin)) return (await hashPin(enteredPin)) === staff.pin;
  return staff.pin === enteredPin;
}

/* ============================= PIN LOCKOUT ============================= */
// A 4-digit PIN only has 10,000 combinations, so with no limit it's
// guessable quickly. We track wrong attempts per staff name in
// localStorage (survives a page reload, unlike in-memory state) and lock
// that name out for a cooldown once the threshold is hit. The cooldown
// doubles each time it's triggered again, so repeated guessing gets
// slower rather than staying a fixed, plannable delay.
const PIN_LOCK_THRESHOLD = 5;
const PIN_LOCK_BASE_MS = 30 * 1000; // 30s, then 60s, 120s... capped below
const PIN_LOCK_MAX_MS = 15 * 60 * 1000; // cap at 15 minutes
function getPinAttempts(){
  try{ return JSON.parse(localStorage.getItem('mmc_pin_attempts')||'{}'); } catch(e){ return {}; }
}
function savePinAttempts(obj){
  try{ localStorage.setItem('mmc_pin_attempts', JSON.stringify(obj)); } catch(e){ /* storage unavailable */ }
}
function pinLockStatus(name){
  if(!name) return {locked:false};
  const rec = getPinAttempts()[name];
  if(rec && rec.lockedUntil && Date.now() < rec.lockedUntil){
    return {locked:true, remainingMs: rec.lockedUntil - Date.now()};
  }
  return {locked:false};
}
function recordFailedPin(name){
  const all = getPinAttempts();
  const rec = all[name] || {fails:0, lockCount:0};
  rec.fails++;
  if(rec.fails >= PIN_LOCK_THRESHOLD){
    rec.lockCount++;
    rec.lockedUntil = Date.now() + Math.min(PIN_LOCK_BASE_MS * Math.pow(2, rec.lockCount-1), PIN_LOCK_MAX_MS);
    rec.fails = 0;
  }
  all[name] = rec;
  savePinAttempts(all);
  return rec;
}
function clearPinAttempts(name){
  const all = getPinAttempts();
  delete all[name];
  savePinAttempts(all);
}
function onLoginStaffChange(name){
  state.loginSelectedName = name;
  const lock = pinLockStatus(name);
  state.loginError = lock.locked ? `Too many incorrect attempts. Try again in ${Math.ceil(lock.remainingMs/1000)}s.` : '';
  render();
}

async function doSetup(){
  const name = document.getElementById('setup-name').value.trim();
  const role = document.getElementById('setup-role').value;
  const pin = document.getElementById('setup-pin').value.trim();
  const err = document.getElementById('setup-error');
  if(!name || !/^\d{4}$/.test(pin)){
    err.textContent = 'Enter your name and a 4-digit PIN.'; return;
  }
  state.data.staff.push({name, role, pin: await hashPin(pin), owner: true, qualification: ''});
  logAudit('Clinic set up', `First account: ${name} (${role})`, name);
  const ok = await saveData();
  if(!ok){ err.textContent = state.saveError; render(); return; }
  state.session.staffName = name;
  saveSessionToStorage();
  go('dashboard');
}

// Whoever's logged in — used to gate doctor-only actions like "Continue".
function currentStaffRole(){
  if(!state.data || !state.data.staff) return null; // data hasn't loaded yet (or failed to)
  const s = state.data.staff.find(s=>s.name===state.session.staffName);
  return s ? s.role : null;
}
function isDoctor(){ return currentStaffRole()==='Doctor'; }
// Clinic admin flag on a staff record — never used as a printed title on documents.
function isOwner(){
  const s = state.data && state.data.staff
    ? state.data.staff.find(x=>x.name===state.session.staffName) : null;
  return !!(s && s.owner);
}
// Ensure at least one owner exists (legacy data / first account).
function ensureOwnerExists(){
  if(!state.data || !state.data.staff || !state.data.staff.length) return;
  if(state.data.staff.some(s=>s.owner)) return;
  // Prefer first Doctor, else first staff account
  const doc = state.data.staff.find(s=>s.role==='Doctor');
  (doc || state.data.staff[0]).owner = true;
}
function displayStaffRole(s){
  // Roles shown in the app UI — never print "Owner" on clinical documents.
  if(!s) return '';
  return s.role || '';
}


function staffByName(name){
  if(!name || !state.data || !state.data.staff) return null;
  return state.data.staff.find(s=>s.name===name) || null;
}
function staffQualification(name){
  const s = staffByName(name);
  return (s && s.qualification) ? s.qualification : '';
}


// A visit a receptionist saved without a diagnosis yet is "waiting" for a
// doctor to continue it. Older records with no explicit status fall back
// to inferring it from whether a diagnosis was ever recorded.
function visitStatus(v){
  return v.status || (v.diagnosis ? 'completed' : 'waiting');
}

// Older visits (saved before billing existed) get a default here rather
// than being migrated in the database.
function billingOf(v){
  return v.billing || { fee:'', charges:[], paid:false, mode:'' };
}
function billingTotal(b){
  const fee = parseFloat(b.fee) || 0;
  const chargeSum = (b.charges||[]).reduce((sum,c)=> sum + (parseFloat(c.amount)||0), 0);
  return fee + chargeSum;
}

// Records who changed what and when. Call this right before saveData() so
// the entry rides along with the same save. `actor` lets a couple of
// pre-login flows (first-time setup, adding an account from the login
// screen) attribute the entry to the name just entered rather than
// whoever happens to be logged in (nobody, at that point).
function logAudit(action, details, actor){
  if(!state.data.auditLog) state.data.auditLog = [];
  state.data.auditLog.push({
    ts: new Date().toISOString(),
    staff: actor || state.session.staffName || 'System',
    action, details: details || ''
  });
  // Keep the log from growing without bound — recent history matters most.
  if(state.data.auditLog.length > 1000) state.data.auditLog = state.data.auditLog.slice(-1000);
}

async function doLogin(){
  const name = document.getElementById('login-select').value;
  const pin = document.getElementById('login-pin').value.trim();
  const lock = pinLockStatus(name);
  if(lock.locked){
    state.loginError = `Too many incorrect attempts. Try again in ${Math.ceil(lock.remainingMs/1000)}s.`;
    render();
    return;
  }
  const staff = state.data.staff.find(s => s.name === name);
  if(staff && await verifyPin(staff, pin)){
    clearPinAttempts(name);
    state.session.staffName = name;
    state.loginError = '';
    saveSessionToStorage();
    if(!looksHashed(staff.pin)){ staff.pin = await hashPin(pin); saveData(); }
    go('dashboard');
  } else {
    const rec = recordFailedPin(name);
    if(rec.lockedUntil && Date.now() < rec.lockedUntil){
      state.loginError = `Too many incorrect attempts. Try again in ${Math.ceil((rec.lockedUntil-Date.now())/1000)}s.`;
    } else {
      const left = PIN_LOCK_THRESHOLD - rec.fails;
      state.loginError = `Incorrect PIN. Try again.${left<=2 ? ` (${left} attempt${left===1?'':'s'} left before a cooldown)` : ''}`;
    }
    render();
  }
}

function toggleAddFromLogin(){
  state.loginMode = state.loginMode === 'login' ? 'addFromLogin' : 'login';
  state.loginError = '';
  render();
}

async function addStaffFromLogin(){
  const name = document.getElementById('als-name').value.trim();
  const role = document.getElementById('als-role').value;
  const pin = document.getElementById('als-pin').value.trim();
  const err = document.getElementById('als-error');
  if(!name || !/^\d{4}$/.test(pin)){
    err.textContent = 'Enter a name and a 4-digit PIN.'; return;
  }
  if(state.data.staff.some(s=>s.name===name)){
    err.textContent = 'That name is already registered.'; return;
  }
  state.data.staff.push({name, role, pin: await hashPin(pin), owner: false, qualification: ''});
  logAudit('Added staff account', `${name} (${role})`);
  const ok = await saveData();
  if(!ok){ err.textContent = state.saveError; render(); return; }
  state.loginMode = 'login';
  render();
}

function logout(){
  state.session.staffName = null;
  state.loginMode = 'login';
  clearSessionStorage();
  go('dashboard');
}

/* ============================= SESSION PERSISTENCE ============================= */
// Mobile/tablet browsers routinely discard a backgrounded tab to save memory
// and reload it from scratch when you switch back — which used to wipe the
// in-memory `state` object and drop the user back to the login screen even
// though they'd been active seconds earlier. We mirror just the login name
// and a last-activity timestamp into sessionStorage (cleared when the tab or
// browser actually closes, unlike localStorage) so a reload can silently
// restore the session instead of forcing a re-login — while still honoring
// the real idle timeout if the time away exceeds it.
const SESSION_KEY = 'mmc_session';
function saveSessionToStorage(){
  try{
    if(!state.session.staffName){ sessionStorage.removeItem(SESSION_KEY); return; }
    sessionStorage.setItem(SESSION_KEY, JSON.stringify({staffName: state.session.staffName, lastActivity: Date.now()}));
  } catch(e){ /* storage unavailable (e.g. private mode) — session just won't survive a reload */ }
}
function clearSessionStorage(){
  try{ sessionStorage.removeItem(SESSION_KEY); } catch(e){}
}
function restoreSessionFromStorage(){
  try{
    const raw = sessionStorage.getItem(SESSION_KEY);
    if(!raw) return;
    const saved = JSON.parse(raw);
    if(saved && saved.staffName && (Date.now() - saved.lastActivity) < IDLE_TIMEOUT_MS){
      state.session.staffName = saved.staffName;
    } else {
      clearSessionStorage();
    }
  } catch(e){ /* ignore malformed/unavailable storage */ }
}

/* ============================= IDLE AUTO-LOGOUT ============================= */
// A shared front-desk computer shouldn't stay signed in indefinitely, so we
// log out automatically after a stretch of no keyboard/mouse/touch activity.
const IDLE_TIMEOUT_MS = 15 * 60 * 1000; // 15 minutes
let idleTimer = null;
function resetIdleTimer(){
  if(idleTimer){ clearTimeout(idleTimer); idleTimer = null; }
  if(!state.session.staffName) return;
  saveSessionToStorage(); // stamp last-activity so a tab reload can restore correctly
  idleTimer = setTimeout(()=>{
    if(state.session.staffName){
      logout();
      state.loginError = 'Logged out after 15 minutes of inactivity.';
      render();
    }
  }, IDLE_TIMEOUT_MS);
}
['mousedown','mousemove','keydown','touchstart','scroll'].forEach(evt=>{
  document.addEventListener(evt, resetIdleTimer, {passive:true});
});
// Coming back to this tab counts as activity too — switching tabs to check
// something else and returning a minute later shouldn't cost the session.
document.addEventListener('visibilitychange', ()=>{
  if(document.visibilityState === 'visible') resetIdleTimer();
});

/* ============================= PATIENTS ============================= */
function onPatientSearchInput(v){
  state.search = v;
  const el = document.getElementById('patients-table-container');
  if(el) el.innerHTML = patientsTableHTML();
}

function filteredPatients(){
  const q = state.search.trim().toLowerCase();
  let list = state.data.patients.slice().sort((a,b)=> (b.registeredDate||'').localeCompare(a.registeredDate||''));
  if(q){
    list = list.filter(p =>
      p.name.toLowerCase().includes(q) ||
      p.id.toLowerCase().includes(q) ||
      (p.phone||'').includes(q)
    );
  }
  return list;
}

function lastVisitDate(p){
  if(!p.visits || p.visits.length===0) return null;
  return p.visits.slice().sort((a,b)=> (b.date+b.id).localeCompare(a.date+a.id))[0].date;
}

// Normalizes to digits-only so "98765 43210", "(987) 654-3210" etc. all
// compare equal — a punctuation difference shouldn't hide a real duplicate.
function normPhone(p){ return (p||'').replace(/\D/g,''); }
function phoneDuplicates(phone, excludeId){
  const np = normPhone(phone);
  if(!np) return [];
  return state.data.patients.filter(p=> p.id!==excludeId && normPhone(p.phone)===np);
}
function dupeWarningHTML(matches){
  const cards = matches.map(p=>`
    <div class="card" style="padding:10px 12px;margin-bottom:6px;">
      <strong>${esc(p.name)}</strong> <span class="pill">${p.id}</span>
      <div class="faint">${esc(displayAge(p))}/${esc(p.sex)} · ${(p.visits||[]).length} visit(s)${lastVisitDate(p)?' · last visit '+fmtDate(lastVisitDate(p)):''}</div>
      <button class="btn btn-sm" style="margin-top:6px;" onclick="go('patient',{patientId:'${p.id}'})">Use this record instead</button>
    </div>`).join('');
  return `
    <div class="banner" style="background:var(--accent-tint);color:var(--accent);margin-top:10px;">
      <strong>⚠ This phone number is already on file.</strong> A shared family phone can mean two different people — check it's not the same person before registering a new record.
    </div>
    ${cards}
    <button class="btn btn-ghost btn-sm" onclick="confirmRegisterAnyway()">This is a different person — register anyway</button>`;
}
function confirmRegisterAnyway(){
  state.regDupeAcknowledged = true;
  saveNewPatient();
}
async function saveNewPatient(){
  const name = document.getElementById('reg-name').value.trim();
  const dob = document.getElementById('reg-dob').value;
  const age = document.getElementById('reg-age').value.trim();
  const sex = document.getElementById('reg-sex').value;
  const phone = document.getElementById('reg-phone').value.trim();
  const address = document.getElementById('reg-address').value.trim();
  const allergies = document.getElementById('reg-allergies').value.trim();
  const chronicIllness = document.getElementById('reg-chronic') ? document.getElementById('reg-chronic').value.trim() : '';
  const err = document.getElementById('reg-error');
  if(!name || (!dob && !age) || !sex || !phone || !address){
    err.textContent = 'Name, date of birth (or age), sex, phone and address are all required.'; return;
  }
  err.textContent = '';
  if(!state.regDupeAcknowledged){
    const matches = phoneDuplicates(phone, null);
    if(matches.length){
      const warnEl = document.getElementById('reg-dupe-warning');
      if(warnEl) warnEl.innerHTML = dupeWarningHTML(matches);
      return;
    }
  }
  const patient = {
    id: newPatientId(), name, dob: dob||'', age, sex, phone, address, allergies, chronicIllness,
    registeredDate: todayStr(), visits: [], growthRecords: [], vaccinations: []
  };
  state.data.patients.push(patient);
  logAudit('Registered patient', `${patient.name} (${patient.id})`);
  const ok = await saveData();
  if(!ok){ err.textContent = state.saveError; render(); return; }
  go('patient', {patientId: patient.id});
}

function startEditPatient(){ state.ui.editingPatient = true; render(); }
function cancelEditPatient(){ state.ui.editingPatient = false; render(); }
async function saveEditPatient(patientId){
  const p = state.data.patients.find(p=>p.id===patientId);
  const name = document.getElementById('ep-name').value.trim();
  const dob = document.getElementById('ep-dob').value;
  const age = document.getElementById('ep-age').value.trim();
  const sex = document.getElementById('ep-sex').value;
  const phone = document.getElementById('ep-phone').value.trim();
  const address = document.getElementById('ep-address').value.trim();
  const allergies = document.getElementById('ep-allergies').value.trim();
  const chronicIllness = document.getElementById('ep-chronic') ? document.getElementById('ep-chronic').value.trim() : '';
  const err = document.getElementById('ep-error');
  if(!name || (!dob && !age) || !sex || !phone || !address){
    if(err) err.textContent = 'Name, date of birth (or age), sex, phone and address are all required.';
    return;
  }
  p.name = name; p.dob = dob||''; p.age = age; p.sex = sex; p.phone = phone; p.address = address; p.allergies = allergies; p.chronicIllness = chronicIllness;
  if(p.detailsRedacted){ p.detailsRedacted = false; p.redactedAt = ''; }
  logAudit('Edited patient', `${name} (${p.id})`);
  state.ui.editingPatient = false;
  await saveData();
  render();
}

/* ============================= APPOINTMENTS ============================= */
function appointmentsForDate(date){
  return (state.data.appointments||[])
    .filter(a=>a.date===date && a.status!=='cancelled')
    .sort((a,b)=> (a.time||'').localeCompare(b.time||''));
}
function shiftApptDate(deltaDays){
  const d = new Date((state.apptDate||todayStr())+'T00:00:00');
  d.setDate(d.getDate()+deltaDays);
  state.apptDate = d.toISOString().slice(0,10);
  render();
}
function setApptDate(v){ state.apptDate = v; render(); }
function goToApptToday(){ state.apptDate = todayStr(); render(); }

function appointmentsView(){
  state.apptDate = state.apptDate || todayStr();
  const date = state.apptDate;
  const isToday = date === todayStr();
  const list = appointmentsForDate(date);

  const rows = list.map(a=>{
    const patient = a.patientId ? state.data.patients.find(p=>p.id===a.patientId) : null;
    const nameCell = patient
      ? `${esc(patient.name)} <span class="pill">${patient.id}</span>`
      : `${esc(a.name)}${a.phone?` <span class="faint">${esc(a.phone)}</span>`:''} <span class="faint">(not registered)</span>`;
    const canCheckIn = isToday && a.status==='booked';
    const isPastOrToday = date <= todayStr();
    const statusPill =
      a.status==='checked-in' ? '<span class="pill">Arrived</span>' :
      a.status==='no-show' ? '<span class="pill" style="background:var(--danger-tint);color:var(--danger);">No-show</span>' : '';
    return `<tr>
      <td>${esc(a.time)}</td>
      <td>${nameCell}</td>
      <td>${esc(a.doctorName)||'<span class="faint">Any</span>'}</td>
      <td>${esc(a.notes)||'<span class="faint">—</span>'}</td>
      <td style="white-space:nowrap;">
        ${statusPill}
        ${canCheckIn ? `<button class="btn btn-sm btn-accent" onclick="checkInAppointment('${a.id}')">Check in</button>` : ''}
        ${a.status==='booked' ? `<button class="btn btn-ghost btn-sm" onclick="startEditAppointment('${a.id}')">Reschedule</button>` : ''}
        ${a.status==='booked' && isPastOrToday ? `<button class="btn btn-ghost btn-sm" onclick="markNoShow('${a.id}')">No-show</button>` : ''}
        ${a.status==='booked' ? `<button class="btn btn-ghost btn-sm" onclick="cancelAppointment('${a.id}')">Cancel</button>` : ''}
      </td>
    </tr>`;
  }).join('');

  return `
    <div class="page-head">
      <div><h1>Appointments</h1><p class="muted">Book ahead and see the day's booked slots</p></div>
      <button class="btn btn-accent" onclick="go('newAppointment')">+ Book appointment</button>
    </div>
    <div class="card">
      <div class="row" style="align-items:flex-end;margin-bottom:14px;">
        <div class="field" style="max-width:180px;flex:none;"><label>Date</label><input type="date" value="${date}" onchange="setApptDate(this.value)"></div>
        <button class="btn btn-sm" onclick="shiftApptDate(-1)">‹ Prev day</button>
        <button class="btn btn-sm" onclick="goToApptToday()">Today</button>
        <button class="btn btn-sm" onclick="shiftApptDate(1)">Next day ›</button>
      </div>
      <p class="muted" style="margin-bottom:10px;">${fmtDate(date)}${isToday?' — today':''} · ${list.length} booked</p>
      ${list.length
        ? `<table><thead><tr><th>Time</th><th>Patient</th><th>Doctor</th><th>Notes</th><th></th></tr></thead><tbody>${rows}</tbody></table>`
        : `<p class="muted">No appointments booked for this day.</p>`}
    </div>`;
}

function initDraftAppt(){
  state.draftAppt = {
    editId: null, patientId: null, guestName:'', guestPhone:'',
    date: state.apptDate || todayStr(), time:'', doctorName:'', notes:''
  };
  state.apptPatientSearch = '';
  state.apptError = '';
}
function startEditAppointment(id){
  const a = (state.data.appointments||[]).find(a=>a.id===id);
  if(!a) return;
  state.draftAppt = {
    editId: a.id,
    patientId: a.patientId || null,
    guestName: a.name || '', guestPhone: a.phone || '',
    date: a.date, time: a.time, doctorName: a.doctorName || '', notes: a.notes || ''
  };
  state.apptPatientSearch = '';
  state.apptError = '';
  state.route = 'newAppointment';
  state.routeParams = {};
  render();
}
async function markNoShow(id){
  const a = (state.data.appointments||[]).find(a=>a.id===id);
  if(!a) return;
  const label = a.patientId ? (state.data.patients.find(p=>p.id===a.patientId)||{}).name || a.patientId : a.name;
  if(!confirm(`Mark ${label}'s ${fmtDate(a.date)} ${a.time} appointment as a no-show?`)) return;
  a.status = 'no-show';
  logAudit('Marked appointment no-show', `${label} — ${fmtDate(a.date)} ${a.time}`);
  const ok = await saveData();
  if(!ok) render(); else render();
}

function onApptPatientSearch(v){
  state.apptPatientSearch = v;
  const el = document.getElementById('appt-patient-results');
  if(el) el.innerHTML = apptPatientResultsHTML();
}
function apptPatientResultsHTML(){
  const q = (state.apptPatientSearch||'').trim().toLowerCase();
  if(!q) return '';
  const matches = state.data.patients.filter(p=>
    p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q) || (p.phone||'').includes(q)
  ).slice(0,6);
  if(!matches.length) return `<p class="faint">No matches — fill in the name and phone below instead.</p>`;
  return matches.map(p=>
    `<div class="chip" style="display:block;width:fit-content;margin-bottom:4px;" onmousedown="selectPatientForAppt('${p.id}')">${esc(p.name)} — ${p.id}${p.phone?(' · '+esc(p.phone)):''}</div>`
  ).join('');
}
function selectPatientForAppt(id){
  state.draftAppt.patientId = id;
  state.apptPatientSearch = '';
  render();
}

function newAppointmentView(){
  if(!state.draftAppt) initDraftAppt();
  const da = state.draftAppt;
  const doctors = state.data.staff.filter(s=>s.role==='Doctor');

  let patientBlock;
  if(da.patientId){
    const p = state.data.patients.find(p=>p.id===da.patientId);
    patientBlock = `<div class="banner banner-info">Patient: <strong>${esc(p.name)}</strong> (${p.id}) — ${esc(displayAge(p))}/${esc(p.sex)}
      <button class="btn btn-ghost btn-sm" style="margin-left:8px;" onclick="state.draftAppt.patientId=null;render()">Change</button></div>`;
  } else {
    patientBlock = `
      <div class="field"><label>Find existing patient (optional)</label>
        <input type="text" placeholder="Search by name, ID or phone" value="${esc(state.apptPatientSearch)}" oninput="onApptPatientSearch(this.value)"></div>
      <div id="appt-patient-results" style="margin-bottom:10px;">${apptPatientResultsHTML()}</div>
      <p class="faint" style="margin:0 0 10px;">Not registered yet? Just fill in their name and phone instead.</p>
      <div class="row">
        <div class="field"><label>Name</label><input id="appt-guest-name" value="${esc(da.guestName)}"></div>
        <div class="field"><label>Phone</label><input id="appt-guest-phone" value="${esc(da.guestPhone)}"></div>
      </div>`;
  }

  return `
    <div class="page-head"><h1>${da.editId ? 'Reschedule appointment' : 'Book appointment'}</h1></div>
    <div class="card" style="max-width:520px;">
      ${patientBlock}
      <div class="row" style="margin-top:6px;">
        <div class="field"><label>Date *</label><input id="appt-date" type="date" value="${esc(da.date)}"></div>
        <div class="field"><label>Time *</label><input id="appt-time" type="time" value="${esc(da.time)}"></div>
      </div>
      ${doctors.length ? `<div class="field"><label>Doctor (optional)</label>
        <select id="appt-doctor"><option value="">No preference</option>${doctors.map(d=>`<option ${d.name===da.doctorName?'selected':''}>${esc(d.name)}</option>`).join('')}</select></div>` : ''}
      <div class="field"><label>Notes</label><input id="appt-notes" value="${esc(da.notes)}" placeholder="e.g. reason for visit"></div>
      <div id="appt-error" class="error-text">${esc(state.apptError||'')}</div>
      <div class="row">
        <button class="btn btn-primary" onclick="saveAppointment()">${da.editId ? 'Save changes' : 'Book appointment'}</button>
        <button class="btn btn-ghost" onclick="state.draftAppt=null;go('appointments')">Cancel</button>
      </div>
    </div>`;
}

// True if some other booked/checked-in appointment already has this doctor
// at this exact date+time. excludeId lets a reschedule ignore itself.
function apptConflict(date, time, doctorName, excludeId){
  if(!doctorName) return null;
  return (state.data.appointments||[]).find(a=>
    a.id!==excludeId && a.date===date && a.time===time && a.doctorName===doctorName &&
    (a.status==='booked' || a.status==='checked-in')
  );
}

async function saveAppointment(){
  const da = state.draftAppt;
  const date = document.getElementById('appt-date').value;
  const time = document.getElementById('appt-time').value;
  const doctorEl = document.getElementById('appt-doctor');
  const doctorName = doctorEl ? doctorEl.value : '';
  const notes = document.getElementById('appt-notes').value.trim();
  const errEl = document.getElementById('appt-error');
  let guestName = '', guestPhone = '';
  if(!da.patientId){
    guestName = document.getElementById('appt-guest-name').value.trim();
    guestPhone = document.getElementById('appt-guest-phone').value.trim();
  }
  if(!date || !time){ errEl.textContent = 'Date and time are both required.'; return; }
  if(!da.patientId && !guestName){ errEl.textContent = 'Select an existing patient, or enter a name for someone not yet registered.'; return; }
  errEl.textContent = '';

  const conflict = apptConflict(date, time, doctorName, da.editId);
  if(conflict){
    const conflictLabel = conflict.patientId ? (state.data.patients.find(p=>p.id===conflict.patientId)||{}).name || conflict.patientId : conflict.name;
    if(!confirm(`${doctorName} already has an appointment with ${conflictLabel} at ${time} on ${fmtDate(date)}. Book this one anyway?`)) return;
  }

  if(!state.data.appointments) state.data.appointments = [];
  const apptPatientLabel = da.patientId
    ? (state.data.patients.find(p=>p.id===da.patientId)||{}).name || da.patientId
    : guestName;

  if(da.editId){
    const a = state.data.appointments.find(a=>a.id===da.editId);
    if(!a){ errEl.textContent = 'That appointment no longer exists.'; return; }
    a.patientId = da.patientId || null;
    a.name = da.patientId ? '' : guestName;
    a.phone = da.patientId ? '' : guestPhone;
    a.date = date; a.time = time; a.doctorName = doctorName||''; a.notes = notes;
    logAudit('Rescheduled appointment', `${apptPatientLabel} — ${fmtDate(date)} ${time}`);
  } else {
    state.data.appointments.push({
      id: 'A'+Date.now().toString(36).toUpperCase(),
      patientId: da.patientId || null,
      name: da.patientId ? '' : guestName,
      phone: da.patientId ? '' : guestPhone,
      date, time, doctorName: doctorName||'', notes,
      status: 'booked', bookedBy: state.session.staffName||'', createdAt: new Date().toISOString()
    });
    logAudit('Booked appointment', `${apptPatientLabel} — ${fmtDate(date)} ${time}`);
  }
  const ok = await saveData();
  if(!ok){ errEl.textContent = state.saveError; render(); return; }
  state.apptDate = date;
  state.draftAppt = null;
  go('appointments');
}

async function cancelAppointment(id){
  const a = (state.data.appointments||[]).find(a=>a.id===id);
  if(!a) return;
  if(!confirm('Cancel this appointment? This can\'t be undone.')) return;
  const label = a.patientId ? (state.data.patients.find(p=>p.id===a.patientId)||{}).name || a.patientId : a.name;
  a.status = 'cancelled';
  logAudit('Cancelled appointment', `${label} — ${fmtDate(a.date)} ${a.time}`);
  const ok = await saveData();
  if(!ok) render();
  else render();
}

async function checkInAppointment(id){
  const a = (state.data.appointments||[]).find(a=>a.id===id);
  if(!a) return;
  a.status = 'checked-in';
  await saveData();
  if(a.patientId){
    go('newVisit', {patientId: a.patientId});
  } else {
    go('newVisit');
    state.draftVisit.newPatient = {name: a.name||'', dob:'', age:'', sex:'', phone: a.phone||'', address:''};
    render();
  }
}

/* ============================= NEW VISIT (draft) ============================= */
function initDraftVisit(patientId, existingVisit){
  if(existingVisit){
    state.draftVisit = {
      patientId: patientId,
      newPatient: null,
      editingVisitId: existingVisit.id,
      doctorName: existingVisit.doctorName || state.session.staffName || '',
      vitals: { bp:'', pulse:'', temp:'', weight:'', height:'', ...(existingVisit.vitals||{}) },
      complaints: existingVisit.complaints||'', examination: existingVisit.examination||'',
      diagnosis: existingVisit.diagnosis||'', notes: existingVisit.notes||'',
      followUpDate: existingVisit.followUpDate||'',
      assignedDoctor: existingVisit.assignedDoctor||'',
      referredTo: existingVisit.referredTo||'', referralReason: existingVisit.referralReason||'',
      prescriptions: (existingVisit.prescriptions && existingVisit.prescriptions.length)
        ? existingVisit.prescriptions.map(r=>({...r})) : [{medicine:'',dosage:'',frequency:'',duration:'',instructions:''}],
      investigations: (existingVisit.investigations && existingVisit.investigations.length)
        ? existingVisit.investigations.map(r=>({...r})) : [{test:'',notes:''}]
    };
  } else {
    state.draftVisit = {
      patientId: patientId || null,
      newPatient: null,
      editingVisitId: null,
      doctorName: state.session.staffName || '',
      vitals: {bp:'',pulse:'',temp:'',weight:'',height:''},
      complaints:'', examination:'', diagnosis:'', notes:'', followUpDate:'', assignedDoctor:'',
      referredTo:'', referralReason:'',
      prescriptions: [{medicine:'',dosage:'',frequency:'',duration:'',instructions:''}],
      investigations: []
    };
  }
  state.visitError = '';
}

function toggleNewPatientInVisit(){
  state.draftVisit.newPatient = state.draftVisit.newPatient ? null : {name:'',dob:'',age:'',sex:'',phone:'',address:'',allergies:'',chronicIllness:''};
  state.draftVisit.patientId = null;
  render();
}

/* ============================= OFFLINE DRAFT RESILIENCE ============================= */
// A consultation in progress lives only in the DOM/JS memory until "Save
// visit" successfully reaches the server. On a shaky connection — or if the
// tab is closed or reloaded by accident — that typed work would otherwise
// vanish with no way back. We snapshot the doctor's form into localStorage
// every few seconds while it's open, and offer to restore it the next time
// a blank consultation is opened. This is a local safety net only — it
// doesn't sync anything to the server by itself.
const VISIT_DRAFT_KEY = 'mmc_visit_draft';
function snapshotVisitFormFields(){
  const dv = state.draftVisit;
  if(!dv) return null;
  const val = id => { const el = document.getElementById(id); return el ? el.value : undefined; };
  const prescriptions = [];
  document.querySelectorAll('[data-rx-idx]').forEach(row=>{
    const i = Number(row.getAttribute('data-rx-idx'));
    prescriptions[i] = {
      medicine: row.querySelector('[data-f="medicine"]')?.value || '',
      dosage: row.querySelector('[data-f="dosage"]')?.value || '',
      frequency: row.querySelector('[data-f="frequency"]')?.value || '',
      duration: row.querySelector('[data-f="duration"]')?.value || '',
      instructions: row.querySelector('[data-f="instructions"]')?.value || ''
    };
  });
  // Investigations are kept in state via the checklist; still merge any DOM notes if present
  const investigations = (state.draftVisit.investigations||[])
    .filter(r=>r && r.test)
    .map(r=>({test: r.test, notes: r.notes||''}));
  return {
    savedAt: Date.now(),
    patientId: dv.patientId, newPatient: dv.newPatient, editingVisitId: dv.editingVisitId,
    doctorName: val('v-doctor'),
    vitals: { bp: val('v-bp'), pulse: val('v-pulse'), temp: val('v-temp'), weight: val('v-weight'), height: val('v-height') },
    complaints: val('v-complaints'), examination: val('v-exam'),
    diagnosis: val('v-diagnosis'), notes: val('v-notes'), followUpDate: val('v-followup'),
    referredTo: val('v-referred-to'), referralReason: val('v-referral-reason'),
    prescriptions: prescriptions.length ? prescriptions : undefined,
    investigations: investigations.length ? investigations : undefined
  };
}
// True only if the doctor has actually typed/selected something worth
// protecting — an empty or barely-touched form isn't worth remembering,
// and remembering it anyway is exactly what caused the restore prompt to
// appear on every visit to this page, even ones with nothing entered.
function snapshotHasContent(snap){
  if(!snap) return false;
  if(snap.newPatient && (snap.newPatient.name || snap.newPatient.phone)) return true;
  if(snap.complaints || snap.examination || snap.diagnosis || snap.notes) return true;
  if(snap.followUpDate || snap.referredTo || snap.referralReason) return true;
  const v = snap.vitals || {};
  if(v.bp || v.pulse || v.temp || v.weight) return true;
  if((snap.prescriptions||[]).some(r => r && r.medicine)) return true;
  if((snap.investigations||[]).some(r => r && r.test)) return true;
  return false;
}
function autosaveVisitDraft(){
  if(!state.data || !isDoctor() || state.route !== 'newVisit' || !state.draftVisit) return;
  const snap = snapshotVisitFormFields();
  if(!snapshotHasContent(snap)) return;
  try{
    localStorage.setItem(VISIT_DRAFT_KEY, JSON.stringify(snap));
    const ind = document.getElementById('draft-save-indicator');
    if(ind) ind.textContent = `Draft saved on this device at ${new Date(snap.savedAt).toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}`;
  } catch(e){ /* storage unavailable (e.g. private mode) — nothing we can do locally */ }
}
function clearVisitDraftStorage(){
  try{ localStorage.removeItem(VISIT_DRAFT_KEY); } catch(e){}
}
function restoreVisitDraftIfAny(){
  if(!isDoctor()) return;
  let raw;
  try{ raw = localStorage.getItem(VISIT_DRAFT_KEY); } catch(e){ return; }
  if(!raw) return;
  let snap;
  try{ snap = JSON.parse(raw); } catch(e){ clearVisitDraftStorage(); return; }
  if(!snap || !snap.savedAt){ clearVisitDraftStorage(); return; }
  if(!snapshotHasContent(snap)){ clearVisitDraftStorage(); return; } // leftover from before this check existed
  if(Date.now() - snap.savedAt > 24*60*60*1000){ clearVisitDraftStorage(); return; } // stale, don't offer
  const when = new Date(snap.savedAt).toLocaleString('en-IN',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'});
  if(!confirm(`An unsaved consultation draft was found from ${when} (likely from a dropped connection, or the tab closing before it was saved). Restore it into this form?`)){
    clearVisitDraftStorage();
    return;
  }
  const dv = state.draftVisit;
  if(snap.patientId) dv.patientId = snap.patientId;
  if(snap.newPatient) dv.newPatient = snap.newPatient;
  if(snap.doctorName) dv.doctorName = snap.doctorName;
  dv.vitals = Object.assign({}, dv.vitals, snap.vitals||{});
  if(snap.complaints) dv.complaints = snap.complaints;
  if(snap.examination) dv.examination = snap.examination;
  if(snap.diagnosis) dv.diagnosis = snap.diagnosis;
  if(snap.notes) dv.notes = snap.notes;
  if(snap.followUpDate) dv.followUpDate = snap.followUpDate;
  if(snap.referredTo) dv.referredTo = snap.referredTo;
  if(snap.referralReason) dv.referralReason = snap.referralReason;
  if(snap.prescriptions && snap.prescriptions.length) dv.prescriptions = snap.prescriptions.map(r=>({medicine:'',dosage:'',frequency:'',duration:'',instructions:'',...r}));
  if(snap.investigations && snap.investigations.length) dv.investigations = snap.investigations.map(r=>({test:'',notes:'',...r}));
}
function cancelVisitFlow(){
  clearVisitDraftStorage();
  go(state.routeParams.patientId?'patient':'patients', state.routeParams.patientId?{patientId:state.routeParams.patientId}:{});
}
// Checked every 10s — cheap no-op unless a doctor has the visit form open.
setInterval(autosaveVisitDraft, 10000);

function onVisitPatientSearch(v){
  state.search = v;
  const el = document.getElementById('visit-patient-results');
  if(el) el.innerHTML = visitPatientResultsHTML();
}

function selectPatientForVisit(id){
  state.draftVisit.patientId = id;
  state.draftVisit.newPatient = null;
  state.search = '';
  render();
}

function addRxRow(){
  state.draftVisit.prescriptions.push({medicine:'',dosage:'',frequency:'',duration:'',instructions:''});
  document.getElementById('rx-rows').innerHTML = rxRowsHTML();
  refreshRxSafetySummary();
}
function removeRxRow(i){
  state.draftVisit.prescriptions.splice(i,1);
  if(state.draftVisit.prescriptions.length===0) state.draftVisit.prescriptions.push({medicine:'',dosage:'',frequency:'',duration:'',instructions:''});
  document.getElementById('rx-rows').innerHTML = rxRowsHTML();
  refreshRxSafetySummary();
}
function addInvRow(){
  // Legacy — checklist uses toggleInvCheck / addCustomInv
  const box = document.getElementById('inv-rows');
  if(box) box.innerHTML = invRowsHTML();
}
function removeInvRow(i){
  if(state.draftVisit.investigations[i]) state.draftVisit.investigations.splice(i,1);
  const box = document.getElementById('inv-rows');
  if(box) box.innerHTML = invRowsHTML();
}

/* ============================= PRESCRIPTION TEMPLATES ============================= */
// A named, reusable bundle of medicines + investigations (e.g. "Standard
// viral fever Rx") — saved from a visit in progress, applied into any
// later one so a repeat combination doesn't need retyping.
function applyRxTemplate(){
  const sel = document.getElementById('rx-template-select');
  if(!sel || sel.value==='') return;
  const t = (state.data.rxTemplates||[])[Number(sel.value)];
  if(!t) return;
  const dv = state.draftVisit;
  const rxIsBlank = dv.prescriptions.length===1 && !dv.prescriptions[0].medicine;
  const invIsBlank = dv.investigations.length===1 && !dv.investigations[0].test;
  dv.prescriptions = (rxIsBlank ? [] : dv.prescriptions).concat((t.prescriptions||[]).map(r=>({...r})));
  dv.investigations = (invIsBlank ? [] : dv.investigations).concat((t.investigations||[]).map(r=>({...r})));
  if(!dv.prescriptions.length) dv.prescriptions = [{medicine:'',dosage:'',frequency:'',duration:'',instructions:''}];
  dv.investigations = (dv.investigations||[]).filter(r=>r && r.test);
  document.getElementById('rx-rows').innerHTML = rxRowsHTML();
  document.getElementById('inv-rows').innerHTML = invRowsHTML();
}
async function saveCurrentAsTemplate(){
  const dv = state.draftVisit;
  // Pull the latest typed values off the DOM first, same as saveVisit() does.
  document.querySelectorAll('[data-rx-idx]').forEach(row=>{
    const i = Number(row.getAttribute('data-rx-idx'));
    dv.prescriptions[i] = {
      medicine: row.querySelector('[data-f="medicine"]').value.trim(),
      dosage: row.querySelector('[data-f="dosage"]').value.trim(),
      frequency: row.querySelector('[data-f="frequency"]').value.trim(),
      duration: row.querySelector('[data-f="duration"]').value.trim(),
      instructions: row.querySelector('[data-f="instructions"]').value.trim()
    };
  });
  // Checklist keeps investigations in state; ensure notes from selected rows are current
  dv.investigations = (dv.investigations||[]).filter(r=>r && r.test).map(r=>({test:r.test, notes:(r.notes||'').trim()}));
  const prescriptions = dv.prescriptions.filter(r=>r.medicine);
  const investigations = dv.investigations.filter(r=>r.test);
  if(!prescriptions.length && !investigations.length){
    alert('Add at least one medicine or test before saving it as a template.');
    return;
  }
  const name = prompt('Name this template (e.g. "Standard viral fever Rx"):');
  if(!name || !name.trim()) return;
  if(!state.data.rxTemplates) state.data.rxTemplates = [];
  state.data.rxTemplates.push({
    id: 'RXT'+Date.now().toString(36).toUpperCase(),
    name: name.trim(), prescriptions, investigations, createdAt: new Date().toISOString()
  });
  logAudit('Saved prescription template', `${name.trim()} — ${prescriptions.length} medicine(s), ${investigations.length} test(s)`);
  const ok = await saveData();
  if(!ok){ alert(state.saveError || 'Could not save the template — try again.'); return; }
  render();
}
async function removeRxTemplate(idx){
  const t = (state.data.rxTemplates||[])[idx];
  if(!t) return;
  if(!confirm(`Remove the "${t.name}" template?`)) return;
  state.data.rxTemplates.splice(idx,1);
  logAudit('Removed prescription template', t.name);
  await saveData();
  render();
}

async function saveVisit(){
  const dv = state.draftVisit;
  const val = id => { const el = document.getElementById(id); return el ? el.value.trim() : null; };
  // These fields only exist in the doctor's full form — on the receptionist's
  // check-in form they're simply absent, so dv keeps its existing (blank) values.
  if(document.getElementById('v-doctor') !== null){
    dv.doctorName = val('v-doctor');
    dv.complaints = val('v-complaints');
    dv.examination = val('v-exam');
    dv.diagnosis = val('v-diagnosis');
    dv.notes = val('v-notes');
    dv.followUpDate = val('v-followup');
    dv.referredTo = val('v-referred-to');
    dv.referralReason = val('v-referral-reason');
    dv.vitals.bp = val('v-bp');
    dv.vitals.pulse = val('v-pulse');
    dv.vitals.temp = val('v-temp');
    dv.vitals.weight = val('v-weight');
    if(document.getElementById('v-height')) dv.vitals.height = val('v-height');
  }
  if(document.getElementById('v-assigned-doctor') !== null){
    dv.assignedDoctor = val('v-assigned-doctor');
  }

  document.querySelectorAll('[data-rx-idx]').forEach(row=>{
    const i = Number(row.getAttribute('data-rx-idx'));
    dv.prescriptions[i] = {
      medicine: row.querySelector('[data-f="medicine"]').value.trim(),
      dosage: row.querySelector('[data-f="dosage"]').value.trim(),
      frequency: row.querySelector('[data-f="frequency"]').value.trim(),
      duration: row.querySelector('[data-f="duration"]').value.trim(),
      instructions: row.querySelector('[data-f="instructions"]').value.trim()
    };
  });
  // Checklist keeps investigations in state; ensure notes from selected rows are current
  dv.investigations = (dv.investigations||[]).filter(r=>r && r.test).map(r=>({test:r.test, notes:(r.notes||'').trim()}));

  const errEl = document.getElementById('visit-error');
  if(!dv.patientId && !dv.newPatient){
    errEl.textContent = 'Select an existing patient or register a new one.'; return;
  }
  if(dv.newPatient){
    dv.newPatient.name = document.getElementById('np-name').value.trim();
    dv.newPatient.dob = document.getElementById('np-dob').value;
    dv.newPatient.age = document.getElementById('np-age').value.trim();
    dv.newPatient.sex = document.getElementById('np-sex').value;
    dv.newPatient.phone = document.getElementById('np-phone').value.trim();
    dv.newPatient.address = document.getElementById('np-address').value.trim();
    dv.newPatient.allergies = document.getElementById('np-allergies') ? document.getElementById('np-allergies').value.trim() : '';
    dv.newPatient.chronicIllness = document.getElementById('np-chronic') ? document.getElementById('np-chronic').value.trim() : '';
    if(!dv.newPatient.name || (!dv.newPatient.dob && !dv.newPatient.age) || !dv.newPatient.sex || !dv.newPatient.phone || !dv.newPatient.address){
      errEl.textContent = 'New patient needs name, date of birth (or age), sex, phone and address.'; return;
    }
  } else if(dv.patientId){
    // Existing patient linked to this visit — their record should already
    // have these from registration. Skipped for a patient whose personal
    // details were deliberately cleared (see "Clear personal details"),
    // since blocking new visits for them would defeat that feature's point.
    const existingPatient = state.data.patients.find(p=>p.id===dv.patientId);
    if(existingPatient && !existingPatient.detailsRedacted){
      if(!existingPatient.name || (!existingPatient.dob && !existingPatient.age) || !existingPatient.sex || !existingPatient.phone || !existingPatient.address){
        errEl.textContent = `${existingPatient.name||'This patient'}'s record is missing some details (name, date of birth/age, sex, phone or address) — fill these in via "Edit details" on their patient page before saving a visit.`;
        return;
      }
    }
  }
  if(document.getElementById('v-doctor') !== null){
    if(!dv.vitals.bp || !dv.vitals.pulse || !dv.vitals.temp || !dv.vitals.weight){
      errEl.textContent = 'BP, pulse, temperature and weight are all required before saving.'; return;
    }
  }
  errEl.textContent = '';

  const prescriptions = dv.prescriptions.filter(r=>r.medicine);
  const investigations = dv.investigations.filter(r=>r.test);
  const status = dv.diagnosis ? 'completed' : 'waiting';

  if(document.getElementById('v-doctor') !== null && prescriptions.length){
    const allergyHits = collectVisitAllergyHits(prescriptions);
    const interactions = findDrugInteractions(prescriptions);
    if(allergyHits.length || interactions.length){
      const lines = [
        ...allergyHits.map(h=>`• ${h.medicine} vs listed allergy “${h.allergy}”`),
        ...interactions.map(w=>'• '+w)
      ];
      const okSafety = confirm(
        'Safety check — please confirm before saving this prescription:\n\n'
        + lines.join('\n')
        + '\n\nThis is a prompt only, not a clinical guarantee. Save anyway?'
      );
      if(!okSafety) return;
    }
  }

  let patient;
  if(dv.newPatient){
    patient = {
      id: newPatientId(), name: dv.newPatient.name, dob: dv.newPatient.dob||'', age: dv.newPatient.age, sex: dv.newPatient.sex,
      phone: dv.newPatient.phone, address: dv.newPatient.address, allergies: dv.newPatient.allergies||'', chronicIllness: dv.newPatient.chronicIllness||'',
      registeredDate: todayStr(), visits: [], growthRecords: [], vaccinations: []
    };
    state.data.patients.push(patient);
  } else {
    patient = state.data.patients.find(p=>p.id===dv.patientId);
  }

  let visit = dv.editingVisitId ? (patient.visits||[]).find(v=>v.id===dv.editingVisitId) : null;
  const wasExisting = !!visit;
  if(visit){
    // Continuing a visit the receptionist started — update in place, keep
    // the original id/date/time.
    visit.doctorName = dv.doctorName;
    visit.vitals = dv.vitals;
    visit.complaints = dv.complaints;
    visit.examination = dv.examination;
    visit.diagnosis = dv.diagnosis;
    visit.notes = dv.notes;
    visit.followUpDate = dv.followUpDate;
    visit.referredTo = dv.referredTo; visit.referralReason = dv.referralReason;
    visit.assignedDoctor = dv.assignedDoctor;
    visit.prescriptions = prescriptions;
    visit.investigations = investigations;
    visit.status = status;
  } else {
    visit = {
      id: newVisitId(), token: nextTokenNumber(), date: todayStr(), time: nowTimeStr(),
      doctorName: dv.doctorName, vitals: dv.vitals,
      complaints: dv.complaints, examination: dv.examination, diagnosis: dv.diagnosis, notes: dv.notes,
      followUpDate: dv.followUpDate, assignedDoctor: dv.assignedDoctor||'',
      referredTo: dv.referredTo||'', referralReason: dv.referralReason||'',
      prescriptions, investigations, status,
      billing: { fee:'', charges:[], paid:false, mode:'' }
    };
    patient.visits.unshift(visit);
  }
  logAudit(wasExisting ? 'Updated visit' : 'Recorded visit', `${patient.name} (${patient.id}) — ${fmtDate(visit.date)}${visit.doctorName?' · '+visit.doctorName:''}`);
  const ok = await saveData();
  if(!ok){ errEl.textContent = state.saveError; render(); return; }
  clearVisitDraftStorage();
  if(isDoctor()){
    go('visitPrint', {patientId: patient.id, visitId: visit.id});
  } else {
    go('dashboard');
  }
}

/* ============================= PRINT ============================= */
function printSection(id){
  document.querySelectorAll('.print-sheet').forEach(el=>el.classList.remove('print-active'));
  const el = document.getElementById(id);
  if(el){ el.classList.add('print-active'); window.print(); }
}

/* ============================= SETTINGS ============================= */
async function saveClinicInfo(){
  state.data.clinicInfo.name = document.getElementById('ci-name').value.trim() || state.data.clinicInfo.name;
  state.data.clinicInfo.address = document.getElementById('ci-address').value.trim();
  state.data.clinicInfo.phone = document.getElementById('ci-phone').value.trim();
  logAudit('Updated clinic info', state.data.clinicInfo.name);
  await saveData();
  render();
}
function onClinicLogoFile(file){
  if(!file) return;
  if(file.size > 500 * 1024){
    alert('Please choose an image under 500 KB.');
    return;
  }
  const reader = new FileReader();
  reader.onload = async ()=>{
    state.data.clinicInfo.logo = String(reader.result||'');
    logAudit('Updated clinic logo', state.data.clinicInfo.name);
    await saveData();
    render();
  };
  reader.readAsDataURL(file);
}
async function clearClinicLogo(){
  state.data.clinicInfo.logo = '';
  logAudit('Removed clinic logo', state.data.clinicInfo.name);
  await saveData();
  render();
}

function downloadTextFile(filename, text, mime){
  const blob = new Blob([text], {type: mime||'text/plain'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}
function csvEscape(s){
  const t = String(s==null?'':s);
  if(/[",\n]/.test(t)) return '"'+t.replace(/"/g,'""')+'"';
  return t;
}
function exportPatientsCSV(){
  const rows = [['ID','Name','DOB','Age','Sex','Phone','Address','Allergies','ChronicIllness','Registered']];
  (state.data.patients||[]).forEach(p=>{
    rows.push([p.id,p.name,p.dob||'',displayAge(p),p.sex||'',p.phone||'',p.address||'',p.allergies||'',p.chronicIllness||'',p.registeredDate||'']);
  });
  const csv = rows.map(r=>r.map(csvEscape).join(',')).join('\n');
  downloadTextFile('MMC-patients-'+todayStr()+'.csv', csv, 'text/csv');
  logAudit('Exported patients CSV', rows.length-1+' patients');
}
function exportVisitsCSV(){
  const rows = [['PatientID','PatientName','VisitID','Token','Date','Time','Doctor','Diagnosis','Complaints','Status','FollowUp']];
  (state.data.patients||[]).forEach(p=>{
    (p.visits||[]).forEach(v=>{
      rows.push([p.id,p.name,v.id,v.token!=null?v.token:'',v.date||'',v.time||'',v.doctorName||'',v.diagnosis||'',v.complaints||'',visitStatus(v),v.followUpDate||'']);
    });
  });
  const csv = rows.map(r=>r.map(csvEscape).join(',')).join('\n');
  downloadTextFile('MMC-visits-'+todayStr()+'.csv', csv, 'text/csv');
  logAudit('Exported visits CSV', rows.length-1+' visits');
}

function downloadBackup(){
  const blob = new Blob([JSON.stringify(state.data, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `mmc-clinic-backup-${todayStr()}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
async function restoreBackup(file){
  const msg = document.getElementById('restore-msg');
  if(!file) return;
  if(!confirm('This will replace every patient, visit, appointment and staff record currently in the system with the contents of this backup file. This cannot be undone. Continue?')){
    document.getElementById('restore-file-input').value = '';
    return;
  }
  try{
    const text = await file.text();
    const parsed = JSON.parse(text);
    if(!parsed || !Array.isArray(parsed.patients) || !Array.isArray(parsed.staff)){
      throw new Error('not a clinic backup file');
    }
    const restored = Object.assign(defaultData(), parsed);
    const restoredBy = state.session.staffName || 'System';
    state.data = restored;
    logAudit('Restored data from backup', `File: ${file.name}`, restoredBy);
    const ok = await saveData();
    document.getElementById('restore-file-input').value = '';
    if(!ok){ msg.textContent = state.saveError || 'Could not save the restored data — try again.'; return; }
    msg.textContent = '';
    // The logged-in staff account may not exist in the restored data.
    if(!state.data.staff.some(s=>s.name===state.session.staffName)){
      state.session.staffName = null;
      clearSessionStorage();
    }
    render();
  } catch(e){
    document.getElementById('restore-file-input').value = '';
    msg.textContent = "Couldn't read that file — make sure it's an MMC backup JSON file.";
  }
}
async function addStaff(){
  if(!isOwner()){ alert('Only the clinic admin can add staff accounts.'); return; }
  const name = document.getElementById('st-name').value.trim();
  const role = document.getElementById('st-role').value;
  const pin = document.getElementById('st-pin').value.trim();
  const qualification = (document.getElementById('st-qualification')||{}).value.trim() || '';
  const err = document.getElementById('st-error');
  if(!name || !/^\d{4}$/.test(pin)){ err.textContent = 'Enter a name and a 4-digit PIN.'; return; }
  if(state.data.staff.some(s=>s.name===name)){ err.textContent = 'That name is already registered.'; return; }
  state.data.staff.push({name, role, pin: await hashPin(pin), qualification, owner: false});
  logAudit('Added staff account', `${name} (${role})${qualification?' · '+qualification:''}`);
  await saveData();
  render();
}
async function editStaffQualification(name){
  if(!isOwner()){ alert('Only the clinic admin can edit staff profiles.'); return; }
  const s = state.data.staff.find(s=>s.name===name);
  if(!s) return;
  const entered = prompt(`Qualification / course for ${name} (e.g. M.B.B.S., M.D. Paediatrics):`, s.qualification || '');
  if(entered === null) return;
  s.qualification = entered.trim();
  logAudit('Updated staff qualification', `${name}: ${s.qualification||'(cleared)'}`);
  await saveData();
  render();
}
async function removeStaff(name){
  if(!isOwner()){ alert('Only the clinic admin can remove staff accounts.'); return; }
  if(name === state.session.staffName){ return; }
  const target = state.data.staff.find(s=>s.name===name);
  if(target && target.owner){ alert('Cannot remove the clinic admin account.'); return; }
  if(!confirm(`Remove staff account "${name}"? They will no longer be able to log in.`)) return;
  state.data.staff = state.data.staff.filter(s=>s.name!==name);
  logAudit('Removed staff account', name);
  await saveData();
  render();
}
// Renaming isn't offered here: a staff name is used as the identifying key
// throughout visits, appointments and the audit log, so changing it would
// orphan that history. Role and PIN are safe to change in place (admin only).
async function changeStaffRole(name){
  if(!isOwner()){ alert('Only the clinic admin can change staff roles.'); return; }
  const s = state.data.staff.find(s=>s.name===name);
  if(!s) return;
  const roles = ['Doctor','Receptionist','Staff'];
  const entered = prompt(`New role for ${name} (${roles.join(' / ')}):`, s.role);
  if(entered === null) return;
  const role = roles.find(r=>r.toLowerCase()===entered.trim().toLowerCase());
  if(!role){ alert(`Role must be one of: ${roles.join(', ')}`); return; }
  if(role === s.role) return;
  const oldRole = s.role;
  s.role = role;
  logAudit('Changed staff role', `${name}: ${oldRole} → ${role}`);
  await saveData();
  render();
}
async function resetStaffPin(name){
  if(!isOwner()){ alert('Only the clinic admin can reset staff PINs.'); return; }
  const s = state.data.staff.find(s=>s.name===name);
  if(!s) return;
  const entered = prompt(`New 4-digit PIN for ${name}:`);
  if(entered === null) return;
  const pin = entered.trim();
  if(!/^\d{4}$/.test(pin)){ alert('PIN must be exactly 4 digits.'); return; }
  s.pin = await hashPin(pin);
  logAudit('Reset staff PIN', name);
  await saveData();
  render();
}
async function saveStaffProfileEdit(name){
  if(!isOwner()){ alert('Only the clinic admin can edit staff profiles.'); return; }
  const s = state.data.staff.find(s=>s.name===name);
  if(!s) return;
  const qualEl = document.getElementById('edit-st-qualification');
  const roleEl = document.getElementById('edit-st-role');
  if(qualEl) s.qualification = qualEl.value.trim();
  if(roleEl){
    const roles = ['Doctor','Receptionist','Staff'];
    if(roles.includes(roleEl.value)) s.role = roleEl.value;
  }
  state.ui.editingStaffName = null;
  logAudit('Updated staff profile', `${name}${s.qualification?' · '+s.qualification:''}`);
  await saveData();
  render();
}
function startEditStaffProfile(name){
  if(!isOwner()){ alert('Only the clinic admin can edit staff profiles.'); return; }
  state.ui.editingStaffName = name;
  render();
}
function cancelEditStaffProfile(){
  state.ui.editingStaffName = null;
  render();
}
function onResetConfirmInput(v){
  state.ui.resetConfirmText = v;
  document.getElementById('reset-btn').disabled = (v !== 'RESET');
}
async function doReset(){
  if(state.ui.resetConfirmText !== 'RESET') return;
  state.data = defaultData();
  state.session.staffName = null;
  await saveData();
  state.ui.resetConfirmText = '';
  go('dashboard');
}

/* ============================= VIEWS ============================= */
function loadingView(){
  return `<div class="center-screen"><p class="muted">Loading clinic records…</p></div>`;
}

function setupView(){
  return `
  <div class="center-screen">
    <div class="auth-card">
      <div class="auth-brand">
        <div class="brand-mark">MMC</div>
        <h1 style="font-size:19px;">Set up ${esc(state.data.clinicInfo.name)}</h1>
        <p class="muted" style="font-size:13px;">Create the first staff account to start using the clinic system.</p>
      </div>
      <div class="field"><label>Your name</label><input id="setup-name" type="text" placeholder="e.g. Dr. Ravi"></div>
      <div class="field"><label>Role</label>
        <select id="setup-role"><option>Doctor</option><option>Receptionist</option><option>Staff</option></select>
      </div>
      <div class="field"><label>Choose a 4-digit PIN</label><input id="setup-pin" type="password" inputmode="numeric" maxlength="4" placeholder="••••"></div>
      <div id="setup-error" class="error-text"></div>
      <button class="btn btn-primary btn-block" onclick="doSetup()">Create account &amp; start</button>
    </div>
  </div>`;
}

function loginView(){
  const selectedName = state.loginSelectedName || (state.data.staff[0] && state.data.staff[0].name) || '';
  const lock = pinLockStatus(selectedName);
  const staffOptions = state.data.staff.map(s=>`<option value="${esc(s.name)}" ${s.name===selectedName?'selected':''}>${esc(s.name)} — ${esc(s.role)}</option>`).join('');
  if(state.loginMode === 'addFromLogin'){
    return `
    <div class="center-screen">
      <div class="auth-card">
        <div class="auth-brand"><div class="brand-mark">MMC</div><h1 style="font-size:19px;">New staff account</h1></div>
        <div class="field"><label>Name</label><input id="als-name" type="text"></div>
        <div class="field"><label>Role</label><select id="als-role"><option>Doctor</option><option>Receptionist</option><option>Staff</option></select></div>
        <div class="field"><label>4-digit PIN</label><input id="als-pin" type="password" inputmode="numeric" maxlength="4"></div>
        <div id="als-error" class="error-text"></div>
        <button class="btn btn-primary btn-block" onclick="addStaffFromLogin()">Add account</button>
        <button class="btn btn-ghost btn-block" style="margin-top:6px;" onclick="toggleAddFromLogin()">Back to log in</button>
      </div>
    </div>`;
  }
  return `
  <div class="center-screen">
    <div class="auth-card">
      <div class="auth-brand">
        <div class="brand-mark">MMC</div>
        <h1 style="font-size:19px;">${esc(state.data.clinicInfo.name)}</h1>
        <p class="muted" style="font-size:13px;">Log in to continue</p>
      </div>
      <div class="field"><label>Staff</label><select id="login-select" onchange="onLoginStaffChange(this.value)">${staffOptions}</select></div>
      <div class="field"><label>PIN</label><input id="login-pin" type="password" inputmode="numeric" maxlength="4" placeholder="••••" ${lock.locked?'disabled':''}></div>
      ${state.loginError ? `<div class="error-text">${esc(state.loginError)}</div>` : ''}
      <button class="btn btn-primary btn-block" ${lock.locked?'disabled':''} onclick="doLogin()">Log in</button>
      <button class="btn btn-ghost btn-block" style="margin-top:6px;" onclick="toggleAddFromLogin()">+ Add a staff account</button>
      ${state.data.demoSeeded ? `<div class="banner banner-info" style="text-align:left;margin-top:14px;font-size:12.5px;"><strong>Sample clinic ready</strong><br>Doctor — Dr. R. Sharma · PIN 1234<br>Reception — Priya N. · PIN 1234</div>` : ''}
      <p class="faint" style="text-align:center;margin-top:14px;">Forgot your PIN? Ask another staff member to reset it from Settings → Staff accounts.</p>
    </div>
  </div>`;
}

function shellView(){
  const items = [
    ['dashboard','Dashboard'],
    ['appointments','Appointments'],
    ['patients','Patients'],
    ['newVisit', isDoctor() ? 'New OPD Visit' : 'Check In Patient']
  ];
  if(isDoctor()) items.push(['pediatrics','Pediatrics']);
  items.push(['billing','Billing']);
  items.push(['certificates','Certificates']);
  items.push(['reports','Reports']);
  items.push(['settings','Settings']);
  const nav = items.map(([r,label])=>
    `<button class="nav-item ${state.route===r?'active':''}" onclick="go('${r}')">${label}</button>`
  ).join('');
  const staff = state.data.staff.find(s=>s.name===state.session.staffName);
  return `
  <div class="shell">
    <div class="sidebar">
      <div class="brand">
        <div class="brand-mark">MMC</div>
        <div class="brand-text"><div class="full">Male Madeshwara Clinic</div><div class="sub">Clinic system</div></div>
      </div>
      <div class="nav">${nav}</div>
      <div class="sidebar-foot">
        <div class="staff-chip"><strong>${esc(state.session.staffName)}</strong>${staff?esc(staff.role):''}</div>
        <button class="nav-item" onclick="logout()">Log out</button>
      </div>
    </div>
    <div class="main">
      ${state.saveError ? `<div class="banner banner-error">${esc(state.saveError)}</div>` : ''}
      ${routeContent()}
    </div>
  </div>`;
}

function routeContent(){
  switch(state.route){
    case 'appointments': return appointmentsView();
    case 'newAppointment': return newAppointmentView();
    case 'patients': return patientsView();
    case 'newPatient': return newPatientView();
    case 'patient': return patientView(state.routeParams.patientId);
    case 'newVisit': return newVisitView();
    case 'visitPrint': return visitPrintView(state.routeParams.patientId, state.routeParams.visitId);
    case 'settings': return settingsView();
    case 'pediatrics': return pediatricsView();
    case 'billing': return billingView();
    case 'billingDetail': return billingDetailView(state.routeParams.patientId, state.routeParams.visitId);
    case 'certificates': return certificatesView();
    case 'reports': return reportsView();
    case 'mergePatients': return mergePatientsView();
    case 'auditLog': return auditLogView();
    default: return dashboardView();
  }
}

function dashboardView(){
  const today = todayStr();
  const todaysVisits = [];
  const waitingVisits = [];
  const followUps = [];
  state.data.patients.forEach(p=>{
    (p.visits||[]).forEach(v=>{
      if(v.date===today) todaysVisits.push({patient:p, visit:v});
      if(visitStatus(v)==='waiting' && (!isDoctor() || !v.assignedDoctor || v.assignedDoctor===state.session.staffName)) waitingVisits.push({patient:p, visit:v});
      if(v.followUpDate && v.followUpDate<=today) followUps.push({patient:p, visit:v});
    });
  });
  todaysVisits.sort((a,b)=> (b.visit.time||'').localeCompare(a.visit.time||''));
  waitingVisits.sort((a,b)=> (b.visit.date+b.visit.time).localeCompare(a.visit.date+a.visit.time));
  followUps.sort((a,b)=> a.visit.followUpDate.localeCompare(b.visit.followUpDate));

  const showClinical = isDoctor();
  const myVisitsOnly = isDoctor() && state.dashboardMineOnly;
  const shownTodaysVisits = myVisitsOnly ? todaysVisits.filter(({visit})=> visit.doctorName===state.session.staffName) : todaysVisits;
  const rows = shownTodaysVisits.map(({patient,visit})=>`
    <tr class="clickable" onclick="go('visitPrint',{patientId:'${patient.id}',visitId:'${visit.id}'})">
      <td>${visit.time||''}</td>
      <td>${esc(patient.name)} <span class="faint">${patient.id}</span></td>
      <td>${showClinical ? (esc(visit.diagnosis)||'<span class="faint">—</span>') : `<span class="pill">${visitStatus(visit)==='waiting'?'Waiting':'Completed'}</span>`}</td>
      <td>${esc(visit.doctorName)}</td>
    </tr>`).join('');

  // Queue sorted by token (then time) so the board matches the waiting room
  waitingVisits.sort((a,b)=>{
    const ta = a.visit.token||9999, tb = b.visit.token||9999;
    if(ta!==tb) return ta-tb;
    return (a.visit.time||'').localeCompare(b.visit.time||'');
  });
  const waitingRows = waitingVisits.map(({patient,visit})=>`
    <tr>
      <td style="font-size:20px;font-weight:700;color:var(--primary-dark);width:56px;">${visit.token!=null?visit.token:'—'}</td>
      <td>${esc(patient.name)} <span class="pill">${patient.id}</span>${visit.assignedDoctor?` <span class="faint">for ${esc(visit.assignedDoctor)}</span>`:''}</td>
      <td>${fmtDate(visit.date)} ${visit.time||''}</td>
      <td>${showClinical ? (esc(visit.complaints)||'<span class="faint">—</span>') : '<span class="faint">—</span>'}</td>
      <td>${isDoctor()
        ? `<button class="btn btn-sm btn-accent" onclick="go('newVisit',{patientId:'${patient.id}',editVisitId:'${visit.id}'})">Continue</button>`
        : '<span class="faint">Waiting for doctor</span>'}</td>
    </tr>`).join('');

  const followUpRows = followUps.map(({patient,visit})=>`
    <tr>
      <td>${esc(patient.name)} <span class="pill">${patient.id}</span></td>
      <td>${fmtDate(visit.followUpDate)}${visit.followUpDate<today?' <span class="faint">(overdue)</span>':''}</td>
      <td>${esc(visit.diagnosis)||'<span class="faint">—</span>'}</td>
      <td>
        <button class="btn btn-sm" onclick="go('newVisit',{patientId:'${patient.id}',editVisitId:'${visit.id}'})">Open</button>
        <button class="btn btn-ghost btn-sm" onclick="markFollowUpDone('${patient.id}','${visit.id}')">Mark done</button>
      </td>
    </tr>`).join('');
  const followUpCard = isDoctor() ? `
    <div class="card" style="margin-bottom:18px;">
      <h2 style="margin-bottom:10px;">Follow-ups due</h2>
      ${followUps.length ? `<table><thead><tr><th>Patient</th><th>Due</th><th>Diagnosis</th><th></th></tr></thead><tbody>${followUpRows}</tbody></table>`
        : `<p class="muted">No follow-ups due.</p>`}
    </div>` : '';

  return `
    <div class="page-head">
      <div><h1>Dashboard</h1><p class="muted">${fmtDate(today)}</p></div>
      <div class="row" style="gap:8px;">
        <button class="btn" onclick="go('appointments')">📅 Appointments</button>
        <button class="btn btn-accent" onclick="go('newVisit')">+ New OPD Visit</button>
      </div>
    </div>
    <div class="stat-grid">
      <div class="stat-card"><div class="stat-num">${state.data.patients.length}</div><div class="stat-label">Total patients</div></div>
      <div class="stat-card"><div class="stat-num">${todaysVisits.length}</div><div class="stat-label">Visits today</div></div>
      <div class="stat-card"><div class="stat-num">${waitingVisits.length}</div><div class="stat-label">Waiting for doctor</div></div>
      <div class="stat-card"><div class="stat-num">${appointmentsForDate(today).filter(a=>a.status==='booked').length}</div><div class="stat-label">Appointments booked today</div></div>
    </div>
    <div class="card" style="margin-bottom:18px;">
      <h2 style="margin-bottom:10px;">Waiting for doctor</h2>
      ${waitingVisits.length ? `<table><thead><tr><th>Token</th><th>Patient</th><th>Registered</th><th>Complaints</th><th></th></tr></thead><tbody>${waitingRows}</tbody></table>`
        : `<p class="muted">No patients waiting right now.</p>`}
    </div>
    ${followUpCard}
    <div class="card">
      <div class="rx-row-head" style="margin-bottom:10px;">
        <h2>Today's visits</h2>
        ${isDoctor() ? `<div class="row" style="gap:6px;">
          <button class="btn btn-sm ${!state.dashboardMineOnly?'btn-primary':''}" onclick="toggleDashboardMineOnly(false)">All doctors</button>
          <button class="btn btn-sm ${state.dashboardMineOnly?'btn-primary':''}" onclick="toggleDashboardMineOnly(true)">My patients</button>
        </div>` : ''}
      </div>
      ${shownTodaysVisits.length ? `<table><thead><tr><th>Time</th><th>Patient</th><th>Diagnosis</th><th>Doctor</th></tr></thead><tbody>${rows}</tbody></table>`
        : `<p class="muted">${myVisitsOnly ? 'No visits of yours recorded yet today.' : 'No visits recorded yet today.'}</p>`}
    </div>`;
}
function toggleDashboardMineOnly(v){ state.dashboardMineOnly = v; render(); }
async function markFollowUpDone(patientId, visitId){
  const p = state.data.patients.find(p=>p.id===patientId);
  const v = p && (p.visits||[]).find(v=>v.id===visitId);
  if(!v) return;
  v.followUpDate = '';
  await saveData();
  render();
}

function patientsTableHTML(){
  const list = filteredPatients();
  if(list.length===0) return `<p class="muted" style="padding:8px 0;">No patients match your search.</p>`;
  const rows = list.map(p=>{
    const lv = lastVisitDate(p);
    return `<tr class="clickable" onclick="go('patient',{patientId:'${p.id}'})">
      <td><span class="pill">${p.id}</span></td>
      <td>${esc(p.name)}</td>
      <td>${esc(displayAge(p))} / ${esc(p.sex)}</td>
      <td>${esc(p.phone)||'<span class="faint">—</span>'}</td>
      <td>${lv?fmtDate(lv):'<span class="faint">No visits</span>'}</td>
    </tr>`;
  }).join('');
  return `<table><thead><tr><th>ID</th><th>Name</th><th>Age/Sex</th><th>Phone</th><th>Last visit</th></tr></thead><tbody>${rows}</tbody></table>`;
}

function patientsView(){
  return `
    <div class="page-head">
      <div><h1>Patients</h1><p class="muted">${state.data.patients.length} registered</p></div>
      <div class="row">
        ${isDoctor() ? `<button class="btn btn-ghost" onclick="go('mergePatients')">🔗 Merge duplicates</button>` : ''}
        <button class="btn btn-accent" onclick="go('newPatient')">+ New Patient</button>
      </div>
    </div>
    <div class="card">
      <div class="search-wrap" style="margin-bottom:14px;">
        <input type="text" placeholder="Search by name, ID or phone" value="${esc(state.search)}" oninput="onPatientSearchInput(this.value)">
      </div>
      <div id="patients-table-container">${patientsTableHTML()}</div>
    </div>`;
}

/* ============================= MERGE PATIENTS ============================= */
function initMergeUI(){
  state.mergeUI = { aId: null, bId: null, searchA: '', searchB: '', choices: {} };
}
function mergeSearchResultsHTML(side){
  const mu = state.mergeUI;
  const q = (side==='A' ? mu.searchA : mu.searchB).trim().toLowerCase();
  if(!q) return '';
  const excludeId = side==='A' ? mu.bId : mu.aId;
  const matches = state.data.patients.filter(p=>
    p.id!==excludeId && (p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q) || (p.phone||'').includes(q))
  ).slice(0,6);
  if(!matches.length) return `<p class="faint">No matches.</p>`;
  return matches.map(p=>
    `<div class="chip" style="display:block;width:fit-content;margin-bottom:4px;" onmousedown="selectMergePatient('${side}','${p.id}')">${esc(p.name)} — ${p.id}${p.phone?(' · '+esc(p.phone)):''}</div>`
  ).join('');
}
function onMergeSearchInput(side, v){
  if(side==='A') state.mergeUI.searchA = v; else state.mergeUI.searchB = v;
  const el = document.getElementById('merge-results-'+side);
  if(el) el.innerHTML = mergeSearchResultsHTML(side);
}
function selectMergePatient(side, id){
  if(side==='A') state.mergeUI.aId = id; else state.mergeUI.bId = id;
  state.mergeUI.choices = {}; // field picks reset whenever either side changes
  render();
}
function clearMergeSlot(side){
  if(side==='A') state.mergeUI.aId = null; else state.mergeUI.bId = null;
  render();
}
function mergeFieldRow(field, label, valA, valB){
  const choice = state.mergeUI.choices[field] || 'A';
  return `
    <div class="row" style="align-items:flex-start;border-bottom:1px solid var(--line);padding:8px 0;margin:0;">
      <div style="width:110px;flex:none;"><strong style="font-size:12.5px;">${esc(label)}</strong></div>
      <label style="flex:1;display:flex;gap:6px;align-items:flex-start;cursor:pointer;">
        <input type="radio" name="mf-${field}" ${choice==='A'?'checked':''} onchange="state.mergeUI.choices['${field}']='A'">
        <span>${esc(valA) || '<span class="faint">—</span>'}</span>
      </label>
      <label style="flex:1;display:flex;gap:6px;align-items:flex-start;cursor:pointer;">
        <input type="radio" name="mf-${field}" ${choice==='B'?'checked':''} onchange="state.mergeUI.choices['${field}']='B'">
        <span>${esc(valB) || '<span class="faint">—</span>'}</span>
      </label>
    </div>`;
}
function mergeCompareHTML(a,b){
  const totalVisits = (a.visits||[]).length + (b.visits||[]).length;
  return `
    <div class="card" style="margin-top:16px;max-width:680px;">
      <h2 style="margin-bottom:4px;">Pick which details to keep</h2>
      <p class="faint" style="margin-bottom:10px;">Visit history, growth records and vaccinations from both records are combined either way — only these demographic fields need picking.</p>
      <div class="row" style="padding:0 0 6px;border-bottom:2px solid var(--line);font-weight:600;font-size:12px;color:var(--ink-soft);margin:0;">
        <div style="width:110px;flex:none;"></div>
        <div style="flex:1;">${esc(a.name)} (${a.id})</div>
        <div style="flex:1;">${esc(b.name)} (${b.id})</div>
      </div>
      ${mergeFieldRow('name','Name', a.name, b.name)}
      ${mergeFieldRow('dob','Date of birth', a.dob?fmtDate(a.dob):'', b.dob?fmtDate(b.dob):'')}
      ${mergeFieldRow('age','Age (if DOB unknown)', a.age, b.age)}
      ${mergeFieldRow('sex','Sex', a.sex, b.sex)}
      ${mergeFieldRow('phone','Phone', a.phone, b.phone)}
      ${mergeFieldRow('address','Address', a.address, b.address)}
      ${mergeFieldRow('allergies','Allergies', a.allergies, b.allergies)}
      ${mergeFieldRow('chronicIllness','Chronic illness', a.chronicIllness, b.chronicIllness)}
      <p class="muted" style="margin-top:12px;">${totalVisits} visit(s) total will end up on the kept record. "${esc(b.name)}" (${b.id}) will be permanently deleted after merging.</p>
      <div id="merge-error" class="error-text"></div>
      <button class="btn btn-primary" onclick="performMerge()">Merge these records</button>
    </div>`;
}
function mergePatientsView(){
  if(!isDoctor()){
    return `<div class="page-head"><h1>Merge duplicate patients</h1></div><p class="muted">This is available to staff logged in with the Doctor role.</p>`;
  }
  if(!state.mergeUI) initMergeUI();
  const mu = state.mergeUI;
  const a = mu.aId ? state.data.patients.find(p=>p.id===mu.aId) : null;
  const b = mu.bId ? state.data.patients.find(p=>p.id===mu.bId) : null;

  const pickerBlock = (side, p) => p
    ? `<div class="banner banner-info">${esc(p.name)} (${p.id}) — ${esc(displayAge(p))}/${esc(p.sex)} · ${(p.visits||[]).length} visit(s)
        <button class="btn btn-ghost btn-sm" style="margin-left:8px;" onclick="clearMergeSlot('${side}')">Change</button></div>`
    : `<input type="text" placeholder="Search by name, ID or phone" value="${esc(side==='A'?mu.searchA:mu.searchB)}" oninput="onMergeSearchInput('${side}',this.value)">
       <div id="merge-results-${side}" style="margin-top:6px;">${mergeSearchResultsHTML(side)}</div>`;

  let content = `
    <div class="row" style="align-items:flex-start;gap:16px;">
      <div class="card" style="flex:1;min-width:240px;">
        <h3>Record to keep</h3>
        ${pickerBlock('A', a)}
      </div>
      <div class="card" style="flex:1;min-width:240px;">
        <h3>Record to merge in <span class="faint">(will be deleted)</span></h3>
        ${pickerBlock('B', b)}
      </div>
    </div>`;

  if(a && b){
    content += (a.id===b.id)
      ? `<p class="error-text" style="margin-top:14px;">That's the same record on both sides — choose a different patient to merge in.</p>`
      : mergeCompareHTML(a,b);
  }

  return `<div class="page-head"><h1>Merge duplicate patients</h1></div>${content}`;
}
async function performMerge(){
  const mu = state.mergeUI;
  const a = state.data.patients.find(p=>p.id===mu.aId);
  const b = state.data.patients.find(p=>p.id===mu.bId);
  const errEl = document.getElementById('merge-error');
  if(!a || !b) return;
  const typed = prompt(`This combines "${b.name}" (${b.id}) into "${a.name}" (${a.id}) and permanently deletes the "${b.name}" (${b.id}) record.\n\nType MERGE to confirm.`);
  if(typed === null) return;
  if(typed.trim().toUpperCase() !== 'MERGE'){ if(errEl) errEl.textContent = 'Not confirmed — nothing was merged.'; return; }

  const pick = field => (mu.choices[field]||'A')==='A' ? a[field] : b[field];
  a.name = pick('name'); a.dob = pick('dob'); a.age = pick('age'); a.sex = pick('sex');
  a.phone = pick('phone'); a.address = pick('address'); a.allergies = pick('allergies'); a.chronicIllness = pick('chronicIllness');

  a.visits = (a.visits||[]).concat(b.visits||[]).sort((x,y)=> (x.date+x.id).localeCompare(y.date+y.id));
  a.growthRecords = (a.growthRecords||[]).concat(b.growthRecords||[]);
  a.vaccinations = (a.vaccinations||[]).concat(b.vaccinations||[]);

  (state.data.appointments||[]).forEach(appt=>{ if(appt.patientId===b.id) appt.patientId = a.id; });

  state.data.patients = state.data.patients.filter(p=>p.id!==b.id);
  logAudit('Merged patient records', `${b.name} (${b.id}) merged into ${a.name} (${a.id})`);
  const ok = await saveData();
  if(!ok){ if(errEl) errEl.textContent = state.saveError || 'Could not save — try again.'; return; }
  state.mergeUI = null;
  go('patient', {patientId: a.id});
}

function newPatientView(){
  return `
    <div class="page-head"><h1>Register new patient</h1></div>
    <div class="card" style="max-width:520px;">
      <div class="row"><div class="field"><label>Full name *</label><input id="reg-name" type="text"></div></div>
      <div class="row">
        <div class="field"><label>Date of birth</label><input id="reg-dob" type="date" max="${todayStr()}" oninput="updateAgePreview(this,'reg-age-preview')">
          <div id="reg-age-preview" class="faint" style="margin-top:4px;"></div></div>
        <div class="field"><label>Age (if DOB unknown)</label><input id="reg-age" type="text" placeholder="e.g. 45"></div>
        <div class="field"><label>Sex *</label><select id="reg-sex"><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select></div>
      </div>
      <p class="faint" style="margin:-8px 0 12px;">Enter a date of birth when known — it keeps age accurate automatically. Otherwise, enter an approximate age.</p>
      <div class="field"><label>Address *</label><textarea id="reg-address"></textarea></div>
      <div class="field"><label>Phone *</label><input id="reg-phone" type="text" oninput="state.regDupeAcknowledged=false"></div>
      <div class="field"><label>Known allergies</label><input id="reg-allergies" type="text" placeholder="e.g. Penicillin, Sulfa — leave blank if none known"></div>
      <div class="field"><label>Chronic illness</label><input id="reg-chronic" type="text" placeholder="e.g. Type 2 diabetes, Asthma, Hypertension — leave blank if none"></div>
      <div id="reg-error" class="error-text"></div>
      <div id="reg-dupe-warning"></div>
      <div class="row" style="margin-top:6px;">
        <button class="btn btn-primary" onclick="saveNewPatient()">Save patient</button>
        <button class="btn btn-ghost" onclick="go('patients')">Cancel</button>
      </div>
    </div>`;
}

function patientView(patientId){
  const p = state.data.patients.find(p=>p.id===patientId);
  if(!p) return `<p class="error-text">Patient not found.</p><button class="btn" onclick="go('patients')">Back to patients</button>`;

  const infoBlock = state.ui.editingPatient ? `
    <div class="row">
      <div class="field"><label>Name *</label><input id="ep-name" value="${esc(p.name)}"></div>
    </div>
    <div class="row">
      <div class="field"><label>Date of birth</label><input id="ep-dob" type="date" max="${todayStr()}" value="${esc(p.dob||'')}" oninput="updateAgePreview(this,'ep-age-preview')">
        <div id="ep-age-preview" class="faint" style="margin-top:4px;">${p.dob && ageFromDob(p.dob) ? 'Age: '+esc(ageFromDob(p.dob).full) : ''}</div></div>
      <div class="field"><label>Age (if DOB unknown)</label><input id="ep-age" value="${esc(p.age)}"></div>
      <div class="field"><label>Sex *</label><select id="ep-sex">
        ${['Male','Female','Other'].map(s=>`<option ${p.sex===s?'selected':''}>${s}</option>`).join('')}
      </select></div>
    </div>
    <div class="field"><label>Address *</label><textarea id="ep-address">${esc(p.address)}</textarea></div>
    <div class="row">
      <div class="field"><label>Phone *</label><input id="ep-phone" value="${esc(p.phone)}"></div>
    </div>
    <div class="field"><label>Known allergies</label><input id="ep-allergies" value="${esc(p.allergies||'')}" placeholder="e.g. Penicillin, Sulfa — leave blank if none known"></div>
    <div class="field"><label>Chronic illness</label><input id="ep-chronic" value="${esc(p.chronicIllness||'')}" placeholder="e.g. Type 2 diabetes, Asthma, Hypertension"></div>
    <div id="ep-error" class="error-text"></div>
    <div class="row"><button class="btn btn-primary" onclick="saveEditPatient('${p.id}')">Save</button><button class="btn btn-ghost" onclick="cancelEditPatient()">Cancel</button></div>
  ` : `
    ${p.detailsRedacted ? `<div class="banner" style="background:var(--danger-tint);color:var(--danger);margin-bottom:10px;"><strong>Personal details removed</strong>${p.redactedAt?' on '+fmtDate(p.redactedAt.slice(0,10)):''} — visit history below is preserved.</div>` : ''}
    <div class="row" style="margin-bottom:4px;">
      <div><span class="faint">Patient ID</span><div><span class="pill">${p.id}</span></div></div>
      <div><span class="faint">Age / Sex</span><div>${esc(displayAge(p))} / ${esc(p.sex)}${p.dob?` <span class="faint">(DOB ${fmtDate(p.dob)})</span>`:''}</div>
        ${p.dob && ageFromDob(p.dob) ? `<div class="faint" style="margin-top:2px;">${esc(ageFromDob(p.dob).full)} old</div>` : ''}</div>
      <div><span class="faint">Registered</span><div>${fmtDate(p.registeredDate)}</div></div>
    </div>
    <div><span class="faint">Address</span><div>${esc(p.address)||'—'}</div></div>
    <div style="margin-top:8px;"><span class="faint">Phone</span><div>${esc(p.phone)||'—'}</div></div>
    ${patientSafetyBannerHTML(p)}
    <button class="btn btn-sm" style="margin-top:12px;" onclick="startEditPatient()">Edit details</button>
  `;

  const visits = (p.visits||[]).slice().sort((a,b)=> (b.date+b.id).localeCompare(a.date+a.id));
  const visitRows = visits.map(v=>{
    const st = visitStatus(v);
    const canContinue = st==='waiting' && isDoctor();
    const clickAction = canContinue
      ? `go('newVisit',{patientId:'${p.id}',editVisitId:'${v.id}'})`
      : `go('visitPrint',{patientId:'${p.id}',visitId:'${v.id}'})`;
    return `
    <tr class="clickable" onclick="${clickAction}">
      <td>${fmtDate(v.date)}</td>
      <td>${isDoctor() ? (esc(v.diagnosis)||'<span class="faint">—</span>') : '<span class="faint">—</span>'}</td>
      <td>${esc(v.doctorName)||'<span class="faint">—</span>'}</td>
      <td>${st==='waiting'
        ? `<span class="pill" style="background:var(--accent-tint);color:var(--accent);">Waiting${canContinue?' — tap to continue':''}</span>`
        : '<span class="pill">Completed</span>'}
        ${v.referredTo ? `<span class="pill" title="Referred to ${esc(v.referredTo)}${v.referralReason?' — '+esc(v.referralReason):''}" style="margin-left:4px;">↗ Referred</span>` : ''}</td>
      <td>${isDoctor() ? `<button class="btn btn-ghost btn-sm" onclick="event.stopPropagation();deleteVisit('${p.id}','${v.id}')">Delete</button>` : ''}</td>
    </tr>`;
  }).join('');

  const pedBanner = isPediatricPatient(p)
    ? `<div class="banner banner-info" style="margin-bottom:14px;"><strong>Pediatric patient</strong> (under 16) — ${esc(opdAgeDisplay(p))}
        ${isDoctor() ? `<button class="btn btn-sm" style="margin-left:8px;" onclick="state.pedLinkedPatientId='${p.id}';state.pedTab='growth';go('pediatrics')">Open in Pediatrics</button>` : ''}
      </div>` : '';
  return `
    <div class="page-head">
      <div><h1>${esc(p.name)} <span class="pill">${p.id}</span></h1></div>
      <div class="row" style="gap:8px;">
        <button class="btn btn-accent" onclick="go('newVisit',{patientId:'${p.id}'})">+ New OPD Visit</button>
        <button class="btn" onclick="state.certPatientId='${p.id}';state.certType='sick';go('certificates')">Certificate</button>
      </div>
    </div>
    ${pedBanner}
    <div class="card" style="margin-bottom:18px;">${infoBlock}</div>
    ${isDoctor() && isPediatricPatient(p) ? growthRecordsCardHTML(p) : ''}
    ${isDoctor() && isPediatricPatient(p) ? vaccinationCardHTML(p) : ''}
    <div class="card" style="margin-bottom:18px;">
      <h2 style="margin-bottom:10px;">Visit history</h2>
      ${visits.length ? `<table><thead><tr><th>Date</th><th>Diagnosis</th><th>Doctor</th><th>Status</th><th></th></tr></thead><tbody>${visitRows}</tbody></table>`
        : `<p class="muted">No visits recorded yet.</p>`}
    </div>
    ${isDoctor() ? `
    <div class="card" style="border-color:var(--danger);">
      <h2 style="color:var(--danger);margin-bottom:6px;">Danger zone</h2>
      <div style="margin-bottom:14px;padding-bottom:14px;border-bottom:1px solid var(--border);">
        <p class="muted" style="font-size:12.5px;">Clears this patient's name, date of birth/age, phone and address. Their visit history, prescriptions and billing stay on record under the same patient ID — only the personal/contact details are removed. Doesn't touch any other patient or any other data on the site.</p>
        <button class="btn btn-danger btn-sm" onclick="clearPatientDetails('${p.id}')">Clear personal details</button>
      </div>
      <p class="muted" style="font-size:12.5px;">Permanently deletes this patient and their entire visit history. This cannot be undone.</p>
      <button class="btn btn-danger btn-sm" onclick="deletePatient('${p.id}')">Delete patient record</button>
    </div>` : ''}`;
}
async function deleteVisit(patientId, visitId){
  if(!isDoctor()) return;
  const p = state.data.patients.find(p=>p.id===patientId);
  const v = p && (p.visits||[]).find(v=>v.id===visitId);
  if(!p || !v) return;
  const warn = v.billing && v.billing.paid ? '\n\nThis visit has a paid bill on record — deleting it also removes that billing history.' : '';
  if(!confirm(`Delete the visit from ${fmtDate(v.date)}? This cannot be undone.${warn}`)) return;
  p.visits = p.visits.filter(v=>v.id!==visitId);
  logAudit('Deleted visit', `${p.name} (${p.id}) — ${fmtDate(v.date)}`);
  await saveData();
  render();
}
async function deletePatient(patientId){
  if(!isDoctor()) return;
  const p = state.data.patients.find(p=>p.id===patientId);
  if(!p) return;
  const typed = prompt(`This permanently deletes ${p.name} (${p.id}) and all ${(p.visits||[]).length} visit(s) on record.\n\nType the patient ID (${p.id}) to confirm.`);
  if(typed === null) return;
  if(typed.trim() !== p.id){ alert('That did not match — nothing was deleted.'); return; }
  state.data.patients = state.data.patients.filter(pt=>pt.id!==patientId);
  logAudit('Deleted patient record', `${p.name} (${p.id})`);
  await saveData();
  go('patients');
}
// A lighter option than deletePatient(): clears just the personal/contact
// fields (name, DOB/age, phone, address) while keeping the patient ID,
// visit history, prescriptions and billing intact — e.g. for a privacy
// request where the clinic still needs the clinical/financial record.
// Only this one patient is touched; nothing else on the site is affected.
async function clearPatientDetails(patientId){
  if(!isDoctor()) return;
  const p = state.data.patients.find(p=>p.id===patientId);
  if(!p) return;
  const originalName = p.name;
  const typed = prompt(`This clears ${p.name}'s name, date of birth/age, phone and address — their visit history, prescriptions and billing stay on record under patient ID ${p.id}.\n\nType the patient ID (${p.id}) to confirm.`);
  if(typed === null) return;
  if(typed.trim() !== p.id){ alert('That did not match — nothing was changed.'); return; }
  p.name = '[Details removed]';
  p.dob = ''; p.age = ''; p.phone = ''; p.address = '';
  p.detailsRedacted = true;
  p.redactedAt = new Date().toISOString();
  logAudit('Cleared patient details', `${p.id} — was "${originalName}"`);
  await saveData();
  render();
}

function growthRecordsCardHTML(p){
  const recs = p.growthRecords || [];
  if(!recs.length) return '';
  const rows = recs.slice().sort((a,b)=>b.date.localeCompare(a.date)).map(r=>`
    <tr><td>${fmtDate(r.date)}</td><td>${(r.ageMonths/12).toFixed(1)}y</td>
      <td>${r.weight?r.weight+'kg ('+r.weightPercentile+'th)':'<span class="faint">—</span>'}</td>
      <td>${r.height?r.height+'cm ('+r.heightPercentile+'th)':'<span class="faint">—</span>'}</td>
      <td>${r.hc?r.hc+'cm ('+r.hcPercentile+'th)':'<span class="faint">—</span>'}</td>
    </tr>`).join('');
  return `
    <div class="card" style="margin-bottom:18px;">
      <h2 style="margin-bottom:10px;">Growth records</h2>
      <table><thead><tr><th>Date</th><th>Age</th><th>Weight</th><th>Height</th><th>Head circ.</th></tr></thead><tbody>${rows}</tbody></table>
    </div>`;
}

function vaccineOptionsList(){
  const set = new Set();
  IMMUNIZATION_SCHEDULE.forEach(r=> r.vaccines.split(',').forEach(v=> set.add(v.trim())));
  return Array.from(set);
}
function vaccinationCardHTML(p){
  const vacs = (p.vaccinations||[]).slice().sort((a,b)=>(a.date||'').localeCompare(b.date||''));
  const rows = vacs.map((v,i)=>`
    <tr><td>${esc(v.vaccine)}</td><td>${v.date?fmtDate(v.date):'<span class="faint">—</span>'}</td>
      <td><button class="btn btn-ghost btn-sm" onclick="removeVaccination('${p.id}',${i})">Remove</button></td></tr>`).join('');
  let dueBlock = '';
  if(isPediatricPatient(p)){
    const due = vaccinationStatusForPatient(p).filter(i=>i.status==='due'||i.status==='overdue'||i.status==='upcoming').slice(0,8);
    if(due.length){
      dueBlock = `<div style="margin-bottom:12px;">
        <p class="faint" style="margin-bottom:6px;">Suggested by age (IAP/UIP):</p>
        <div class="chip-row">${due.map(d=>
          `<button type="button" class="chip" style="${d.status==='overdue'||d.status==='due'?'border-color:var(--accent);':''}"
            onclick="quickAddVaccination('${p.id}', this.getAttribute('data-vac'))" data-vac="${esc(d.vaccine)}">${esc(d.vaccine)} · ${d.status}</button>`
        ).join('')}</div>
      </div>`;
    }
  }
  return `
    <div class="card" style="margin-bottom:18px;">
      <h2 style="margin-bottom:10px;">Vaccinations</h2>
      ${dueBlock}
      ${vacs.length ? `<table><thead><tr><th>Vaccine</th><th>Date given</th><th></th></tr></thead><tbody>${rows}</tbody></table>` : `<p class="muted">None recorded yet.</p>`}
      <div class="row" style="margin-top:10px;">
        <div class="field" style="flex:2;"><label>Vaccine</label>
          <select id="vac-name">${vaccineOptionsList().map(v=>`<option>${esc(v)}</option>`).join('')}</select>
        </div>
        <div class="field"><label>Date given</label><input id="vac-date" type="date" value="${todayStr()}"></div>
      </div>
      <button class="btn btn-sm" onclick="addVaccination('${p.id}')">+ Add</button>
    </div>`;
}
async function addVaccination(patientId){
  const p = state.data.patients.find(p=>p.id===patientId);
  if(!p) return;
  const vaccine = document.getElementById('vac-name').value;
  const date = document.getElementById('vac-date').value;
  if(!p.vaccinations) p.vaccinations = [];
  p.vaccinations.push({vaccine, date});
  logAudit('Added vaccination', `${vaccine} — ${p.name} (${p.id})`);
  await saveData();
  render();
}
async function removeVaccination(patientId, idx){
  const p = state.data.patients.find(p=>p.id===patientId);
  if(!p || !p.vaccinations) return;
  const v = p.vaccinations[idx];
  if(!v) return;
  if(!confirm(`Remove ${v.vaccine}${v.date?' ('+fmtDate(v.date)+')':''} from this patient's record?`)) return;
  p.vaccinations.splice(idx,1);
  logAudit('Removed vaccination', `${v.vaccine} — ${p.name} (${p.id})`);
  await saveData();
  render();
}

function visitPatientResultsHTML(){
  const q = state.search.trim().toLowerCase();
  if(!q) return `<p class="faint">Type a name, ID or phone to search.</p>`;
  const list = state.data.patients.filter(p =>
    p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q) || (p.phone||'').includes(q)
  ).slice(0,8);
  if(list.length===0) return `<p class="faint">No matching patients.</p>`;
  return list.map(p=>`
    <div class="rx-row" style="cursor:pointer;" onclick="selectPatientForVisit('${p.id}')">
      <strong>${esc(p.name)}</strong> <span class="pill">${p.id}</span>
      <div class="faint">${esc(displayAge(p))} / ${esc(p.sex)} ${p.phone?'· '+esc(p.phone):''}</div>
    </div>`).join('');
}

// Free-text heuristic only (substring match against the patient's allergy
// list) — not a real drug-interaction database. It catches the common case
// (patient's card says "Penicillin", doctor picks Amoxicillin) but doesn't
// know drug classes or cross-reactivity, so it's a prompt to double-check,
// not a clinical guarantee.
function currentVisitPatientAllergies(){
  const dv = state.draftVisit;
  if(dv.patientId){
    const p = state.data.patients.find(p=>p.id===dv.patientId);
    return p ? (p.allergies||'') : '';
  }
  if(dv.newPatient) return dv.newPatient.allergies || '';
  return '';
}
function allergyMatch(medicineName){
  const allergies = currentVisitPatientAllergies();
  if(!allergies || !medicineName) return null;
  const med = medicineName.toLowerCase();
  const tokens = allergies.split(/[,;/]+/).map(s=>s.trim().toLowerCase()).filter(Boolean);
  for(const t of tokens){
    if(t.length<2) continue;
    if(med.includes(t)) return t;
    const group = ALLERGY_ALIASES.find(g => g.keys.some(k => t.includes(k) || k.includes(t)));
    if(group && group.keys.some(k => med.includes(k))) return group.label;
  }
  return null;
}
function rxAllergyWarningHTML(medicineName){
  const hit = allergyMatch(medicineName);
  if(!hit) return '';
  return `<div class="banner" style="background:var(--danger-tint);color:var(--danger);margin:6px 0 0;padding:6px 10px;font-size:12.5px;">⚠ Patient has a listed allergy to "${esc(hit)}" — check before prescribing.</div>`;
}
function collectVisitAllergyHits(prescriptions){
  const hits = [];
  (prescriptions||[]).forEach(r=>{
    if(!r || !r.medicine) return;
    const hit = allergyMatch(r.medicine);
    if(hit) hits.push({medicine:r.medicine, allergy:hit});
  });
  return hits;
}
function rxSafetySummaryHTML(){
  const dv = state.draftVisit;
  if(!dv) return '';
  const prescriptions = (dv.prescriptions||[]).filter(r=>r && r.medicine);
  const allergyHits = collectVisitAllergyHits(prescriptions);
  const interactions = findDrugInteractions(prescriptions);
  if(!allergyHits.length && !interactions.length) return '';
  const allergyLines = allergyHits.map(h=>`⚠ ${esc(h.medicine)} may conflict with listed allergy “${esc(h.allergy)}”.`).join('<br>');
  const ixLines = interactions.map(w=>`⚠ ${esc(w)}`).join('<br>');
  return `<div class="banner" style="background:var(--danger-tint);color:var(--danger);margin-top:10px;">
    <strong>Safety check before save</strong>
    <div style="margin-top:4px;font-weight:500;">${[allergyLines, ixLines].filter(Boolean).join('<br>')}</div>
    <div class="faint" style="margin-top:4px;color:inherit;opacity:0.85;">Heuristic only — confirm against the patient’s history and a current formulary.</div>
  </div>`;
}
function refreshRxSafetySummary(){
  const sum = document.getElementById('rx-safety-summary');
  if(sum) sum.innerHTML = rxSafetySummaryHTML();
}
function updateRxAllergyWarning(i){
  const el = document.getElementById('rx-allergy-'+i);
  if(el && state.draftVisit.prescriptions[i]) el.innerHTML = rxAllergyWarningHTML(state.draftVisit.prescriptions[i].medicine);
  refreshRxSafetySummary();
}
function rxRowsHTML(){
  const pedPatient = state.draftVisit && state.draftVisit.patientId
    ? state.data.patients.find(p=>p.id===state.draftVisit.patientId) : null;
  const showDose = pedPatient && isPediatricPatient(pedPatient);
  const knownWt = showDose ? mostRecentPediatricWeight(pedPatient) : null;
  return state.draftVisit.prescriptions.map((r,i)=>`
    <div class="rx-row" data-rx-idx="${i}">
      <div class="rx-row-head"><span class="idx">MEDICINE ${i+1}</span>
        <button class="btn btn-ghost btn-sm" onclick="removeRxRow(${i})">Remove</button></div>
      <div class="row">
        <div class="field" style="flex:2;"><label>Medicine</label>
          <select onchange="pickMedicine(${i},this.value)">
            <option value="">Select…</option>
            ${medicineOptionsList().map(m=>`<option value="${esc(m.name)}" ${r.medicine===m.name?'selected':''}>${esc(m.name)}</option>`).join('')}
          </select>
          <input data-f="medicine" type="text" placeholder="or type a medicine name" value="${esc(r.medicine)}"
            oninput="state.draftVisit.prescriptions[${i}].medicine=this.value;updateRxAllergyWarning(${i});updateRxDoseHint(${i})">
          <div id="rx-allergy-${i}">${rxAllergyWarningHTML(r.medicine)}</div>
        </div>
        <div class="field"><label>Dosage</label>
          <select id="rx-dose-select-${i}" onchange="pickDosage(${i},this.value)">${dosageOptionsHTML(r.medicine, r.dosage)}</select>
          <input data-f="dosage" type="text" placeholder="or type dosage" value="${esc(r.dosage)}"
            oninput="state.draftVisit.prescriptions[${i}].dosage=this.value">
        </div>
      </div>
      ${showDose ? `<div id="rx-dose-hint-${i}" class="banner banner-info" style="margin:6px 0 8px;font-size:12.5px;">${rxDoseHintHTML(r.medicine, knownWt)}</div>` : ''}
      <div class="row">
        <div class="field"><label>Frequency</label>
          <select onchange="pickFrequency(${i},this.value)">
            <option value="">Select…</option>
            ${FREQUENCY_OPTIONS.map(f=>`<option value="${esc(f)}" ${r.frequency===f?'selected':''}>${esc(f)}</option>`).join('')}
          </select>
          <input data-f="frequency" type="text" placeholder="or type e.g. 1-0-1" value="${esc(r.frequency)}"
            oninput="state.draftVisit.prescriptions[${i}].frequency=this.value">
        </div>
        <div class="field"><label>Days</label><input data-f="duration" type="number" min="1" step="1" inputmode="numeric" placeholder="e.g. 5" value="${esc(r.duration)}"></div>
        <div class="field"><label>Timing</label>
          <select data-f="instructions">
            <option value="" ${!r.instructions?'selected':''}>—</option>
            <option value="Before food" ${r.instructions==='Before food'?'selected':''}>Before food</option>
            <option value="After food" ${r.instructions==='After food'?'selected':''}>After food</option>
            <option value="SOS" ${r.instructions==='SOS'?'selected':''}>SOS (as needed)</option>
          </select>
        </div>
      </div>
      <button class="btn btn-ghost btn-sm" onclick="saveMedicineToLibrary(${i},this)">+ Save this medicine to my list</button>
    </div>`).join('');
}
// Match a typed medicine name against the pediatric dose formulary.
function findPediatricDoseEntry(medicineName){
  const n = (medicineName||'').toLowerCase().replace(/^(tab\.|syp\.|syrup|inj\.|cap\.)\s*/,'');
  if(!n) return null;
  return (typeof PEDIATRIC_DOSE_DB!=='undefined' ? PEDIATRIC_DOSE_DB : []).find(d=>{
    const dn = d.name.toLowerCase();
    return n.includes(dn) || dn.includes(n) || n.includes(dn.split(' ')[0]);
  }) || null;
}
function rxDoseHintHTML(medicineName, knownWt){
  const d = findPediatricDoseEntry(medicineName);
  if(!d) return knownWt
    ? `<span class="faint">Weight on file: ${knownWt.value} kg (${knownWt.source}). Type a formulary medicine (e.g. Paracetamol) for a dose suggestion.</span>`
    : `<span class="faint">Pediatric visit — enter weight in vitals, or link a prior growth reading, for dose suggestions.</span>`;
  if(!knownWt || !knownWt.value){
    return `<strong>Dose ref:</strong> ${esc(d.name)} — ${d.mgPerKg}mg/kg per dose · ${esc(d.freq)}. Enter weight to calculate.`;
  }
  let doseMg = knownWt.value * d.mgPerKg;
  let capped = false;
  if(d.maxMg && doseMg > d.maxMg){ doseMg = d.maxMg; capped = true; }
  let vol = '';
  if(d.conc && d.conc.length){
    vol = d.conc.map(c=>{
      const ml = (doseMg / c) * 5;
      return `${ml.toFixed(1)} ml of ${c}mg/5ml`;
    }).join(' or ');
  }
  return `<strong>Suggested dose (${knownWt.value} kg):</strong> ${doseMg.toFixed(1)} mg per dose${capped?' (capped)':''}${vol?' — '+vol:''} · ${esc(d.freq)} <span class="faint">— confirm before prescribing</span>`;
}
function refreshAllRxDoseHints(){
  if(!state.draftVisit || !state.draftVisit.prescriptions) return;
  // Keep draft weight in sync so mostRecentPediatricWeight fallback still works mid-visit
  const wEl = document.getElementById('v-weight');
  if(wEl && state.draftVisit.vitals) state.draftVisit.vitals.weight = wEl.value;
  state.draftVisit.prescriptions.forEach((_,i)=>updateRxDoseHint(i));
}
function updateRxDoseHint(i){
  const el = document.getElementById('rx-dose-hint-'+i);
  if(!el) return;
  const pedPatient = state.draftVisit && state.draftVisit.patientId
    ? state.data.patients.find(p=>p.id===state.draftVisit.patientId) : null;
  const knownWt = pedPatient ? mostRecentPediatricWeight(pedPatient) : null;
  const med = document.querySelector(`[data-rx-idx="${i}"] [data-f="medicine"]`);
  el.innerHTML = rxDoseHintHTML(med ? med.value : '', knownWt);
}

// ---- Essential OPD medicine / investigation reference data ----
// Suggestions only — every field stays free-typeable, so anything not
// listed here can still just be typed in directly.
const MEDICINE_DB = [
  {name:'Tab. Paracetamol', dosages:['500mg','650mg']},
  {name:'Tab. Ibuprofen', dosages:['200mg','400mg']},
  {name:'Tab. Diclofenac', dosages:['50mg','100mg']},
  {name:'Tab. Aceclofenac', dosages:['100mg']},
  {name:'Tab. Aceclofenac + Paracetamol', dosages:['100mg/325mg']},
  {name:'Tab. Amoxicillin', dosages:['250mg','500mg']},
  {name:'Tab. Amoxicillin + Clavulanic Acid', dosages:['375mg','625mg']},
  {name:'Tab. Azithromycin', dosages:['250mg','500mg']},
  {name:'Tab. Ciprofloxacin', dosages:['250mg','500mg']},
  {name:'Tab. Ofloxacin', dosages:['200mg']},
  {name:'Tab. Ofloxacin + Ornidazole', dosages:['200mg/500mg']},
  {name:'Tab. Norfloxacin', dosages:['400mg']},
  {name:'Tab. Cefixime', dosages:['100mg','200mg']},
  {name:'Tab. Cefpodoxime', dosages:['100mg','200mg']},
  {name:'Tab. Doxycycline', dosages:['100mg']},
  {name:'Tab. Metronidazole', dosages:['400mg']},
  {name:'Tab. Ornidazole', dosages:['500mg']},
  {name:'Tab. Pantoprazole', dosages:['40mg']},
  {name:'Tab. Omeprazole', dosages:['20mg']},
  {name:'Tab. Rabeprazole', dosages:['20mg']},
  {name:'Tab. Rabeprazole + Domperidone', dosages:['20mg/30mg']},
  {name:'Tab. Ranitidine', dosages:['150mg']},
  {name:'Tab. Domperidone', dosages:['10mg']},
  {name:'Tab. Ondansetron', dosages:['4mg','8mg']},
  {name:'Tab. Metoclopramide', dosages:['10mg']},
  {name:'Tab. Cetirizine', dosages:['10mg']},
  {name:'Tab. Levocetirizine', dosages:['5mg']},
  {name:'Tab. Fexofenadine', dosages:['120mg','180mg']},
  {name:'Tab. Chlorpheniramine', dosages:['4mg']},
  {name:'Tab. Montelukast', dosages:['10mg']},
  {name:'Tab. Montelukast + Levocetirizine', dosages:['10mg/5mg']},
  {name:'Tab. Metformin', dosages:['500mg','850mg','1000mg']},
  {name:'Tab. Glimepiride', dosages:['1mg','2mg','4mg']},
  {name:'Tab. Glimepiride + Metformin', dosages:['1mg/500mg','2mg/500mg']},
  {name:'Tab. Glipizide', dosages:['5mg']},
  {name:'Tab. Sitagliptin', dosages:['50mg','100mg']},
  {name:'Tab. Amlodipine', dosages:['2.5mg','5mg','10mg']},
  {name:'Tab. Telmisartan', dosages:['20mg','40mg']},
  {name:'Tab. Telmisartan + Amlodipine', dosages:['40mg/5mg']},
  {name:'Tab. Losartan', dosages:['25mg','50mg']},
  {name:'Tab. Atenolol', dosages:['25mg','50mg']},
  {name:'Tab. Metoprolol', dosages:['25mg','50mg']},
  {name:'Tab. Atorvastatin', dosages:['10mg','20mg']},
  {name:'Tab. Rosuvastatin', dosages:['10mg','20mg']},
  {name:'Tab. Aspirin', dosages:['75mg','150mg']},
  {name:'Tab. Clopidogrel', dosages:['75mg']},
  {name:'Tab. Levothyroxine', dosages:['25mcg','50mcg','100mcg']},
  {name:'Tab. Prednisolone', dosages:['5mg','10mg','20mg']},
  {name:'Tab. Albendazole', dosages:['400mg']},
  {name:'Tab. Loperamide', dosages:['2mg']},
  {name:'Tab. Tramadol', dosages:['50mg']},
  {name:'Tab. Isoniazid (ATT)', dosages:['300mg']},
  {name:'Tab. Rifampicin (ATT)', dosages:['450mg','600mg']},
  {name:'Tab. Ethambutol (ATT)', dosages:['800mg']},
  {name:'Tab. Pyrazinamide (ATT)', dosages:['750mg']},
  {name:'Tab. Chloroquine', dosages:['250mg']},
  {name:'Tab. Iron + Folic Acid', dosages:['100mg/0.5mg']},
  {name:'Tab. Calcium + Vitamin D3', dosages:['500mg/250IU']},
  {name:'Tab. Multivitamin', dosages:['1 tablet']},
  {name:'Tab. Vitamin B Complex', dosages:['1 tablet']},
  {name:'Cap. Vitamin D3', dosages:['60000IU']},
  {name:'Tab. Zinc Sulphate', dosages:['20mg']},
  {name:'Cap. Omeprazole', dosages:['20mg']},
  {name:'Cap. Doxycycline', dosages:['100mg']},
  {name:'Cap. Amoxicillin', dosages:['250mg','500mg']},
  {name:'Cap. Fluconazole', dosages:['150mg']},
  {name:'Syp. Paracetamol (Pediatric)', dosages:['125mg/5ml','250mg/5ml']},
  {name:'Syp. Amoxicillin (Pediatric)', dosages:['125mg/5ml','250mg/5ml']},
  {name:'Syp. Azithromycin (Pediatric)', dosages:['200mg/5ml']},
  {name:'Syp. Cefixime (Pediatric)', dosages:['100mg/5ml']},
  {name:'Syp. Ambroxol (Cough)', dosages:['15mg/5ml']},
  {name:'Syp. Dextromethorphan (Cough)', dosages:['10mg/5ml']},
  {name:'Syp. Domperidone (Pediatric)', dosages:['5mg/5ml']},
  {name:'Syp. Ondansetron (Pediatric)', dosages:['2mg/5ml']},
  {name:'Syp. Cetirizine (Pediatric)', dosages:['5mg/5ml']},
  {name:'Syp. Zinc Sulphate', dosages:['20mg/5ml']},
  {name:'Syp. Multivitamin', dosages:['5ml']},
  {name:'Syp. Iron (Ferrous)', dosages:['5ml']},
  {name:'Syp. Albendazole (Pediatric)', dosages:['200mg/5ml']},
  {name:'ORS Sachet (Electral)', dosages:['1 sachet in 200ml water']},
  {name:'Inj. Ceftriaxone', dosages:['1g']},
  {name:'Inj. Amoxicillin + Clavulanic Acid', dosages:['1.2g']},
  {name:'Inj. Diclofenac', dosages:['75mg/3ml']},
  {name:'Inj. Tramadol', dosages:['100mg']},
  {name:'Inj. Pantoprazole', dosages:['40mg']},
  {name:'Inj. Ondansetron', dosages:['4mg']},
  {name:'Inj. Metoclopramide', dosages:['10mg']},
  {name:'Inj. Dexamethasone', dosages:['4mg/ml']},
  {name:'Inj. Hydrocortisone', dosages:['100mg']},
  {name:'Inj. Insulin (Human Mixtard 30/70)', dosages:['as per sliding scale']},
  {name:'Inj. Insulin (Human Regular)', dosages:['as per sliding scale']},
  {name:'Inj. Tetanus Toxoid (TT)', dosages:['0.5ml']},
  {name:'Inj. Adrenaline', dosages:['1mg/ml']},
  {name:'Inj. Hyoscine Butylbromide', dosages:['20mg']},
  {name:'Inj. Vitamin B12', dosages:['1ml']},
  {name:'Inj. Iron Sucrose', dosages:['100mg/5ml']},
  {name:'IV Fluid — Normal Saline (NS) 0.9%', dosages:['500ml','1000ml']},
  {name:'IV Fluid — Ringer Lactate (RL)', dosages:['500ml','1000ml']},
  {name:'IV Fluid — Dextrose Normal Saline (DNS)', dosages:['500ml']},
  {name:'IV Fluid — 5% Dextrose (D5)', dosages:['500ml']},
  {name:'IV Fluid — 25% Dextrose (D25)', dosages:['100ml']},
  {name:'Oint. Betadine (Povidone Iodine)', dosages:['apply locally']},
  {name:'Gel. Diclofenac', dosages:['apply locally']},
  {name:'Cream. Hydrocortisone', dosages:['apply locally']},
  {name:'Cream. Clotrimazole', dosages:['apply locally']},
  {name:'Drops. Ciprofloxacin (Eye/Ear)', dosages:['2 drops']},
  {name:'Inhaler Salbutamol', dosages:['100mcg/puff']},
  {name:'Inhaler Budesonide + Formoterol', dosages:['200mcg/6mcg per puff']}
];

// Generic dosage suggestions shown when a typed medicine isn't in the list.
const COMMON_DOSAGES = [
  '500mg','650mg','250mg','400mg','200mg','100mg','50mg','25mg','10mg','5mg',
  '1 tablet','2 tablets','1 capsule','5ml','10ml','1 sachet','1 puff','1-2 drops'
];

const FREQUENCY_OPTIONS = [
  '1-0-1','1-1-1','1-0-0','0-0-1','0-1-0','1-1-0','0-1-1','2-0-2','1-0-2',
  'OD (once daily)','BD (twice daily)','TDS (thrice daily)','QID (four times daily)',
  'STAT (immediately)','HS (at bedtime)'
];

const INVESTIGATION_GROUPS = [
  {name:'Blood / biochemistry', tests:[
    'Complete Blood Count (CBC)','Random Blood Sugar (RBS)','Fasting Blood Sugar (FBS)',
    'Post-Prandial Blood Sugar (PPBS)','HbA1c','Liver Function Test (LFT)',
    'Renal Function Test (RFT)','Blood Urea','Serum Creatinine','Lipid Profile',
    'Serum Electrolytes','Thyroid Profile (T3/T4/TSH)','Serum Bilirubin (Total/Direct)',
    'Serum Uric Acid','CRP','ESR','Blood Grouping & Rh Typing','Peripheral Smear',
    'PT/INR','Serum Amylase/Lipase','Vitamin D3 Level','Vitamin B12 Level','Serum Calcium'
  ]},
  {name:'Urine / stool', tests:[
    'Urine Routine & Microscopy','Stool Routine','Urine Pregnancy Test',
    'Culture & Sensitivity (Urine)'
  ]},
  {name:'Infectious disease', tests:[
    'Widal Test','Dengue NS1 Antigen','Dengue IgM/IgG','Malaria Parasite (MP) Smear',
    'Typhidot','HIV Test','HBsAg','HCV','VDRL','Sputum for AFB','Mantoux Test',
    'Culture & Sensitivity (Blood)','COVID-19 RT-PCR / Antigen'
  ]},
  {name:'Imaging / cardiac', tests:[
    'ECG','Chest X-Ray','X-Ray (specify site)','USG Abdomen','USG Pelvis','2D Echo'
  ]}
];
const INVESTIGATION_DB = INVESTIGATION_GROUPS.flatMap(g=>g.tests);

// Structured lab result panels — components, units, and approximate Indian
// clinical reference ranges by age/sex (screening values; labs vary).
const LAB_PANELS = {
  'Complete Blood Count (CBC)': [
    {key:'Hb', label:'Hemoglobin (Hb)', unit:'g/dL',
      ref:(age,sex)=>{
        if(age!=null && age<12) return age<5 ? '11.0 – 14.0' : '11.5 – 15.5';
        return sex==='Female' ? '12.0 – 15.0' : '13.0 – 17.0';
      }},
    {key:'RBC', label:'RBC count', unit:'×10⁶/µL',
      ref:(age,sex)=> sex==='Female' ? '4.0 – 5.2' : '4.5 – 5.5'},
    {key:'HCT', label:'Hematocrit (PCV)', unit:'%',
      ref:(age,sex)=> sex==='Female' ? '36 – 46' : '40 – 50'},
    {key:'MCV', label:'MCV', unit:'fL', ref:()=>'80 – 100'},
    {key:'MCH', label:'MCH', unit:'pg', ref:()=>'27 – 33'},
    {key:'MCHC', label:'MCHC', unit:'g/dL', ref:()=>'32 – 36'},
    {key:'WBC', label:'WBC (TLC)', unit:'/µL',
      ref:(age)=> age!=null && age<12 ? '4,500 – 13,500' : '4,000 – 11,000'},
    {key:'Neutrophils', label:'Neutrophils', unit:'%', ref:()=>'40 – 70'},
    {key:'Lymphocytes', label:'Lymphocytes', unit:'%',
      ref:(age)=> age!=null && age<12 ? '30 – 55' : '20 – 40'},
    {key:'Eosinophils', label:'Eosinophils', unit:'%', ref:()=>'1 – 6'},
    {key:'Monocytes', label:'Monocytes', unit:'%', ref:()=>'2 – 10'},
    {key:'Platelets', label:'Platelet count', unit:'/µL', ref:()=>'1,50,000 – 4,50,000'},
    {key:'RDW', label:'RDW', unit:'%', ref:()=>'11.5 – 14.5'}
  ],
  'Liver Function Test (LFT)': [
    {key:'TBili', label:'Total bilirubin', unit:'mg/dL', ref:()=>'0.2 – 1.2'},
    {key:'DBili', label:'Direct bilirubin', unit:'mg/dL', ref:()=>'0.0 – 0.3'},
    {key:'IBili', label:'Indirect bilirubin', unit:'mg/dL', ref:()=>'0.2 – 0.9'},
    {key:'AST', label:'AST (SGOT)', unit:'U/L', ref:()=>'5 – 40'},
    {key:'ALT', label:'ALT (SGPT)', unit:'U/L', ref:()=>'5 – 40'},
    {key:'ALP', label:'Alkaline phosphatase', unit:'U/L',
      ref:(age)=> age!=null && age<18 ? '50 – 400 (age-dependent)' : '40 – 129'},
    {key:'Protein', label:'Total protein', unit:'g/dL', ref:()=>'6.0 – 8.3'},
    {key:'Albumin', label:'Albumin', unit:'g/dL', ref:()=>'3.5 – 5.0'},
    {key:'Globulin', label:'Globulin', unit:'g/dL', ref:()=>'2.0 – 3.5'},
    {key:'AG', label:'A/G ratio', unit:'', ref:()=>'1.0 – 2.2'}
  ],
  'Renal Function Test (RFT)': [
    {key:'Urea', label:'Blood urea', unit:'mg/dL', ref:()=>'15 – 40'},
    {key:'BUN', label:'BUN', unit:'mg/dL', ref:()=>'7 – 20'},
    {key:'Creatinine', label:'Serum creatinine', unit:'mg/dL',
      ref:(age,sex)=> sex==='Female' ? '0.5 – 1.1' : '0.7 – 1.3'},
    {key:'UricAcid', label:'Serum uric acid', unit:'mg/dL',
      ref:(age,sex)=> sex==='Female' ? '2.5 – 6.0' : '3.5 – 7.2'},
    {key:'Na', label:'Sodium (Na⁺)', unit:'mEq/L', ref:()=>'135 – 145'},
    {key:'K', label:'Potassium (K⁺)', unit:'mEq/L', ref:()=>'3.5 – 5.0'},
    {key:'Cl', label:'Chloride (Cl⁻)', unit:'mEq/L', ref:()=>'98 – 107'}
  ],
  'Blood Urea': [
    {key:'Urea', label:'Blood urea', unit:'mg/dL', ref:()=>'15 – 40'}
  ],
  'Serum Creatinine': [
    {key:'Creatinine', label:'Serum creatinine', unit:'mg/dL',
      ref:(age,sex)=> sex==='Female' ? '0.5 – 1.1' : '0.7 – 1.3'}
  ],
  'Serum Uric Acid': [
    {key:'UricAcid', label:'Serum uric acid', unit:'mg/dL',
      ref:(age,sex)=> sex==='Female' ? '2.5 – 6.0' : '3.5 – 7.2'}
  ],
  'Serum Electrolytes': [
    {key:'Na', label:'Sodium (Na⁺)', unit:'mEq/L', ref:()=>'135 – 145'},
    {key:'K', label:'Potassium (K⁺)', unit:'mEq/L', ref:()=>'3.5 – 5.0'},
    {key:'Cl', label:'Chloride (Cl⁻)', unit:'mEq/L', ref:()=>'98 – 107'},
    {key:'HCO3', label:'Bicarbonate', unit:'mEq/L', ref:()=>'22 – 28'}
  ],
  'Thyroid Profile (T3/T4/TSH)': [
    {key:'T3', label:'Total T3', unit:'ng/dL', ref:()=>'80 – 200'},
    {key:'T4', label:'Total T4', unit:'µg/dL', ref:()=>'5.0 – 12.0'},
    {key:'FT3', label:'Free T3', unit:'pg/mL', ref:()=>'2.3 – 4.2'},
    {key:'FT4', label:'Free T4', unit:'ng/dL', ref:()=>'0.8 – 1.8'},
    {key:'TSH', label:'TSH', unit:'mIU/L',
      ref:(age)=> age!=null && age<1 ? '0.5 – 5.0 (age-dependent)' : '0.4 – 4.5'}
  ],
  'Lipid Profile': [
    {key:'TChol', label:'Total cholesterol', unit:'mg/dL', ref:()=>'< 200 (desirable)'},
    {key:'HDL', label:'HDL cholesterol', unit:'mg/dL',
      ref:(age,sex)=> sex==='Female' ? '> 50' : '> 40'},
    {key:'LDL', label:'LDL cholesterol', unit:'mg/dL', ref:()=>'< 100 (optimal)'},
    {key:'VLDL', label:'VLDL', unit:'mg/dL', ref:()=>'5 – 40'},
    {key:'TG', label:'Triglycerides', unit:'mg/dL', ref:()=>'< 150'}
  ],
  'Random Blood Sugar (RBS)': [
    {key:'RBS', label:'Random blood sugar', unit:'mg/dL', ref:()=>'70 – 140'}
  ],
  'Fasting Blood Sugar (FBS)': [
    {key:'FBS', label:'Fasting blood sugar', unit:'mg/dL', ref:()=>'70 – 100'}
  ],
  'Post-Prandial Blood Sugar (PPBS)': [
    {key:'PPBS', label:'Post-prandial BS (2 hr)', unit:'mg/dL', ref:()=>'< 140'}
  ],
  'HbA1c': [
    {key:'HbA1c', label:'HbA1c', unit:'%', ref:()=>'< 5.7 (non-diabetic)'}
  ],
  'Urine Routine & Microscopy': [
    {key:'Colour', label:'Colour', unit:'', ref:()=>'Pale yellow'},
    {key:'Appearance', label:'Appearance', unit:'', ref:()=>'Clear'},
    {key:'pH', label:'pH', unit:'', ref:()=>'4.5 – 8.0'},
    {key:'SpGravity', label:'Specific gravity', unit:'', ref:()=>'1.005 – 1.030'},
    {key:'Protein', label:'Protein', unit:'', ref:()=>'Nil / Negative'},
    {key:'Sugar', label:'Sugar', unit:'', ref:()=>'Nil / Negative'},
    {key:'Ketones', label:'Ketones', unit:'', ref:()=>'Nil'},
    {key:'Blood', label:'Blood', unit:'', ref:()=>'Nil'},
    {key:'RBC', label:'RBC / HPF', unit:'', ref:()=>'0 – 2'},
    {key:'WBC', label:'WBC / HPF', unit:'', ref:()=>'0 – 5'},
    {key:'Epithelial', label:'Epithelial cells', unit:'', ref:()=>'Occasional'},
    {key:'Casts', label:'Casts', unit:'', ref:()=>'Nil'}
  ],
  'CRP': [
    {key:'CRP', label:'C-Reactive Protein', unit:'mg/L', ref:()=>'< 5 (or lab-specific)'}
  ],
  'ESR': [
    {key:'ESR', label:'ESR (Westergren)', unit:'mm/hr',
      ref:(age,sex)=> sex==='Female' ? '0 – 20' : '0 – 15'}
  ],
  'Serum Calcium': [
    {key:'Calcium', label:'Serum calcium', unit:'mg/dL', ref:()=>'8.5 – 10.5'}
  ],
  'Vitamin D3 Level': [
    {key:'VitD', label:'25-OH Vitamin D', unit:'ng/mL', ref:()=>'30 – 100 (sufficient)'}
  ],
  'Vitamin B12 Level': [
    {key:'B12', label:'Vitamin B12', unit:'pg/mL', ref:()=>'200 – 900'}
  ],
  'PT/INR': [
    {key:'PT', label:'Prothrombin time', unit:'sec', ref:()=>'11 – 13.5'},
    {key:'INR', label:'INR', unit:'', ref:()=>'0.8 – 1.2'},
    {key:'ISI', label:'ISI', unit:'', ref:()=>'—'}
  ],
  'Blood Grouping & Rh Typing': [
    {key:'ABO', label:'ABO group', unit:'', ref:()=>'A / B / AB / O'},
    {key:'Rh', label:'Rh typing', unit:'', ref:()=>'Positive / Negative'}
  ],
  'Serum Bilirubin (Total/Direct)': [
    {key:'TBili', label:'Total bilirubin', unit:'mg/dL', ref:()=>'0.2 – 1.2'},
    {key:'DBili', label:'Direct bilirubin', unit:'mg/dL', ref:()=>'0.0 – 0.3'},
    {key:'IBili', label:'Indirect bilirubin', unit:'mg/dL', ref:()=>'0.2 – 0.9'}
  ]
};
const PN = ['Positive','Negative'];
const RN = ['Reactive','Non-reactive'];
const DN = ['Detected','Not detected'];
const LAB_QUALITATIVE = {
  'Dengue NS1 Antigen': [{key:'NS1', label:'Dengue NS1', options:PN}],
  'Dengue IgM/IgG': [
    {key:'IgM', label:'Dengue IgM', options:PN},
    {key:'IgG', label:'Dengue IgG', options:PN}
  ],
  'Widal Test': [
    {key:'Widal', label:'Widal (overall)', options:PN},
    {key:'TO', label:'S. typhi O (TO)', options:['Negative','1:40','1:80','1:160','1:320','1:640']},
    {key:'TH', label:'S. typhi H (TH)', options:['Negative','1:40','1:80','1:160','1:320','1:640']}
  ],
  'Malaria Parasite (MP) Smear': [
    {key:'MP', label:'Malaria parasite', options:PN},
    {key:'Species', label:'Species (if positive)', options:['—','P. falciparum','P. vivax','Mixed','Other']}
  ],
  'Typhidot': [{key:'Typhidot', label:'Typhidot', options:PN}],
  'HIV Test': [{key:'HIV', label:'HIV', options:RN}],
  'HBsAg': [{key:'HBsAg', label:'HBsAg', options:RN}],
  'HCV': [{key:'HCV', label:'Anti-HCV', options:RN}],
  'VDRL': [{key:'VDRL', label:'VDRL / RPR', options:RN}],
  'Sputum for AFB': [{key:'AFB', label:'AFB smear', options:PN}],
  'Mantoux Test': [
    {key:'Mantoux', label:'Mantoux', options:PN},
    {key:'Induration', label:'Induration', options:['< 5 mm','5–9 mm','10–14 mm','≥ 15 mm']}
  ],
  'Urine Pregnancy Test': [{key:'UPT', label:'Urine pregnancy test', options:PN}],
  'COVID-19 RT-PCR / Antigen': [
    {key:'COVID', label:'COVID-19', options:DN},
    {key:'Method', label:'Method', options:['Antigen','RT-PCR','Not specified']}
  ],
  'Culture & Sensitivity (Urine)': [{key:'Growth', label:'Culture growth', options:['No growth','Growth present']}],
  'Culture & Sensitivity (Blood)': [{key:'Growth', label:'Culture growth', options:['No growth','Growth present']}]
};
function getLabQualitative(testName){
  if(!testName) return null;
  if(LAB_QUALITATIVE[testName]) return LAB_QUALITATIVE[testName];
  const n = testName.toLowerCase();
  if(n.includes('dengue') && n.includes('ns1')) return LAB_QUALITATIVE['Dengue NS1 Antigen'];
  if(n.includes('dengue')) return LAB_QUALITATIVE['Dengue IgM/IgG'];
  if(n.includes('widal')) return LAB_QUALITATIVE['Widal Test'];
  if(n.includes('malaria') || n.includes('mp smear')) return LAB_QUALITATIVE['Malaria Parasite (MP) Smear'];
  if(n.includes('typhidot')) return LAB_QUALITATIVE['Typhidot'];
  if(n.includes('hiv')) return LAB_QUALITATIVE['HIV Test'];
  if(n.includes('hbsag') || n.includes('hepatitis b')) return LAB_QUALITATIVE['HBsAg'];
  if(n.includes('hcv') || n.includes('hepatitis c')) return LAB_QUALITATIVE['HCV'];
  if(n.includes('vdrl') || n.includes('rpr')) return LAB_QUALITATIVE['VDRL'];
  if(n.includes('afb') || n.includes('sputum')) return LAB_QUALITATIVE['Sputum for AFB'];
  if(n.includes('mantoux') || n.includes('tuberculin')) return LAB_QUALITATIVE['Mantoux Test'];
  if(n.includes('pregnancy') || n.includes('upt')) return LAB_QUALITATIVE['Urine Pregnancy Test'];
  if(n.includes('covid') || n.includes('rt-pcr') || n.includes('antigen')) return LAB_QUALITATIVE['COVID-19 RT-PCR / Antigen'];
  return null;
}
function getLabPanel(testName){
  if(!testName) return null;
  if(LAB_PANELS[testName]) return LAB_PANELS[testName];
  const n = testName.toLowerCase();
  if(n.includes('cbc') || n.includes('complete blood')) return LAB_PANELS['Complete Blood Count (CBC)'];
  if(n.includes('lft') || n.includes('liver')) return LAB_PANELS['Liver Function Test (LFT)'];
  if(n.includes('rft') || n.includes('renal') || n.includes('kft')) return LAB_PANELS['Renal Function Test (RFT)'];
  if(n.includes('thyroid') || n.includes('t3') || n.includes('tsh')) return LAB_PANELS['Thyroid Profile (T3/T4/TSH)'];
  if(n.includes('lipid')) return LAB_PANELS['Lipid Profile'];
  return null;
}
function formatComponentsResult(components, panel){
  if(!components || !panel) return '';
  return panel.map(p=>{
    const v = components[p.key];
    if(v==null || String(v).trim()==='') return null;
    return `${p.label}: ${String(v).trim()}${p.unit?' '+p.unit:''}`;
  }).filter(Boolean).join('; ');
}
function qualCheckHTML(i, key, options, current){
  return `<div class="qual-opts">
    ${options.map(opt=>{
      const on = current===opt;
      return `<label class="qual-opt ${on?'qual-opt-on':''}">
        <input type="radio" name="qual-${i}-${esc(key)}" value="${esc(opt)}" ${on?'checked':''}
          data-lab-idx="${i}" data-lab-key="${esc(key)}"
          onchange="this.closest('.qual-opts').querySelectorAll('.qual-opt').forEach(x=>x.classList.remove('qual-opt-on'));this.parentElement.classList.add('qual-opt-on');">
        <span>${esc(opt)}</span>
      </label>`;
    }).join('')}
  </div>`;
}
function invResultEntryHTML(patient, investigations){
  const ageY = patientAgeYearsForBmi(patient);
  const sex = patient.sex || '';
  return investigations.map((r,i)=>{
    const qual = getLabQualitative(r.test);
    const comps = r.components || {};
    if(qual){
      const rows = qual.map(q=>`
        <div class="qual-row">
          <div class="qual-label">${esc(q.label)}</div>
          ${qualCheckHTML(i, q.key, q.options, comps[q.key]||'')}
        </div>`).join('');
      return `<div class="lab-panel">
        <h3>${esc(r.test)}${r.notes?` <span class="faint">— ${esc(r.notes)}</span>`:''}</h3>
        ${rows}
        <div class="field" style="margin-top:10px;margin-bottom:0;"><label>Additional notes</label>
          <input data-result-idx="${i}" value="${esc(r.result||'')}" placeholder="Optional remarks">
        </div>
      </div>`;
    }
    const panel = getLabPanel(r.test);
    if(panel){
      const rows = panel.map(p=>{
        const ref = typeof p.ref==='function' ? p.ref(ageY, sex) : (p.ref||'—');
        return `<div>${esc(p.label)}</div>
          <input data-lab-idx="${i}" data-lab-key="${esc(p.key)}" value="${esc(comps[p.key]||'')}" placeholder="Value">
          <div class="lab-unit">${esc(p.unit||'')}</div>
          <div class="lab-ref">${esc(ref)}</div>`;
      }).join('');
      return `<div class="lab-panel">
        <h3>${esc(r.test)}${r.notes?` <span class="faint">— ${esc(r.notes)}</span>`:''}</h3>
        <div class="lab-param-grid">
          <div class="lab-head">Parameter</div><div class="lab-head">Result</div>
          <div class="lab-head">Unit</div><div class="lab-head">Reference</div>
          ${rows}
        </div>
        <div class="field" style="margin-top:10px;margin-bottom:0;"><label>Additional notes</label>
          <input data-result-idx="${i}" value="${esc(r.result||'')}" placeholder="Free-text notes or summary">
        </div>
      </div>`;
    }
    return `<div class="lab-panel">
      <h3>${esc(r.test)}${r.notes?` <span class="faint">— ${esc(r.notes)}</span>`:''}</h3>
      <div class="field" style="margin-bottom:0;"><label>Result</label>
        <input data-result-idx="${i}" value="${esc(r.result||'')}" placeholder="Enter result when available">
      </div>
    </div>`;
  }).join('');
}


/* ============================= PEDIATRICS REFERENCE DATA ============================= */
// WHO Child Growth Standards, birth to 5 years — L/M/S (Box-Cox) parameters per
// completed month, transcribed from WHO's own published tables (cdn.who.int).
// height_boys/height_girls splice WHO's recumbent-length table (0-23 months)
// with the standing-height table (24-60 months), matching WHO's own convention
// — the small step at 24 months is expected, not an error.

const WHO_LMS = {
  weight_boys:[[0.3487,3.3464,0.14602],[0.2297,4.4709,0.13395],[0.197,5.5675,0.12385],[0.1738,6.3762,0.11727],[0.1553,7.0023,0.11316],[0.1395,7.5105,0.1108],[0.1257,7.934,0.10958],[0.1134,8.297,0.10902],[0.1021,8.6151,0.10882],[0.0917,8.9014,0.10881],[0.082,9.1649,0.10891],[0.073,9.4122,0.10906],[0.0644,9.6479,0.10925],[0.0563,9.8749,0.10949],[0.0487,10.0953,0.10976],[0.0413,10.3108,0.11007],[0.0343,10.5228,0.11041],[0.0275,10.7319,0.11079],[0.0211,10.9385,0.11119],[0.0148,11.143,0.11164],[0.0087,11.3462,0.11211],[0.0029,11.5486,0.11261],[-0.0028,11.7504,0.11314],[-0.0083,11.9514,0.11369],[-0.0137,12.1515,0.11426],[-0.0189,12.3502,0.11485],[-0.024,12.5466,0.11544],[-0.0289,12.7401,0.11604],[-0.0337,12.9303,0.11664],[-0.0385,13.1169,0.11723],[-0.0431,13.3,0.11781],[-0.0476,13.4798,0.11839],[-0.052,13.6567,0.11896],[-0.0564,13.8309,0.11953],[-0.0606,14.0031,0.12008],[-0.0648,14.1736,0.12062],[-0.0689,14.3429,0.12116],[-0.0729,14.5113,0.12168],[-0.0769,14.6791,0.1222],[-0.0808,14.8466,0.12271],[-0.0846,15.014,0.12322],[-0.0883,15.1813,0.12373],[-0.092,15.3486,0.12425],[-0.0957,15.5158,0.12478],[-0.0993,15.6828,0.12531],[-0.1028,15.8497,0.12586],[-0.1063,16.0163,0.12643],[-0.1097,16.1827,0.127],[-0.1131,16.3489,0.12759],[-0.1165,16.515,0.12819],[-0.1198,16.6811,0.1288],[-0.123,16.8471,0.12943],[-0.1262,17.0132,0.13005],[-0.1294,17.1792,0.13069],[-0.1325,17.3452,0.13133],[-0.1356,17.5111,0.13197],[-0.1387,17.6768,0.13261],[-0.1417,17.8422,0.13325],[-0.1447,18.0073,0.13389],[-0.1477,18.1722,0.13453],[-0.1506,18.3366,0.13517]],
  weight_girls:[[0.3809,3.2322,0.14171],[0.1714,4.1873,0.13724],[0.0962,5.1282,0.13],[0.0402,5.8458,0.12619],[-0.005,6.4237,0.12402],[-0.043,6.8985,0.12274],[-0.0756,7.297,0.12204],[-0.1039,7.6422,0.12178],[-0.1288,7.9487,0.12181],[-0.1507,8.2254,0.12199],[-0.17,8.48,0.12223],[-0.1872,8.7192,0.12247],[-0.2024,8.9481,0.12268],[-0.2158,9.1699,0.12283],[-0.2278,9.387,0.12294],[-0.2384,9.6008,0.12299],[-0.2478,9.8124,0.12303],[-0.2562,10.0226,0.12306],[-0.2637,10.2315,0.12309],[-0.2703,10.4393,0.12315],[-0.2762,10.6464,0.12323],[-0.2815,10.8534,0.12335],[-0.2862,11.0608,0.1235],[-0.2903,11.2688,0.12369],[-0.2941,11.4775,0.1239],[-0.2975,11.6864,0.12414],[-0.3005,11.8947,0.12441],[-0.3032,12.1015,0.12472],[-0.3057,12.3059,0.12506],[-0.308,12.5073,0.12545],[-0.3101,12.7055,0.12587],[-0.312,12.9006,0.12633],[-0.3138,13.093,0.12683],[-0.3155,13.2837,0.12737],[-0.3171,13.4731,0.12794],[-0.3186,13.6618,0.12855],[-0.3201,13.8503,0.12919],[-0.3216,14.0385,0.12988],[-0.323,14.2265,0.13059],[-0.3243,14.414,0.13135],[-0.3257,14.601,0.13213],[-0.327,14.7873,0.13293],[-0.3283,14.9727,0.13376],[-0.3296,15.1573,0.1346],[-0.3309,15.341,0.13545],[-0.3322,15.524,0.1363],[-0.3335,15.7064,0.13716],[-0.3348,15.8882,0.138],[-0.3361,16.0697,0.13884],[-0.3374,16.2511,0.13968],[-0.3387,16.4322,0.14051],[-0.34,16.6133,0.14132],[-0.3414,16.7942,0.14213],[-0.3427,16.9748,0.14293],[-0.344,17.1551,0.14371],[-0.3453,17.3347,0.14448],[-0.3466,17.5136,0.14525],[-0.3479,17.6916,0.146],[-0.3492,17.8686,0.14675],[-0.3505,18.0445,0.14748],[-0.3518,18.2193,0.14821]],
  height_boys:[[1,49.8842,0.03795],[1,54.7244,0.03557],[1,58.4249,0.03424],[1,61.4292,0.03328],[1,63.886,0.03257],[1,65.9026,0.03204],[1,67.6236,0.03165],[1,69.1645,0.03139],[1,70.5994,0.03124],[1,71.9687,0.03117],[1,73.2812,0.03118],[1,74.5388,0.03125],[1,75.7488,0.03137],[1,76.9186,0.03154],[1,78.0497,0.03174],[1,79.1458,0.03197],[1,80.2113,0.03222],[1,81.2487,0.0325],[1,82.2587,0.03279],[1,83.2418,0.0331],[1,84.1996,0.03342],[1,85.1348,0.03376],[1,86.0477,0.0341],[1,86.941,0.03445],[1,87.1161,0.03507],[1,87.972,0.03542],[1,88.8065,0.03576],[1,89.6197,0.0361],[1,90.412,0.03642],[1,91.1828,0.03674],[1,91.9327,0.03704],[1,92.6631,0.03733],[1,93.3753,0.03761],[1,94.0711,0.03787],[1,94.7532,0.03812],[1,95.4236,0.03836],[1,96.0835,0.03858],[1,96.7337,0.03879],[1,97.3749,0.039],[1,98.0073,0.03919],[1,98.631,0.03937],[1,99.2459,0.03954],[1,99.8515,0.03971],[1,100.448,0.03986],[1,101.037,0.04002],[1,101.619,0.04016],[1,102.193,0.04031],[1,102.763,0.04045],[1,103.327,0.04059],[1,103.889,0.04073],[1,104.447,0.04086],[1,105.004,0.041],[1,105.56,0.04113],[1,106.114,0.04126],[1,106.667,0.04139],[1,107.219,0.04152],[1,107.77,0.04165],[1,108.32,0.04177],[1,108.869,0.0419],[1,109.417,0.04202],[1,109.964,0.04214]],
  height_girls:[[1,49.1477,0.0379],[1,53.6872,0.0364],[1,57.0673,0.03568],[1,59.8029,0.0352],[1,62.0899,0.03486],[1,64.0301,0.03463],[1,65.7311,0.03448],[1,67.2873,0.03441],[1,68.7498,0.0344],[1,70.1435,0.03444],[1,71.4818,0.03452],[1,72.771,0.03464],[1,74.015,0.03479],[1,75.2176,0.03496],[1,76.3817,0.03514],[1,77.5099,0.03534],[1,78.6055,0.03555],[1,79.671,0.03576],[1,80.7079,0.03598],[1,81.7182,0.0362],[1,82.7036,0.03643],[1,83.6654,0.03666],[1,84.604,0.03688],[1,85.5202,0.03711],[1,85.7153,0.03764],[1,86.5904,0.03786],[1,87.4462,0.03808],[1,88.283,0.0383],[1,89.1004,0.03851],[1,89.8991,0.03872],[1,90.6797,0.03893],[1,91.443,0.03913],[1,92.1906,0.03933],[1,92.9239,0.03952],[1,93.6444,0.03971],[1,94.3533,0.03989],[1,95.0515,0.04006],[1,95.7399,0.04024],[1,96.4187,0.04041],[1,97.0885,0.04057],[1,97.7493,0.04073],[1,98.4015,0.04089],[1,99.0448,0.04105],[1,99.6795,0.0412],[1,100.306,0.04135],[1,100.924,0.0415],[1,101.534,0.04164],[1,102.136,0.04179],[1,102.731,0.04193],[1,103.32,0.04206],[1,103.902,0.0422],[1,104.479,0.04233],[1,105.049,0.04246],[1,105.615,0.04259],[1,106.175,0.04272],[1,106.73,0.04285],[1,107.279,0.04298],[1,107.823,0.0431],[1,108.361,0.04322],[1,108.895,0.04334],[1,109.423,0.04347]],
  hc_boys:[[1,34.4618,0.03686],[1,37.2759,0.03133],[1,39.1285,0.02997],[1,40.5135,0.02918],[1,41.6317,0.02868],[1,42.5576,0.02837],[1,43.3306,0.02817],[1,43.9803,0.02804],[1,44.53,0.02796],[1,44.9998,0.02792],[1,45.4051,0.0279],[1,45.7573,0.02789],[1,46.0661,0.02789],[1,46.3395,0.02789],[1,46.5844,0.02791],[1,46.806,0.02792],[1,47.0088,0.02795],[1,47.1962,0.02797],[1,47.3711,0.028],[1,47.5357,0.02803],[1,47.6919,0.02806],[1,47.8408,0.0281],[1,47.9833,0.02813],[1,48.1201,0.02817],[1,48.2515,0.02821],[1,48.3777,0.02825],[1,48.4989,0.0283],[1,48.6151,0.02834],[1,48.7264,0.02838],[1,48.8331,0.02842],[1,48.9351,0.02847],[1,49.0327,0.02851],[1,49.126,0.02855],[1,49.2153,0.02859],[1,49.3007,0.02863],[1,49.3826,0.02867],[1,49.4612,0.02871],[1,49.5367,0.02875],[1,49.6093,0.02878],[1,49.6791,0.02882],[1,49.7465,0.02886],[1,49.8116,0.02889],[1,49.8745,0.02893],[1,49.9354,0.02896],[1,49.9942,0.02899],[1,50.0512,0.02903],[1,50.1064,0.02906],[1,50.1598,0.02909],[1,50.2115,0.02912],[1,50.2617,0.02915],[1,50.3105,0.02918],[1,50.3578,0.02921],[1,50.4039,0.02924],[1,50.4488,0.02927],[1,50.4926,0.02929],[1,50.5354,0.02932],[1,50.5772,0.02935],[1,50.6183,0.02938],[1,50.6587,0.0294],[1,50.6984,0.02943],[1,50.7375,0.02946]],
  hc_girls:[[1,33.8787,0.03496],[1,36.5463,0.0321],[1,38.2521,0.03168],[1,39.5328,0.0314],[1,40.5817,0.03119],[1,41.459,0.03102],[1,42.1995,0.03087],[1,42.829,0.03075],[1,43.3671,0.03063],[1,43.83,0.03053],[1,44.2319,0.03044],[1,44.5844,0.03035],[1,44.8965,0.03027],[1,45.1752,0.03019],[1,45.4265,0.03012],[1,45.6551,0.03006],[1,45.865,0.02999],[1,46.0598,0.02993],[1,46.2424,0.02987],[1,46.4152,0.02982],[1,46.5801,0.02977],[1,46.7384,0.02972],[1,46.8913,0.02967],[1,47.0391,0.02962],[1,47.1822,0.02957],[1,47.3204,0.02953],[1,47.4536,0.02949],[1,47.5817,0.02945],[1,47.7045,0.02941],[1,47.8219,0.02937],[1,47.934,0.02933],[1,48.041,0.02929],[1,48.1432,0.02926],[1,48.2408,0.02922],[1,48.3343,0.02919],[1,48.4239,0.02915],[1,48.5099,0.02912],[1,48.5926,0.02909],[1,48.6722,0.02906],[1,48.7489,0.02903],[1,48.8228,0.029],[1,48.8941,0.02897],[1,48.9629,0.02894],[1,49.0294,0.02891],[1,49.0937,0.02888],[1,49.156,0.02886],[1,49.2164,0.02883],[1,49.2751,0.0288],[1,49.3321,0.02878],[1,49.3877,0.02875],[1,49.4419,0.02873],[1,49.4947,0.0287],[1,49.5464,0.02868],[1,49.5969,0.02865],[1,49.6464,0.02863],[1,49.6947,0.02861],[1,49.7421,0.02859],[1,49.7885,0.02856],[1,49.8341,0.02854],[1,49.8789,0.02852],[1,49.9229,0.0285]]
};

// Abramowitz-Stegun erf approximation -> standard normal CDF -> LMS percentile.
function erf(x){
  const sign = x<0? -1:1; x=Math.abs(x);
  const a1=0.254829592,a2=-0.284496736,a3=1.421413741,a4=-1.453152027,a5=1.061405429,p=0.3275911;
  const t=1/(1+p*x);
  const y=1-(((((a5*t+a4)*t)+a3)*t+a2)*t+a1)*t*Math.exp(-x*x);
  return sign*y;
}
function normalCDF(z){ return 0.5*(1+erf(z/Math.SQRT2)); }
function lmsToPercentile(value, L, M, S){
  let z;
  if(Math.abs(L) < 1e-6){ z = Math.log(value/M)/S; }
  else { z = (Math.pow(value/M, L) - 1) / (L*S); }
  return { z, percentile: normalCDF(z)*100 };
}
// Linear-interpolates L/M/S between the two nearest completed months.
function lmsAt(table, ageMonths){
  const m = Math.max(0, Math.min(60, ageMonths));
  const lo = Math.floor(m), hi = Math.ceil(m);
  const row = table[lo];
  if(lo===hi) return row;
  const frac = m - lo;
  const row2 = table[hi];
  return [row[0]+(row2[0]-row[0])*frac, row[1]+(row2[1]-row[1])*frac, row[2]+(row2[2]-row[2])*frac];
}
function percentileBand(p){
  if(p < 3) return {label:'Below normal range', cls:'band-low'};
  if(p < 15) return {label:'Lower normal range', cls:'band-mid'};
  if(p <= 85) return {label:'Normal range', cls:'band-ok'};
  if(p <= 97) return {label:'Upper normal range', cls:'band-mid'};
  return {label:'Above normal range', cls:'band-low'};
}
function growthPercentile(measure, sex, ageMonths, value){
  const key = measure + '_' + (sex==='Female'?'girls':'boys');
  const table = WHO_LMS[key];
  if(!table || !value || ageMonths<0 || ageMonths>60) return null;
  const [L,M,S] = lmsAt(table, ageMonths);
  const {percentile} = lmsToPercentile(value, L, M, S);
  const clamped = Math.max(0.1, Math.min(99.9, percentile));
  return { percentile: clamped, ...percentileBand(clamped) };
}

// ---- Growth chart (SVG, self-contained — no charting library) ----
// Standard Z-scores for the WHO 3rd/15th/50th/85th/97th percentile lines.
const GROWTH_Z_BANDS = [
  {z:-1.8808, label:'3rd'}, {z:-1.0364, label:'15th'}, {z:0, label:'50th'},
  {z:1.0364, label:'85th'}, {z:1.8808, label:'97th'}
];
// Exact inverse of the Box-Cox transform used by lmsToPercentile — given a
// fixed Z, returns the measurement value that sits at that Z for this L/M/S.
function lmsValueAtZ(L, M, S, Z){
  if(Math.abs(L) < 1e-6) return M * Math.exp(S*Z);
  return M * Math.pow(1 + L*S*Z, 1/L);
}
function growthCurveData(measure, sex){
  const table = WHO_LMS[measure + '_' + (sex==='Female'?'girls':'boys')];
  if(!table) return [];
  return GROWTH_Z_BANDS.map(band => ({
    label: band.label,
    points: table.map((row,m) => ({month:m, value: lmsValueAtZ(row[0],row[1],row[2],band.z)}))
  }));
}
const GROWTH_MEASURE_META = {
  weight: {title:'Weight-for-age', unit:'kg'},
  height: {title:'Height/Length-for-age', unit:'cm'},
  hc: {title:'Head circumference-for-age', unit:'cm'}
};
function growthChartSVG(measure, sex, childAgeMonths, childValue){
  const curves = growthCurveData(measure, sex);
  if(!curves.length) return '';
  const allVals = curves.flatMap(c=>c.points.map(p=>p.value));
  if(childValue!=null) allVals.push(childValue);
  let minV = Math.min(...allVals), maxV = Math.max(...allVals);
  const pad = (maxV-minV)*0.08 || 1;
  minV -= pad; maxV += pad;

  const W=620, H=280, ML=42, MR=12, MT=16, MB=30;
  const PW=W-ML-MR, PH=H-MT-MB;
  const xS = m => ML + (Math.min(60,Math.max(0,m))/60)*PW;
  const yS = v => MT + (1-(v-minV)/(maxV-minV))*PH;

  const lineColor = l => l==='50th' ? 'var(--primary)' : (l==='15th'||l==='85th') ? 'var(--accent)' : 'var(--danger)';
  const paths = curves.map(c=>{
    const d = c.points.map((p,i)=> (i===0?'M':'L')+xS(p.month).toFixed(1)+','+yS(p.value).toFixed(1)).join(' ');
    const isMedian = c.label==='50th';
    return `<path d="${d}" fill="none" stroke="${lineColor(c.label)}" stroke-width="${isMedian?2:1.2}" stroke-dasharray="${isMedian?'none':'4,3'}" opacity="${isMedian?1:0.8}"/>`;
  }).join('');
  // Small end-of-line labels for each band, at the right edge.
  const endLabels = curves.map(c=>{
    const last = c.points[c.points.length-1];
    return `<text x="${xS(last.month)+3}" y="${yS(last.value)+3}" font-size="8.5" fill="${lineColor(c.label)}">${c.label}</text>`;
  }).join('');

  let xTicks = '';
  for(let m=0;m<=60;m+=12){
    xTicks += `<line x1="${xS(m)}" y1="${MT}" x2="${xS(m)}" y2="${MT+PH}" stroke="var(--line)" stroke-width="1"/>
      <text x="${xS(m)}" y="${MT+PH+16}" font-size="9" fill="var(--ink-soft)" text-anchor="middle">${m/12}y</text>`;
  }
  let yTicks = '';
  for(let i=0;i<=4;i++){
    const v = minV + (maxV-minV)*i/4;
    yTicks += `<line x1="${ML}" y1="${yS(v)}" x2="${ML+PW}" y2="${yS(v)}" stroke="var(--line)" stroke-width="0.6"/>
      <text x="${ML-6}" y="${yS(v)+3}" font-size="9" fill="var(--ink-soft)" text-anchor="end">${v.toFixed(1)}</text>`;
  }

  let childMarker = '';
  if(childValue!=null && childAgeMonths!=null){
    childMarker = `<circle cx="${xS(childAgeMonths)}" cy="${yS(childValue)}" r="5.5" fill="var(--accent)" stroke="#fff" stroke-width="2"/>`;
  }

  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:auto;display:block;" xmlns="http://www.w3.org/2000/svg">
    ${yTicks}${xTicks}${paths}${endLabels}${childMarker}
  </svg>`;
}
function growthChartCardHTML(measure, sex, childAgeMonths, childValue){
  const meta = GROWTH_MEASURE_META[measure];
  return `<div class="card" style="padding:12px 10px;margin-bottom:8px;">
    <div class="faint" style="margin-bottom:6px;">${meta.title} (${meta.unit}) — dashed lines 3rd/15th/85th/97th, solid line 50th, dot is this reading</div>
    ${growthChartSVG(measure, sex, childAgeMonths, childValue)}
  </div>`;
}

// ---- Pediatric weight-based dose formulary (reference only) ----
// mgPerKg is per single dose unless noted; always shown with a "confirm
// before prescribing" note in the UI, and capped at maxMg where relevant.
const PEDIATRIC_DOSE_DB = [
  {name:'Paracetamol', mgPerKg:15, maxMg:500, freq:'Every 6 hours (max 4 doses/day)', form:'Syrup 125mg/5ml or 250mg/5ml', conc:[125,250]},
  {name:'Ibuprofen', mgPerKg:10, maxMg:400, freq:'Every 6-8 hours', form:'Syrup 100mg/5ml', conc:[100]},
  {name:'Amoxicillin', mgPerKg:25, maxMg:500, freq:'Per dose, BD (total ~50mg/kg/day)', form:'Syrup 125mg/5ml or 250mg/5ml', conc:[125,250]},
  {name:'Amoxicillin + Clavulanic Acid', mgPerKg:22.5, maxMg:625, freq:'Per dose, BD (amoxicillin component)', form:'Syrup 228.5mg/5ml (as amoxicillin)', conc:[228.5]},
  {name:'Azithromycin', mgPerKg:10, maxMg:500, freq:'OD for 3 days', form:'Syrup 200mg/5ml', conc:[200]},
  {name:'Cefixime', mgPerKg:4, maxMg:200, freq:'Per dose, BD (total ~8mg/kg/day)', form:'Syrup 100mg/5ml', conc:[100]},
  {name:'Cefpodoxime', mgPerKg:5, maxMg:200, freq:'Per dose, BD (total ~10mg/kg/day)', form:'Syrup 50mg/5ml or 100mg/5ml', conc:[50,100]},
  {name:'Metronidazole', mgPerKg:7.5, maxMg:400, freq:'Every 8 hours', form:'Syrup 200mg/5ml', conc:[200]},
  {name:'Ceftriaxone (Inj.)', mgPerKg:50, maxMg:2000, freq:'OD or BD (per day total, 50-75mg/kg/day)', form:'Injection', conc:null},
  {name:'Domperidone', mgPerKg:0.3, maxMg:10, freq:'Every 8 hours before food', form:'Syrup 5mg/5ml', conc:[5]},
  {name:'Ondansetron', mgPerKg:0.15, maxMg:4, freq:'Every 8 hours as needed', form:'Syrup 2mg/5ml', conc:[2]},
  {name:'Salbutamol', mgPerKg:0.1, maxMg:4, freq:'Every 8 hours', form:'Syrup 2mg/5ml', conc:[2]},
  {name:'Cetirizine', mgPerKg:0.25, maxMg:10, freq:'OD or BD', form:'Syrup 5mg/5ml', conc:[5]},
  {name:'Iron (elemental)', mgPerKg:4, maxMg:150, freq:'OD (total 3-6mg/kg/day elemental iron)', form:'Syrup / drops — concentration varies by brand', conc:null},
  {name:'Ceftriaxone / Cefixime alt — Ofloxacin', mgPerKg:7.5, maxMg:200, freq:'Every 12 hours', form:'Syrup 50mg/5ml', conc:[50]},
  {name:'Diclofenac', mgPerKg:1, maxMg:50, freq:'Every 8 hours (use cautiously in young children)', form:'Syrup / suspension — concentration varies by brand', conc:null},
  {name:'Ranitidine', mgPerKg:2, maxMg:150, freq:'Every 12 hours', form:'Syrup 75mg/5ml', conc:[75]},
  {name:'Prednisolone', mgPerKg:1, maxMg:40, freq:'OD, short course as directed', form:'Syrup 15mg/5ml', conc:[15]}
];

// ---- IAP-aligned immunization schedule (reference; confirm current IAP/UIP guidance) ----
const IMMUNIZATION_SCHEDULE = [
  {age:'Birth', vaccines:'BCG, Hepatitis B-1, OPV-0'},
  {age:'6 weeks', vaccines:'DTwP/DTaP-1, IPV-1, Hib-1, Hepatitis B-2, Rotavirus-1, PCV-1'},
  {age:'10 weeks', vaccines:'DTwP/DTaP-2, IPV-2, Hib-2, Rotavirus-2, PCV-2'},
  {age:'14 weeks', vaccines:'DTwP/DTaP-3, IPV-3, Hib-3, Hepatitis B-3, Rotavirus-3, PCV-3'},
  {age:'6 months', vaccines:'OPV-2 (UIP), Influenza-1 (annual, from 6 months)'},
  {age:'9 months', vaccines:'Measles-Rubella / MMR-1, Vitamin A-1'},
  {age:'9-12 months', vaccines:'Typhoid Conjugate Vaccine (TCV)'},
  {age:'12 months', vaccines:'Hepatitis A-1'},
  {age:'15 months', vaccines:'MMR-2, Varicella-1, PCV booster'},
  {age:'16-18 months', vaccines:'DTwP/DTaP booster-1, IPV booster-1, Hib booster-1'},
  {age:'18-19 months', vaccines:'Hepatitis A-2 (6 months after dose 1)'},
  {age:'2 years', vaccines:'Typhoid booster (repeat every 3 years)'},
  {age:'4-6 years', vaccines:'DTwP/DTaP booster-2, OPV booster, MMR-3, Varicella-2'},
  {age:'9-14 years', vaccines:'HPV (2 doses, 6 months apart) — for girls (and boys per current IAP advice)'},
  {age:'10-12 years', vaccines:'Tdap/Td booster'}
];

// ---- Normal vital sign ranges by age (reference) ----
const PEDIATRIC_VITALS_RANGES = [
  {age:'Newborn (0-1 month)', hr:'100-160 /min', rr:'30-60 /min', sbp:'60-90 mmHg'},
  {age:'Infant (1-12 months)', hr:'100-150 /min', rr:'25-40 /min', sbp:'70-100 mmHg'},
  {age:'Toddler (1-3 years)', hr:'90-140 /min', rr:'20-30 /min', sbp:'80-110 mmHg'},
  {age:'Preschool (3-5 years)', hr:'80-120 /min', rr:'20-25 /min', sbp:'80-110 mmHg'},
  {age:'School age (6-12 years)', hr:'70-110 /min', rr:'15-20 /min', sbp:'85-120 mmHg'},
  {age:'Adolescent (12+ years)', hr:'60-100 /min', rr:'12-16 /min', sbp:'90-120 mmHg'}
];

// ---- Developmental milestones (reference) ----
const DEVELOPMENTAL_MILESTONES = [
  {age:'2 months', milestone:'Social smile, follows objects with eyes, coos'},
  {age:'4 months', milestone:'Good head control, laughs, reaches for objects'},
  {age:'6 months', milestone:'Sits with support, babbles, rolls over'},
  {age:'9 months', milestone:'Sits without support, crawls, pincer grasp emerging, says "mama/dada" non-specifically'},
  {age:'12 months', milestone:'Stands with support, says 1-2 meaningful words, waves bye-bye'},
  {age:'15 months', milestone:'Walks alone, says 3-6 words, uses a spoon (spills)'},
  {age:'18 months', milestone:'Runs, 10-15 words, points to body parts'},
  {age:'24 months', milestone:'2-word phrases, climbs stairs with support, kicks a ball'},
  {age:'3 years', milestone:'3-word sentences, rides a tricycle, knows own name and age'},
  {age:'4 years', milestone:'Hops on one foot, tells simple stories, draws a circle/cross'},
  {age:'5 years', milestone:'Skips, prints some letters, dresses independently'}
];

// ---- Medical-term suggestion lists (chip suggestions while typing) ----
const COMPLAINT_TERMS = [
  'Fever','Cough','Cold','Sore throat','Vomiting','Loose stools','Diarrhea','Constipation',
  'Abdominal pain','Headache','Body ache','Breathlessness','Chest pain','Dizziness','Weakness',
  'Loss of appetite','Burning micturition','Joint pain','Back pain','Skin rash','Itching',
  'Ear pain','Eye redness','Swelling','Injury/trauma','Bleeding','Fainting/syncope','Palpitations',
  'Nausea','Giddiness','Weight loss','Weight gain','Fatigue','Insomnia','Numbness','Tingling',
  'Seizures','Yellowish discoloration of eyes','Decreased urine output','Increased thirst',
  'Excessive hunger','Night sweats','Cough with expectoration','Difficulty breathing','Wheeze',
  'Runny nose','Nasal block','Irritability (child)','Poor feeding (infant)','Excessive crying (infant)'
];
const HOPI_PHRASES = [
  'Sudden onset','Gradual onset','Insidious onset','Since 1 day','Since 2 days','Since 3 days',
  'Since 1 week','Since 2 weeks','Since 1 month','Intermittent','Continuous','Progressive',
  'Associated with','Aggravated by','Relieved by','No aggravating factors','No relieving factors',
  'Radiating to','No radiation','No history of similar complaints in the past',
  'History of similar complaints in the past','No history of trauma','History of trauma',
  'Not associated with fever','Associated with fever','No history of similar illness in family',
  'History of contact with similar illness','On self-medication with','No prior medication taken'
];
const DIAGNOSIS_TERMS = [
  'Viral fever','Acute gastroenteritis','Upper respiratory tract infection (URTI)',
  'Lower respiratory tract infection (LRTI)','Acute bronchitis','Bronchial asthma','Pneumonia',
  'Urinary tract infection (UTI)','Type 2 Diabetes Mellitus','Essential Hypertension',
  'Acid peptic disease','Gastroesophageal reflux disease (GERD)','Irritable bowel syndrome',
  'Migraine','Tension headache','Anemia','Iron deficiency anemia','Allergic rhinitis','Sinusitis',
  'Pharyngitis','Tonsillitis','Otitis media','Conjunctivitis','Dermatitis','Fungal skin infection',
  'Scabies','Urticaria','Osteoarthritis','Low back pain','Cervical spondylosis','Hypothyroidism',
  'Hyperthyroidism','Dyslipidemia','Chronic kidney disease','Ischemic heart disease',
  'Chronic obstructive pulmonary disease (COPD)','Typhoid fever','Dengue fever','Malaria',
  'Tuberculosis','Viral hepatitis','Vitamin D deficiency','Vitamin B12 deficiency','Obesity',
  'Anxiety disorder','Acute febrile illness','Acute pharyngotonsillitis'
];


function medicineOptionsList(){
  const custom = (state.data.customMedicines||[]).map(m=>({name:m.name, dosages:m.dosages||[]}));
  return custom.concat(MEDICINE_DB);
}

function daysLabel(duration){
  const trimmed = (duration||'').toString().trim();
  if(!trimmed) return '';
  const n = parseInt(trimmed,10);
  if(!isNaN(n) && n>0) return `${n} day${n===1?'':'s'}`;
  return trimmed;
}

// Converts a frequency like "1-0-1" or "BD (twice daily)" into doses-per-day.
// Returns null when it can't be determined (e.g. "STAT" or free text) so
// quantity calculation is simply skipped rather than guessed.
function parseFrequencyPerDay(freq){
  if(!freq) return null;
  const f = freq.trim().toLowerCase();
  const dashParts = f.split('-').map(s=>s.trim());
  if(dashParts.length>=2 && dashParts.every(p=>/^\d+(\.\d+)?$/.test(p))){
    const sum = dashParts.reduce((a,b)=>a+parseFloat(b),0);
    return sum>0 ? sum : null;
  }
  const head = f.split(/[\s(]/)[0];
  const map = {od:1,bd:2,tds:3,tid:3,qid:4,hs:1};
  return map[head] !== undefined ? map[head] : null;
}

// Only tablets/capsules get a "how many to buy" total — syrups, injections
// and IV fluids don't map to a simple per-dose count the same way.
function computeQuantityLabel(medicine, freq, duration){
  const m = (medicine||'').trim().toLowerCase();
  let unit = null;
  if(m.startsWith('tab.')) unit = 'tablet';
  else if(m.startsWith('cap.')) unit = 'capsule';
  if(!unit) return '';
  const perDay = parseFrequencyPerDay(freq);
  const days = parseInt(duration,10);
  if(!perDay || !days || days<=0) return '';
  const qty = Math.ceil(perDay*days);
  return `Total: ${qty} ${unit}${qty===1?'':'s'}`;
}

// ---- Dropdown pickers (Medicine / Dosage / Frequency / Investigation) ----
// Plain native <select> elements — same control type as the Sex field —
// paired with a free-text input. Picking an option fills the text input
// (which is what actually gets saved); typing directly works too.
function dosageOptionsFor(medicineName){
  const match = medicineOptionsList().find(m=>m.name.toLowerCase()===((medicineName||'').trim().toLowerCase()));
  return (match && match.dosages && match.dosages.length) ? match.dosages : COMMON_DOSAGES;
}
function dosageOptionsHTML(medicineName, currentDosage){
  const opts = dosageOptionsFor(medicineName);
  return `<option value="">Select…</option>` + opts.map(d=>`<option value="${esc(d)}" ${currentDosage===d?'selected':''}>${esc(d)}</option>`).join('');
}
function pickMedicine(i, name){
  const row = document.querySelector(`[data-rx-idx="${i}"]`);
  row.querySelector('[data-f="medicine"]').value = name;
  state.draftVisit.prescriptions[i].medicine = name;
  const doseSel = document.getElementById('rx-dose-select-'+i);
  if(doseSel) doseSel.innerHTML = dosageOptionsHTML(name, state.draftVisit.prescriptions[i].dosage);
  updateRxAllergyWarning(i);
  updateRxDoseHint(i);
}
function pickDosage(i, val){
  if(!val) return;
  const row = document.querySelector(`[data-rx-idx="${i}"]`);
  row.querySelector('[data-f="dosage"]').value = val;
  state.draftVisit.prescriptions[i].dosage = val;
}
function pickFrequency(i, val){
  if(!val) return;
  const row = document.querySelector(`[data-rx-idx="${i}"]`);
  row.querySelector('[data-f="frequency"]').value = val;
  state.draftVisit.prescriptions[i].frequency = val;
}
function pickInvTest(i, val){
  if(!val) return;
  const row = document.querySelector(`[data-inv-idx="${i}"]`);
  row.querySelector('[data-f="test"]').value = val;
  state.draftVisit.investigations[i].test = val;
}

// Saves whatever's currently typed in a row's Medicine + Dosage fields into
// the clinic's own medicine list, so it shows up as a suggestion next time.
async function saveMedicineToLibrary(i, btn){
  const row = document.querySelector(`[data-rx-idx="${i}"]`);
  const name = row.querySelector('[data-f="medicine"]').value.trim();
  const dosage = row.querySelector('[data-f="dosage"]').value.trim();
  if(!name){ btn.textContent = 'Type a medicine name first'; setTimeout(()=>{btn.textContent='+ Save this medicine to my list';},1800); return; }
  if(!state.data.customMedicines) state.data.customMedicines = [];
  let entry = state.data.customMedicines.find(m=>m.name.toLowerCase()===name.toLowerCase());
  if(!entry){ entry = {name, dosages:[]}; state.data.customMedicines.push(entry); }
  if(dosage && !entry.dosages.includes(dosage)) entry.dosages.push(dosage);
  logAudit('Saved medicine to library', dosage ? `${name} (${dosage})` : name);
  const ok = await saveData();
  btn.textContent = ok ? 'Saved ✓' : 'Could not save — try again';
  setTimeout(()=>{ if(btn) btn.textContent = '+ Save this medicine to my list'; }, 1800);
}

function selectedInvTests(){
  return (state.draftVisit.investigations||[]).filter(r=>r && r.test).map(r=>r.test);
}
function isInvSelected(test){
  return selectedInvTests().includes(test);
}
function toggleInvCheck(test){
  if(!state.draftVisit.investigations) state.draftVisit.investigations = [];
  const list = state.draftVisit.investigations;
  const idx = list.findIndex(r=>r.test===test);
  if(idx >= 0) list.splice(idx,1);
  else list.push({test, notes:''});
  // Drop empty placeholder rows
  state.draftVisit.investigations = list.filter(r=>r.test);
  const box = document.getElementById('inv-rows');
  if(box) box.innerHTML = invRowsHTML();
}
function setInvNotes(test, notes){
  const r = (state.draftVisit.investigations||[]).find(x=>x.test===test);
  if(r) r.notes = notes;
}
function addCustomInv(){
  const el = document.getElementById('inv-custom');
  if(!el) return;
  const test = el.value.trim();
  if(!test) return;
  if(!state.draftVisit.investigations) state.draftVisit.investigations = [];
  if(!isInvSelected(test)) state.draftVisit.investigations.push({test, notes:''});
  state.draftVisit.investigations = state.draftVisit.investigations.filter(r=>r.test);
  el.value = '';
  const box = document.getElementById('inv-rows');
  if(box) box.innerHTML = invRowsHTML();
}
function clearAllInv(){
  state.draftVisit.investigations = [];
  const box = document.getElementById('inv-rows');
  if(box) box.innerHTML = invRowsHTML();
}
function invRowsHTML(){
  const selected = selectedInvTests();
  const selectedSet = new Set(selected);
  // Custom tests not in the standard list
  const custom = (state.draftVisit.investigations||[]).filter(r=>r.test && !INVESTIGATION_DB.includes(r.test));

  const groupsHtml = INVESTIGATION_GROUPS.map(g=>{
    const items = g.tests.map(t=>{
      const checked = selectedSet.has(t);
      return `<label class="inv-check ${checked?'inv-check-on':''}">
        <input type="checkbox" ${checked?'checked':''} onchange="toggleInvCheck(${JSON.stringify(t)})">
        <span>${esc(t)}</span>
      </label>`;
    }).join('');
    return `<div class="inv-group">
      <div class="inv-group-title">${esc(g.name)}</div>
      <div class="inv-check-grid">${items}</div>
    </div>`;
  }).join('');

  const customHtml = custom.length ? `
    <div class="inv-group">
      <div class="inv-group-title">Other / custom</div>
      <div class="inv-check-grid">
        ${custom.map(r=>`<label class="inv-check inv-check-on">
          <input type="checkbox" checked onchange="toggleInvCheck(${JSON.stringify(r.test)})">
          <span>${esc(r.test)}</span>
        </label>`).join('')}
      </div>
    </div>` : '';

  const selectedPanel = selected.length ? `
    <div class="inv-selected">
      <div class="rx-row-head" style="margin-bottom:8px;">
        <strong>${selected.length} selected</strong>
        <button type="button" class="btn btn-ghost btn-sm" onclick="clearAllInv()">Clear all</button>
      </div>
      ${(state.draftVisit.investigations||[]).filter(r=>r.test).map(r=>`
        <div class="inv-selected-row">
          <span class="pill">${esc(r.test)}</span>
          <input type="text" placeholder="Clinical note (optional)" value="${esc(r.notes||'')}"
            oninput="setInvNotes(${JSON.stringify(r.test)}, this.value)">
          <button type="button" class="btn btn-ghost btn-sm" onclick="toggleInvCheck(${JSON.stringify(r.test)})">✕</button>
        </div>`).join('')}
    </div>` : `<p class="faint" style="margin:8px 0 12px;">Tick the tests needed below — selected ones appear here.</p>`;

  return `
    ${selectedPanel}
    ${groupsHtml}
    ${customHtml}
    <div class="row" style="margin-top:12px;align-items:flex-end;">
      <div class="field" style="flex:2;margin-bottom:0;"><label>Add custom test</label>
        <input id="inv-custom" type="text" placeholder="Type a test not in the list" onkeydown="if(event.key==='Enter'){event.preventDefault();addCustomInv();}">
      </div>
      <button type="button" class="btn btn-sm" onclick="addCustomInv()">+ Add</button>
    </div>`;
}


function previousVisitSummaryHTML(patient, editingVisitId){
  if(!patient || !isDoctor()) return '';
  const visits = (patient.visits||[]).slice().sort((a,b)=>(b.date+b.id).localeCompare(a.date+a.id));
  // Prefer last completed visit that is not the one currently being edited
  const prev = visits.find(v => v.id !== editingVisitId && visitStatus(v)==='completed')
            || visits.find(v => v.id !== editingVisitId);
  if(!prev) return `<div class="card" style="margin-bottom:14px;"><p class="muted" style="margin:0;">No previous visits on record for this patient.</p></div>`;
  const rx = (prev.prescriptions||[]).filter(r=>r.medicine).slice(0,4);
  const rxLine = rx.length
    ? rx.map(r=>esc(r.medicine)+(r.dosage?' '+esc(r.dosage):'')+(r.frequency?' · '+esc(r.frequency):'')).join('; ')
    : '—';
  return `
    <div class="card" style="margin-bottom:14px;border-left:4px solid var(--primary);">
      <div class="rx-row-head" style="margin-bottom:8px;">
        <h3 style="margin:0;">Previous visit — ${fmtDate(prev.date)}${prev.time?' · '+esc(prev.time):''}</h3>
        <button class="btn btn-ghost btn-sm" onclick="go('visitPrint',{patientId:'${patient.id}',visitId:'${prev.id}'})">Open full</button>
      </div>
      <div class="row" style="gap:18px;flex-wrap:wrap;font-size:13px;">
        <div><span class="faint">Diagnosis</span><div><strong>${esc(prev.diagnosis)||'—'}</strong></div></div>
        <div><span class="faint">Complaints</span><div>${esc(prev.complaints)||'—'}</div></div>
        <div><span class="faint">Vitals</span><div>BP ${esc(prev.vitals&&prev.vitals.bp)||'—'} · Wt ${esc(prev.vitals&&prev.vitals.weight)||'—'}${prev.vitals&&prev.vitals.height?' · Ht '+esc(prev.vitals.height):''}</div></div>
        <div><span class="faint">Doctor</span><div>${esc(prev.doctorName)||'—'}</div></div>
      </div>
      <div style="margin-top:8px;"><span class="faint">Last Rx</span><div>${rxLine}</div></div>
      ${prev.followUpDate?`<div class="faint" style="margin-top:6px;">Follow-up was set for ${fmtDate(prev.followUpDate)}</div>`:''}
      <div class="row" style="margin-top:10px;gap:8px;">
        <button class="btn btn-sm" onclick="copyLastPrescription('${patient.id}','${prev.id}')">Copy last prescription</button>
      </div>
    </div>`;
}
function copyLastPrescription(patientId, visitId){
  const p = state.data.patients.find(x=>x.id===patientId);
  const v = p && (p.visits||[]).find(x=>x.id===visitId);
  if(!v || !state.draftVisit) return;
  const rx = (v.prescriptions||[]).filter(r=>r.medicine).map(r=>({...r}));
  if(!rx.length){ alert('No medicines on the previous prescription.'); return; }
  state.draftVisit.prescriptions = rx;
  // Keep form fields in sync if already painted
  render();
}

function newVisitView(){
  const dv = state.draftVisit;
  let patientBlock;
  if(dv.patientId){
    const p = state.data.patients.find(p=>p.id===dv.patientId);
    patientBlock = `<div class="banner banner-info">Patient: <strong>${esc(p.name)}</strong> (${p.id}) — ${esc(displayAge(p))}/${esc(p.sex)}
      ${!state.routeParams.patientId ? `<button class="btn btn-ghost btn-sm" style="margin-left:8px;" onclick="state.draftVisit.patientId=null;render()">Change</button>`:''}</div>`;
  } else if(dv.newPatient){
    const np = dv.newPatient;
    patientBlock = `
      <div class="card" style="margin-bottom:16px;">
        <div class="rx-row-head"><h3>Register new patient</h3><button class="btn btn-ghost btn-sm" onclick="toggleNewPatientInVisit()">Cancel</button></div>
        <div class="row"><div class="field"><label>Full name *</label><input id="np-name" value="${esc(np.name)}"></div></div>
        <div class="row">
          <div class="field"><label>Date of birth</label><input id="np-dob" type="date" max="${todayStr()}" value="${esc(np.dob||'')}" oninput="updateAgePreview(this,'np-age-preview')">
            <div id="np-age-preview" class="faint" style="margin-top:4px;">${np.dob && ageFromDob(np.dob) ? 'Age: '+esc(ageFromDob(np.dob).full) : ''}</div></div>
          <div class="field"><label>Age (if DOB unknown)</label><input id="np-age" value="${esc(np.age)}"></div>
          <div class="field"><label>Sex *</label><select id="np-sex">
            <option value="">Select</option>
            ${['Male','Female','Other'].map(s=>`<option ${np.sex===s?'selected':''}>${s}</option>`).join('')}
          </select></div>
        </div>
        <div class="row">
          <div class="field"><label>Address *</label><input id="np-address" value="${esc(np.address||'')}"></div>
          <div class="field"><label>Phone *</label><input id="np-phone" value="${esc(np.phone)}"></div>
        </div>
        <div class="field"><label>Known allergies</label><input id="np-allergies" value="${esc(np.allergies||'')}" placeholder="leave blank if none known"></div>
        <div class="field"><label>Chronic illness</label><input id="np-chronic" value="${esc(np.chronicIllness||'')}" placeholder="e.g. Asthma, diabetes"></div>
      </div>`;
  } else {
    patientBlock = `
      <div class="card" style="margin-bottom:16px;">
        <div class="field"><label>Find patient</label><input type="text" placeholder="Search by name, ID or phone" oninput="onVisitPatientSearch(this.value)"></div>
        <div id="visit-patient-results">${visitPatientResultsHTML()}</div>
        <button class="btn btn-ghost btn-sm" style="margin-top:8px;" onclick="toggleNewPatientInVisit()">+ Register a new patient instead</button>
      </div>`;
  }

  const cancelBtn = `<button class="btn btn-ghost" onclick="cancelVisitFlow()">Cancel</button>`;

  // Receptionist: patient check-in only — no vitals, history, diagnosis,
  // prescription or investigations. The doctor fills all of that in.
  if(!isDoctor()){
    const doctors = state.data.staff.filter(s=>s.role==='Doctor');
    return `
      <div class="page-head"><h1>Check In Patient</h1></div>
      <p class="muted" style="margin-bottom:14px;">Find or register the patient. The doctor will take vitals and handle the consultation.</p>
      ${patientBlock}
      <div class="card">
        ${doctors.length ? `<div class="field"><label>Preferred doctor (optional)</label>
          <select id="v-assigned-doctor"><option value="">No preference — any doctor</option>
            ${doctors.map(d=>`<option>${esc(d.name)}</option>`).join('')}
          </select></div>` : ''}
        <div id="visit-error" class="error-text"></div>
        <div class="row">
          <button class="btn btn-primary" onclick="saveVisit()">Check in</button>
          ${cancelBtn}
        </div>
      </div>`;
  }

  const allergyPatient = dv.patientId ? state.data.patients.find(p=>p.id===dv.patientId) : null;
  const allergyBanner = patientSafetyBannerHTML(allergyPatient);
  const pedNote = (allergyPatient && isPediatricPatient(allergyPatient))
    ? `<div class="banner banner-info"><strong>Pediatric patient</strong> — ${esc(opdAgeDisplay(allergyPatient))}. Dose suggestions appear under each medicine when weight is on file. <button class="btn btn-ghost btn-sm" onclick="state.pedLinkedPatientId='${allergyPatient.id}';go('pediatrics')">Pediatrics tools</button></div>` : '';

  const prevSummary = previousVisitSummaryHTML(allergyPatient, dv.editingVisitId);

  return `
    <div class="page-head"><h1>${dv.editingVisitId ? 'Continue Consultation' : 'New OPD Visit'}${allergyPatient && isPediatricPatient(allergyPatient)?' — Pediatric':''}</h1></div>
    ${dv.editingVisitId ? `<div class="banner banner-info">Continuing a visit checked in earlier — patient details are already filled in.</div>` : ''}
    ${allergyBanner}
    ${pedNote}
    ${patientBlock}
    ${prevSummary}
    <div class="card stack">
      <div class="field"><label>Attending doctor</label><input id="v-doctor" value="${esc(dv.doctorName)}"></div>
      <div>
        <h3>Vitals</h3>
        <div class="row">
          <div class="field"><label>BP</label><input id="v-bp" placeholder="120/80" value="${esc(dv.vitals.bp)}"></div>
          <div class="field"><label>Pulse</label><input id="v-pulse" placeholder="bpm" value="${esc(dv.vitals.pulse)}"></div>
          <div class="field"><label>Temp</label><input id="v-temp" placeholder="°F" value="${esc(dv.vitals.temp)}"></div>
          <div class="field"><label>Weight</label><input id="v-weight" placeholder="kg" value="${esc(dv.vitals.weight)}" oninput="updateBmiPreview();refreshAllRxDoseHints()"></div>
          <div class="field"><label>Height</label><input id="v-height" placeholder="cm" value="${esc(dv.vitals.height||'')}" oninput="updateBmiPreview()"></div>
        </div>
        <div id="v-bmi-preview" class="faint" style="margin-top:4px;">${(()=>{ const ap=dv.patientId&&state.data.patients.find(x=>x.id===dv.patientId); const r=calcBMI(dv.vitals.weight,dv.vitals.height,patientAgeYearsForBmi(ap)); return r?`BMI: ${r.value} (${r.label}) · ${r.standard}`:''; })()}</div>
      </div>
      <div class="field"><label>Chief complaints</label>
        <textarea id="v-complaints" oninput="onComplaintsInput(this)" placeholder="e.g. Fever × 3 days, Cough × 2 days — shown as C/O on the OPD card">${esc(dv.complaints)}</textarea>
        <div class="chip-row" id="complaints-chips">${chipRowHTML(chipsFor(dv.complaints, COMPLAINT_TERMS), 'insertComplaintChip')}</div>
      </div>
      <div class="field"><label>Examination findings</label><textarea id="v-exam">${esc(dv.examination)}</textarea></div>
      <div class="field"><label>Diagnosis</label>
        <input id="v-diagnosis" value="${esc(dv.diagnosis)}" oninput="onDiagnosisInput(this)" placeholder="leave blank if not yet confirmed">
        <div class="chip-row" id="diagnosis-chips">${chipRowHTML(chipsFor(dv.diagnosis, DIAGNOSIS_TERMS), 'insertDiagnosisChip')}</div>
      </div>
      <div class="field"><label>Doctor's notes</label><textarea id="v-notes">${esc(dv.notes)}</textarea></div>
      <div class="field"><label>Follow-up date (optional)</label><input id="v-followup" type="date" value="${esc(dv.followUpDate||'')}"></div>
      <div class="row">
        <div class="field"><label>Referred to (optional)</label><input id="v-referred-to" placeholder="e.g. City Hospital — Cardiology" value="${esc(dv.referredTo||'')}"></div>
        <div class="field"><label>Reason for referral</label><input id="v-referral-reason" placeholder="beyond OPD scope, needs specialist, etc." value="${esc(dv.referralReason||'')}"></div>
      </div>

      <div>
        <div class="rx-row-head">
          <h3>Prescription</h3>
          <div class="row" style="gap:6px;flex-wrap:wrap;">
            ${(state.data.rxTemplates||[]).length ? `
            <select id="rx-template-select" style="max-width:170px;">
              <option value="">Use template…</option>
              ${state.data.rxTemplates.map((t,i)=>`<option value="${i}">${esc(t.name)}</option>`).join('')}
            </select>
            <button class="btn btn-sm" onclick="applyRxTemplate()">Apply</button>` : ''}
            <button class="btn btn-sm" onclick="saveCurrentAsTemplate()">💾 Save as template</button>
            <button class="btn btn-sm" onclick="addRxRow()">+ Add medicine</button>
          </div>
        </div>
        <div id="rx-rows">${rxRowsHTML()}</div>
        <div id="rx-safety-summary">${rxSafetySummaryHTML()}</div>
      </div>

      <div>
        <div class="rx-row-head"><h3>Investigations</h3><span class="faint">Checklist — tick all that apply</span></div>
        <div id="inv-rows">${invRowsHTML()}</div>
      </div>

      <div id="visit-error" class="error-text"></div>
      <div class="row">
        <button class="btn btn-primary" onclick="saveVisit()">Save visit</button>
        ${cancelBtn}
      </div>
      <p id="draft-save-indicator" class="faint" style="margin-top:8px;"></p>
    </div>`;
}

// ---- Medical-term chip suggestions (Chief complaints / Diagnosis) ----
// Comma-separated free text stays fully typeable; tapping a chip completes
// whatever's being typed after the last comma, so it works alongside typing
// rather than replacing it.
function chipsFor(text, dict){
  const parts = (text||'').split(',');
  const current = parts[parts.length-1].trim().toLowerCase();
  const pool = current ? dict.filter(t=>t.toLowerCase().includes(current)) : dict;
  return pool.slice(0,8);
}
function chipRowHTML(items, insertFnName){
  return items.map(t=>`<button type="button" class="chip" onmousedown="${insertFnName}(this)" data-val="${esc(t)}">${esc(t)}</button>`).join('');
}
function onComplaintsInput(el){
  state.draftVisit.complaints = el.value;
  document.getElementById('complaints-chips').innerHTML = chipRowHTML(chipsFor(el.value, COMPLAINT_TERMS), 'insertComplaintChip');
}
function insertComplaintChip(el){
  const val = el.getAttribute('data-val');
  const ta = document.getElementById('v-complaints');
  const text = ta.value;
  const lastComma = text.lastIndexOf(',');
  const base = lastComma===-1 ? '' : text.slice(0,lastComma+1)+' ';
  // Chips insert the complaint term; OPD card adds "C/O " when printing.
  ta.value = base + val + ', ';
  state.draftVisit.complaints = ta.value;
  ta.focus();
  document.getElementById('complaints-chips').innerHTML = chipRowHTML(chipsFor(ta.value, COMPLAINT_TERMS), 'insertComplaintChip');
}
function onDiagnosisInput(el){
  state.draftVisit.diagnosis = el.value;
  document.getElementById('diagnosis-chips').innerHTML = chipRowHTML(chipsFor(el.value, DIAGNOSIS_TERMS), 'insertDiagnosisChip');
}
function insertDiagnosisChip(el){
  const val = el.getAttribute('data-val');
  const inp = document.getElementById('v-diagnosis');
  const text = inp.value;
  const lastComma = text.lastIndexOf(',');
  const base = lastComma===-1 ? '' : text.slice(0,lastComma+1)+' ';
  inp.value = base + val;
  state.draftVisit.diagnosis = inp.value;
  inp.focus();
  document.getElementById('diagnosis-chips').innerHTML = chipRowHTML(chipsFor(inp.value, DIAGNOSIS_TERMS), 'insertDiagnosisChip');
}


function parseRefBounds(ref){
  if(!ref) return null;
  const s = String(ref).replace(/,/g,'').replace(/–/g,'-').replace(/—/g,'-');
  let m = s.match(/(\d+\.?\d*)\s*-\s*(\d+\.?\d*)/);
  if(m) return {min:parseFloat(m[1]), max:parseFloat(m[2]), mode:'range'};
  m = s.match(/<\s*=?\s*(\d+\.?\d*)/);
  if(m) return {max:parseFloat(m[1]), mode:'lt'};
  m = s.match(/>\s*=?\s*(\d+\.?\d*)/);
  if(m) return {min:parseFloat(m[1]), mode:'gt'};
  return null;
}
function flagLabValue(value, ref){
  const n = parseFloat(String(value).replace(/,/g,''));
  if(isNaN(n)) return false;
  const b = parseRefBounds(ref);
  if(!b) return false;
  if(b.mode==='range') return n < b.min || n > b.max;
  if(b.mode==='lt') return n >= b.max;
  if(b.mode==='gt') return n <= b.min;
  return false;
}
function investigationHasResult(r){
  if(!r) return false;
  if((r.result||'').trim()) return true;
  const comps = r.components||{};
  return Object.values(comps).some(v => v!=null && String(v).trim()!=='');
}
function visitHasLabResults(v){
  return (v.investigations||[]).some(investigationHasResult);
}
function labReportBlockHTML(p, r){
  const ageY = patientAgeYearsForBmi(p);
  const sex = p.sex||'';
  const comps = r.components||{};
  const pending = !investigationHasResult(r);
  if(pending){
    return `<div class="inv-group"><div class="inv-group-title">${esc(r.test)}</div><p class="faint">Result pending</p></div>`;
  }
  const panel = getLabPanel(r.test);
  const qual = getLabQualitative(r.test);
  if(panel){
    const rows = panel.map(param=>{
      const val = comps[param.key];
      if(val==null || String(val).trim()==='') return '';
      const ref = typeof param.ref==='function' ? param.ref(ageY, sex) : (param.ref||'—');
      const flag = flagLabValue(val, ref);
      return `<tr>
        <td>${esc(param.label)}</td>
        <td class="${flag?'lab-flag':''}">${esc(val)}${flag?' *':''}</td>
        <td>${esc(param.unit||'')}</td>
        <td>${esc(ref)}</td>
      </tr>`;
    }).join('');
    return `<div class="inv-group">
      <div class="inv-group-title">${esc(r.test)}${r.notes?` — ${esc(r.notes)}`:''}</div>
      <table class="lab-report-table"><thead><tr><th>Parameter</th><th>Result</th><th>Unit</th><th>Reference</th></tr></thead>
      <tbody>${rows}</tbody></table>
      ${r.result?`<div class="sheet-section" style="padding-left:0;padding-right:0;"><span class="lbl">Notes</span><div>${esc(r.result)}</div></div>`:''}
    </div>`;
  }
  if(qual){
    const rows = qual.map(q=>{
      const val = comps[q.key];
      if(!val) return '';
      return `<tr><td>${esc(q.label)}</td><td><strong>${esc(val)}</strong></td></tr>`;
    }).join('');
    return `<div class="inv-group">
      <div class="inv-group-title">${esc(r.test)}</div>
      <table class="lab-report-table"><thead><tr><th>Test</th><th>Result</th></tr></thead><tbody>${rows}</tbody></table>
      ${r.result?`<div class="sheet-section" style="padding-left:0;padding-right:0;"><span class="lbl">Notes</span><div>${esc(r.result)}</div></div>`:''}
    </div>`;
  }
  return `<div class="sheet-section"><span class="lbl">${esc(r.test)}</span><div>${esc(r.result||'—')}</div></div>`;
}
function labReportSheetHTML(p, v){
  const ci = state.data.clinicInfo;
  const blocks = (v.investigations||[]).map(r=>labReportBlockHTML(p, r)).join('');
  return `
    <div class="print-sheet" id="sheet-lab">
      ${letterheadHTML(ci)}
      <div class="opd-badge">LABORATORY REPORT</div>
      <div class="patient-strip">
        <span><strong>${esc(p.name)}</strong> <span class="pill">${p.id}</span> — ${esc(opdAgeDisplay(p))}, ${esc(p.sex)}</span>
        <span>${fmtDate(v.date)}${v.time?' · '+esc(v.time):''}</span>
      </div>
      ${patientSafetyStripHTML(p)}
      ${v.diagnosis?`<div class="sheet-section"><span class="lbl">Clinical diagnosis</span><div>${esc(v.diagnosis)}</div></div>`:''}
      <div style="padding:0 22px;">${blocks}</div>
      <p class="faint" style="padding:4px 22px 0;font-size:11px;">* Value outside the listed reference interval. Confirm against the performing laboratory’s own ranges. This report is for use with the treating physician.</p>
      <div class="opd-sign">
        <div class="opd-sign-space"></div>
        <div class="opd-sign-label">Lab / Doctor signature</div>
      </div>
    </div>`;
}
function rxLinesHTML(prescriptions){
  return (prescriptions||[]).map((r,i)=>{
    const days = daysLabel(r.duration);
    const qty = computeQuantityLabel(r.medicine, r.frequency, r.duration);
    return `
      <div class="rx-line"><span class="n">${i+1}.</span>
        <span><strong>${esc(r.medicine)}</strong>${r.dosage?' '+esc(r.dosage):''}
        ${r.frequency?' — '+esc(r.frequency):''}${days?' × '+esc(days):''}${r.instructions?' ('+esc(r.instructions)+')':''}
        ${qty?`<br><span class="faint">${esc(qty)}</span>`:''}</span></div>`;
  }).join('');
}
function doctorLetterExtra(v){
  if(!v || !v.doctorName) return '';
  return `<div class="opd-doctor-top">${esc(v.doctorName)}${staffQualification(v.doctorName)?`<div class="opd-doctor-qual">${esc(staffQualification(v.doctorName))}</div>`:''}</div>`;
}
function rxSheetHTML(p, v){
  const ci = state.data.clinicInfo;
  return `
    <div class="print-sheet" id="sheet-rx">
      ${letterheadHTML(ci, doctorLetterExtra(v))}
      <div class="rx-sheet-mark">℞</div>
      <div class="sheet-title">PRESCRIPTION</div>
      <div class="patient-strip">
        <span><strong>${esc(p.name)}</strong> <span class="pill">${p.id}</span> — ${esc(opdAgeDisplay(p))}, ${esc(p.sex)}</span>
        <span>${fmtDate(v.date)}${v.time?' · '+esc(v.time):''}</span>
      </div>
      ${patientSafetyStripHTML(p)}
      ${v.diagnosis?`<div class="sheet-section"><span class="lbl">Diagnosis</span><div>${esc(v.diagnosis)}</div></div>`:''}
      <div>${rxLinesHTML(v.prescriptions)}</div>
      ${v.followUpDate ? `<div class="opd-followup"><span class="opd-k">Follow-up date</span><span class="opd-v"><strong>${fmtDate(v.followUpDate)}</strong></span></div>` : ''}
      <div class="opd-sign">
        <div class="opd-sign-space"></div>
        <div class="opd-sign-name">${esc(v.doctorName||'')}</div>
        ${staffQualification(v.doctorName)?`<div class="opd-doctor-qual" style="text-align:center;width:160px;">${esc(staffQualification(v.doctorName))}</div>`:''}
        <div class="opd-sign-label">Signature & stamp</div>
      </div>
    </div>`;
}

function visitPrintView(patientId, visitId){
  const p = state.data.patients.find(p=>p.id===patientId);
  if(!p) return `<p class="error-text">Patient not found.</p>`;
  const v = (p.visits||[]).find(v=>v.id===visitId);
  if(!v) return `<p class="error-text">Visit not found.</p>`;
  if(!isDoctor()){
    return `<div class="page-head"><h1>Visit summary</h1></div><p class="muted">Clinical details are available to staff logged in with the Doctor role.</p>
      <button class="btn btn-ghost" onclick="go('patient',{patientId:p.id})">Back to patient</button>`;
  }
  const ci = state.data.clinicInfo;

  const rxBlock = v.prescriptions.length ? `
      <div class="sheet-divider"></div>
      <div class="sheet-title">PRESCRIPTION</div>
      <div>
        ${v.prescriptions.map((r,i)=>{
          const days = daysLabel(r.duration);
          const qty = computeQuantityLabel(r.medicine, r.frequency, r.duration);
          return `
          <div class="rx-line"><span class="n">${i+1}.</span>
            <span><strong>${esc(r.medicine)}</strong>${r.dosage?' '+esc(r.dosage):''}
            ${r.frequency?' — '+esc(r.frequency):''}${days?' × '+esc(days):''}${r.instructions?' ('+esc(r.instructions)+')':''}
            ${qty?`<br><span class="faint">${esc(qty)}</span>`:''}</span></div>`;
        }).join('')}
      </div>` : '';

  // OPD card + prescription are one combined, printable sheet: patient
  // details and consultation notes on top (filled in by the receptionist
  // / doctor), prescription at the bottom.
  const formattedComplaints = formatComplaintsForOpd(v.complaints);
  const complaintsHtml = formattedComplaints === '—'
    ? '—'
    : formattedComplaints.split('\n').map(line=>`<div class="opd-complaint">${esc(line)}</div>`).join('');

  const opdSheet = `
    <div class="print-sheet opd-card" id="sheet-opd">
      ${letterheadHTML(ci, doctorLetterExtra(v))}
      <div class="opd-badge">${isPediatricPatient(p)?'PEDIATRIC OPD CARD':'OPD CARD'}</div>

      <div class="opd-demo">
        <div class="opd-demo-row"><span class="opd-k">Unique ID</span><span class="opd-v"><strong>${esc(p.id)}</strong></span></div>
        <div class="opd-demo-row"><span class="opd-k">Name</span><span class="opd-v"><strong>${esc(p.name)}</strong></span></div>
        <div class="opd-demo-row"><span class="opd-k">Age</span><span class="opd-v">${esc(opdAgeDisplay(p))}</span></div>
        <div class="opd-demo-row"><span class="opd-k">Address</span><span class="opd-v">${esc(p.address)||'—'}</span></div>
        <div class="opd-demo-row"><span class="opd-k">Phone</span><span class="opd-v">${esc(p.phone)||'—'}</span></div>
        <div class="opd-demo-row"><span class="opd-k">Date &amp; time</span><span class="opd-v">${fmtDate(v.date)}${v.time?' · '+esc(v.time):''}</span></div>
        ${v.token!=null?`<div class="opd-demo-row"><span class="opd-k">Token</span><span class="opd-v"><strong style="font-size:18px;">#${v.token}</strong></span></div>`:''}
        <div class="opd-demo-row"><span class="opd-k">Sex</span><span class="opd-v">${esc(p.sex)||'—'}</span></div>
        ${p.allergies?`<div class="opd-demo-row"><span class="opd-k">Allergies</span><span class="opd-v" style="color:var(--danger);font-weight:700;">${esc(p.allergies)}</span></div>`:''}
        ${p.chronicIllness?`<div class="opd-demo-row"><span class="opd-k">Chronic illness</span><span class="opd-v">${esc(p.chronicIllness)}</span></div>`:''}
      </div>

      <div class="opd-vitals" style="grid-template-columns:repeat(auto-fit,minmax(70px,1fr));">
        <div class="opd-vital"><span class="opd-vital-lbl">BP</span><span class="opd-vital-val">${esc(v.vitals.bp)||'—'}</span></div>
        <div class="opd-vital"><span class="opd-vital-lbl">Pulse</span><span class="opd-vital-val">${esc(v.vitals.pulse)||'—'}</span></div>
        <div class="opd-vital"><span class="opd-vital-lbl">Temp</span><span class="opd-vital-val">${esc(v.vitals.temp)||'—'}</span></div>
        <div class="opd-vital"><span class="opd-vital-lbl">Weight</span><span class="opd-vital-val">${esc(v.vitals.weight)||'—'}${v.vitals.weight?' kg':''}</span></div>
        <div class="opd-vital"><span class="opd-vital-lbl">Height</span><span class="opd-vital-val">${esc(v.vitals.height)||'—'}${v.vitals.height?' cm':''}</span></div>
        <div class="opd-vital"><span class="opd-vital-lbl">BMI</span><span class="opd-vital-val">${(()=>{ const r=calcBMI(v.vitals.weight,v.vitals.height,patientAgeYearsForBmi(p)); return r?r.value+' ('+r.label+')':'—'; })()}</span></div>
      </div>

      <div class="opd-block">
        <div class="opd-block-title">Chief complaints</div>
        <div class="opd-block-body opd-complaints">${complaintsHtml}</div>
      </div>
      <div class="opd-block">
        <div class="opd-block-title">Examination</div>
        <div class="opd-block-body">${esc(v.examination)||'—'}</div>
      </div>
      <div class="opd-block">
        <div class="opd-block-title">Diagnosis</div>
        <div class="opd-block-body opd-dx">${esc(v.diagnosis)||'—'}</div>
      </div>
      ${v.notes ? `<div class="opd-block"><div class="opd-block-title">Notes</div><div class="opd-block-body">${esc(v.notes)}</div></div>` : ''}
      ${v.referredTo ? `<div class="opd-block"><div class="opd-block-title">Referred to</div><div class="opd-block-body">${esc(v.referredTo)}${v.referralReason?' — '+esc(v.referralReason):''}</div></div>` : ''}
      ${rxBlock}
      ${v.followUpDate ? `<div class="opd-followup"><span class="opd-k">Follow-up date</span><span class="opd-v"><strong>${fmtDate(v.followUpDate)}</strong></span></div>` : ''}
      <div class="opd-sign">
        <div class="opd-sign-space"></div>
        <div class="opd-sign-label">Signature</div>
      </div>
    </div>`;

  const invSheet = v.investigations.length ? `
    <div class="print-sheet" id="sheet-inv">
      ${letterheadHTML(ci)}
      <div class="sheet-title">INVESTIGATION REQUEST</div>
      <div class="patient-strip">
        <span><strong>${esc(p.name)}</strong> <span class="pill">${p.id}</span> — ${esc(displayAge(p))}, ${esc(p.sex)}</span>
        <span>${fmtDate(v.date)}</span>
      </div>
      ${v.diagnosis?`<div class="sheet-section"><span class="lbl">Clinical diagnosis</span><div>${esc(v.diagnosis)}</div></div>`:''}
      <div style="margin-top:10px;">
        ${v.investigations.map((r,i)=>`
          <div class="rx-line"><span class="n">${i+1}.</span>
            <span><strong>${esc(r.test)}</strong>${r.notes?` — ${esc(r.notes)}`:''}</span></div>`).join('')}
      </div>
      <div class="sheet-section" style="margin-top:24px;"><span class="lbl">Requested by</span><div>${esc(v.doctorName)||'—'}</div></div>
    </div>` : '';

  const resultsCard = v.investigations.length ? `
    <div class="card" style="margin-bottom:16px;max-width:720px;">
      <h2 style="margin-bottom:4px;">Investigation results</h2>
      <p class="faint" style="margin-bottom:12px;">Structured panels show standard parameters with units and approximate Indian reference ranges by age/sex. Confirm against your lab’s ranges.</p>
      ${invResultEntryHTML(p, v.investigations)}
      <button class="btn btn-primary btn-sm" onclick="saveInvestigationResults('${p.id}','${v.id}')">Save results</button>
      <span id="results-saved-msg" class="faint" style="margin-left:8px;"></span>
    </div>` : '';

  return `
    <div class="page-head">
      <div><h1>Visit summary</h1><p class="muted">${esc(p.name)} (${p.id}) — ${fmtDate(v.date)}</p></div>
      <button class="btn btn-ghost" onclick="go('patient',{patientId:p.id})">Back to patient</button>
    </div>
    <div class="row" style="margin-bottom:18px;flex-wrap:wrap;gap:8px;">
      <button class="btn btn-primary" onclick="printSection('sheet-opd')">Print OPD card${v.prescriptions.length?' + prescription':''}</button>
      ${v.prescriptions.length?`<button class="btn" onclick="printSection('sheet-rx')">Print prescription only</button>`:''}
      ${v.investigations.length?`<button class="btn" onclick="printSection('sheet-inv')">Print investigation form</button>`:''}
      ${visitHasLabResults(v)?`<button class="btn btn-accent" onclick="printSection('sheet-lab')">Print lab report</button>`:''}
      <button class="btn" onclick="state.certPatientId='${p.id}';state.certType='sick';go('certificates')">Medical certificate</button>
      <button class="btn btn-ghost" onclick="go('newVisit',{patientId:'${p.id}',editVisitId:'${v.id}'})">Edit this visit</button>
    </div>
    ${resultsCard}
    ${opdSheet}
    ${v.prescriptions.length ? rxSheetHTML(p, v) : ''}
    ${invSheet}
    ${v.investigations.length ? labReportSheetHTML(p, v) : ''}
  `;
}
async function saveInvestigationResults(patientId, visitId){
  const p = state.data.patients.find(p=>p.id===patientId);
  const v = p && (p.visits||[]).find(v=>v.id===visitId);
  if(!v) return;
  // Free-text / notes field
  document.querySelectorAll('[data-result-idx]').forEach(el=>{
    const i = Number(el.getAttribute('data-result-idx'));
    if(v.investigations[i]) v.investigations[i].result = el.value.trim();
  });
  // Structured component values
  document.querySelectorAll('[data-lab-idx]').forEach(el=>{
    const i = Number(el.getAttribute('data-lab-idx'));
    const key = el.getAttribute('data-lab-key');
    if(!v.investigations[i]) return;
    if(!v.investigations[i].components) v.investigations[i].components = {};
    v.investigations[i].components[key] = el.value.trim();
  });
  // Build a readable summary string from components for print/export
  v.investigations.forEach(r=>{
    const panel = getLabPanel(r.test);
    const qual = getLabQualitative(r.test);
    const spec = panel || qual;
    if(spec && r.components){
      const summary = formatComponentsResult(r.components, spec);
      if(summary){
        const notes = (r.result||'').trim();
        // Don't duplicate if result already is the structured summary
        r.result = notes && notes !== summary && !notes.startsWith(summary)
          ? summary + (notes.includes(':') ? '' : ' | ' + notes)
          : (summary || notes);
      }
    }
  });
  logAudit('Saved investigation results', `${p.name} (${p.id}) — ${fmtDate(v.date)}`);
  const ok = await saveData();
  const msg = document.getElementById('results-saved-msg');
  if(msg) msg.textContent = ok ? 'Saved ✓' : 'Could not save — try again';
}

/* ============================= PEDIATRICS ============================= */
function setPedTab(tab){ state.pedTab = tab; state.search=''; render(); }

function pediatricsView(){
  if(!isDoctor()){
    return `<div class="page-head"><h1>Pediatrics</h1></div><p class="muted">This section is available to staff logged in with the Doctor role.</p>`;
  }
  const tab = state.pedTab || 'patients';
  const tabs = [
    ['patients','Pediatric patients'],
    ['growth','Growth chart'],
    ['dose','Dose calculator'],
    ['immunization','Vaccination'],
    ['reference','Vitals & milestones']
  ];
  const nav = tabs.map(([k,label])=>
    `<button class="btn btn-sm ${tab===k?'btn-primary':''}" onclick="setPedTab('${k}')">${label}</button>`
  ).join(' ');
  let content;
  if(tab==='dose') content = doseCalcHTML();
  else if(tab==='immunization') content = immunizationHTML();
  else if(tab==='reference') content = pedReferenceHTML();
  else if(tab==='patients') content = pediatricPatientsHTML();
  else content = growthCalcHTML();
  return `
    <div class="page-head">
      <div><h1>Pediatrics</h1><p class="muted">Patients under 16 years · growth, dosing &amp; immunization</p></div>
      <button class="btn btn-accent" onclick="go('newVisit')">+ New pediatric OPD</button>
    </div>
    <div class="row" style="margin-bottom:18px;flex-wrap:wrap;gap:8px;">${nav}</div>
    ${content}`;
}

function pediatricPatientsHTML(){
  const q = (state.search||'').trim().toLowerCase();
  let list = pediatricPatients();
  if(q){
    list = list.filter(p=>
      p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q) || (p.phone||'').includes(q)
    );
  }
  const rows = list.map(p=>{
    const lv = lastVisitDate(p);
    const due = vaccinationDueSummary(p);
    return `<tr class="clickable" onclick="go('patient',{patientId:'${p.id}'})">
      <td><span class="pill">${p.id}</span></td>
      <td>${esc(p.name)}</td>
      <td>${esc(opdAgeDisplay(p))} / ${esc(p.sex)}</td>
      <td>${esc(p.phone)||'<span class="faint">—</span>'}</td>
      <td>${lv?fmtDate(lv):'<span class="faint">No visits</span>'}</td>
      <td>${due.overdue ? `<span class="pill" style="background:var(--danger-tint);color:var(--danger);">${due.overdue} due</span>`
        : due.upcoming ? `<span class="pill" style="background:var(--accent-tint);color:var(--accent);">${due.upcoming} upcoming</span>`
        : '<span class="faint">Up to date</span>'}</td>
      <td><button class="btn btn-sm btn-accent" onclick="event.stopPropagation();go('newVisit',{patientId:'${p.id}'})">OPD</button></td>
    </tr>`;
  }).join('');
  return `
    <div class="card">
      <div class="search-wrap" style="margin-bottom:14px;">
        <input type="text" placeholder="Search pediatric patients by name, ID or phone" value="${esc(state.search||'')}" oninput="state.search=this.value;render()">
      </div>
      <p class="muted" style="margin-bottom:10px;">${list.length} patient${list.length===1?'':'s'} under 16 years</p>
      ${list.length
        ? `<table><thead><tr><th>ID</th><th>Name</th><th>Age / Sex</th><th>Phone</th><th>Last visit</th><th>Vaccines</th><th></th></tr></thead><tbody>${rows}</tbody></table>`
        : `<p class="muted">No patients under 16 registered yet. Register a child (with date of birth or age under 16) and they will appear here for pediatric OPD.</p>`}
    </div>`;
}

// Approximate age-in-months thresholds for IAP schedule rows (for due suggestions).
const IMMUNIZATION_AGE_MONTHS = [
  {ageLabel:'Birth', minM:0, maxM:0.5},
  {ageLabel:'6 weeks', minM:1.2, maxM:2.2},
  {ageLabel:'10 weeks', minM:2.2, maxM:3.2},
  {ageLabel:'14 weeks', minM:3.0, maxM:4.5},
  {ageLabel:'6 months', minM:5.5, maxM:7.5},
  {ageLabel:'9 months', minM:8.5, maxM:10.5},
  {ageLabel:'9-12 months', minM:9, maxM:13},
  {ageLabel:'12 months', minM:11.5, maxM:14},
  {ageLabel:'15 months', minM:14, maxM:17},
  {ageLabel:'16-18 months', minM:15.5, maxM:19},
  {ageLabel:'18-19 months', minM:17.5, maxM:21},
  {ageLabel:'2 years', minM:22, maxM:30},
  {ageLabel:'4-6 years', minM:48, maxM:78},
  {ageLabel:'9-14 years', minM:108, maxM:180},
  {ageLabel:'10-12 years', minM:120, maxM:156}
];
function patientAgeMonths(p){
  if(p && p.dob){
    const a = ageFromDob(p.dob);
    if(a) return a.totalMonths + (a.days||0)/30;
  }
  const m = String(p && p.age || '').match(/(\d+)/);
  if(m) return parseInt(m[1],10)*12;
  return null;
}
// Normalize vaccine names for exact matching only (so "Rotavirus-1" ≠ "Rotavirus-2").
function normalizeVaccineName(s){
  return String(s||'').toLowerCase().replace(/\s+/g,' ').trim();
}
function vaccinationStatusForPatient(p){
  const ageM = patientAgeMonths(p);
  // Exact normalized names only — never match dose 1 to dose 2 via shared root.
  const given = new Set((p.vaccinations||[]).map(v=>normalizeVaccineName(v.vaccine)));
  const items = [];
  IMMUNIZATION_SCHEDULE.forEach((row, idx)=>{
    const band = IMMUNIZATION_AGE_MONTHS[idx] || {minM:0, maxM:999};
    const vaccines = row.vaccines.split(',').map(s=>s.trim()).filter(Boolean);
    vaccines.forEach(vac=>{
      const key = normalizeVaccineName(vac);
      const isGiven = given.has(key);
      let status = 'future';
      if(isGiven) status = 'given';
      else if(ageM != null){
        if(ageM >= band.minM) status = ageM > band.maxM + 2 ? 'overdue' : 'due';
        else if(ageM >= band.minM - 1) status = 'upcoming';
      }
      items.push({age: row.age, vaccine: vac, status, band});
    });
  });
  return items;
}
function vaccinationDueSummary(p){
  const items = vaccinationStatusForPatient(p);
  return {
    overdue: items.filter(i=>i.status==='overdue'||i.status==='due').length,
    upcoming: items.filter(i=>i.status==='upcoming').length,
    given: items.filter(i=>i.status==='given').length
  };
}

function growthCalcHTML(){
  const linked = state.pedLinkedPatientId ? state.data.patients.find(p=>p.id===state.pedLinkedPatientId) : null;
  const linkedAge = (linked && linked.dob) ? ageFromDob(linked.dob) : null;
  const sex = linked && linked.sex === 'Female' ? 'Female' : 'Male';
  // Historical charts from saved growth records (shown when patient linked)
  let historyCharts = '';
  if(linked && (linked.growthRecords||[]).length){
    const recs = linked.growthRecords.slice().sort((a,b)=>(a.ageMonths||0)-(b.ageMonths||0));
    const last = recs[recs.length-1];
    const sexR = last.sex || sex;
    historyCharts = `
      <div class="card" style="margin-bottom:18px;">
        <h2 style="margin-bottom:4px;">Growth charts — ${esc(linked.name)}</h2>
        <p class="faint" style="margin-bottom:12px;">WHO standards with all saved readings plotted. Dot = most recent reading.</p>
        ${last.weight!=null ? growthChartCardHTML('weight', sexR, last.ageMonths, last.weight) : ''}
        ${last.height!=null ? growthChartCardHTML('height', sexR, last.ageMonths, last.height) : ''}
        ${last.hc!=null ? growthChartCardHTML('hc', sexR, last.ageMonths, last.hc) : ''}
        <table style="margin-top:10px;"><thead><tr><th>Date</th><th>Age</th><th>Weight</th><th>Height</th><th>HC</th></tr></thead>
        <tbody>${recs.slice().reverse().map(r=>`
          <tr><td>${fmtDate(r.date)}</td><td>${(r.ageMonths/12).toFixed(1)}y</td>
            <td>${r.weight!=null?r.weight+' kg'+(r.weightPercentile!=null?' ('+r.weightPercentile+'th)':''):'—'}</td>
            <td>${r.height!=null?r.height+' cm'+(r.heightPercentile!=null?' ('+r.heightPercentile+'th)':''):'—'}</td>
            <td>${r.hc!=null?r.hc+' cm'+(r.hcPercentile!=null?' ('+r.hcPercentile+'th)':''):'—'}</td>
          </tr>`).join('')}</tbody></table>
      </div>`;
  } else if(linked){
    historyCharts = `<div class="card" style="margin-bottom:18px;"><p class="muted">No growth readings saved for ${esc(linked.name)} yet. Enter a measurement below and save it to build their chart.</p></div>`;
  }

  // Blank reference charts always visible on the growth tab
  const refCharts = !linked ? `
    <div class="card" style="margin-bottom:18px;">
      <h2 style="margin-bottom:4px;">Reference growth charts</h2>
      <p class="faint" style="margin-bottom:12px;">WHO Child Growth Standards (0–5 years). Link a patient and calculate a reading to plot their point.</p>
      <div class="row" style="margin-bottom:10px;">
        <button class="btn btn-sm ${state.pedChartSex!=='Female'?'btn-primary':''}" onclick="state.pedChartSex='Male';render()">Boys</button>
        <button class="btn btn-sm ${state.pedChartSex==='Female'?'btn-primary':''}" onclick="state.pedChartSex='Female';render()">Girls</button>
      </div>
      ${growthChartCardHTML('weight', state.pedChartSex==='Female'?'Female':'Male', null, null)}
      ${growthChartCardHTML('height', state.pedChartSex==='Female'?'Female':'Male', null, null)}
      ${growthChartCardHTML('hc', state.pedChartSex==='Female'?'Female':'Male', null, null)}
    </div>` : '';

  return `
    ${historyCharts}
    ${refCharts}
    <div class="card" style="max-width:560px;">
      <h2 style="margin-bottom:4px;">Growth percentile calculator</h2>
      <p class="faint" style="margin-bottom:12px;">WHO Child Growth Standards, birth to 5 years. A single reading is a snapshot — trend across visits matters more than one number.</p>
      <div class="field"><label>Link to a patient (optional — saves reading &amp; shows their chart)</label>
        ${linked ? `<div class="banner banner-info">${esc(linked.name)} (${linked.id}) — ${esc(opdAgeDisplay(linked))}
          <button class="btn btn-ghost btn-sm" onclick="state.pedLinkedPatientId=null;render()">Unlink</button>
          <button class="btn btn-sm btn-accent" style="margin-left:6px;" onclick="go('newVisit',{patientId:'${linked.id}'})">Start OPD</button></div>`
          : `<input type="text" placeholder="Search pediatric patients by name, ID or phone" oninput="onGrowthPatientSearch(this.value)">
             <div id="growth-patient-results">${growthPatientResultsHTML()}</div>`}
      </div>
      <div class="row">
        <div class="field"><label>Sex</label><select id="gc-sex"><option ${linked&&linked.sex==='Female'?'':'selected'}>Male</option><option ${linked&&linked.sex==='Female'?'selected':''}>Female</option></select></div>
        <div class="field"><label>Age — years</label><input id="gc-years" type="number" min="0" max="5" inputmode="numeric" placeholder="0" value="${linkedAge?linkedAge.years:''}"></div>
        <div class="field"><label>Age — months</label><input id="gc-months" type="number" min="0" max="11" inputmode="numeric" placeholder="0" value="${linkedAge?linkedAge.months:''}"></div>
      </div>
      ${linkedAge ? `<p class="faint" style="margin:-6px 0 10px;">Age pulled from ${esc(linked.name)}'s date of birth — adjust if this reading is for a different date.</p>` : ''}
      <div class="row">
        <div class="field"><label>Weight (kg)</label><input id="gc-weight" type="number" step="0.01" inputmode="decimal"></div>
        <div class="field"><label>Height/Length (cm)</label><input id="gc-height" type="number" step="0.1" inputmode="decimal"></div>
        <div class="field"><label>Head circumference (cm)</label><input id="gc-hc" type="number" step="0.1" inputmode="decimal"></div>
      </div>
      <button class="btn btn-primary" onclick="calcGrowth()">Calculate</button>
      <div id="growth-result" style="margin-top:14px;"></div>
    </div>`;
}
function growthPatientResultsHTML(){
  const q = (state.search||'').trim().toLowerCase();
  if(!q) return '';
  const list = pediatricPatients().filter(p=>
    p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q) || (p.phone||'').includes(q)
  ).slice(0,6);
  if(list.length===0) return `<p class="faint">No matching patients under 16.</p>`;
  return list.map(p=>`<div class="rx-row" style="cursor:pointer;" onclick="state.pedLinkedPatientId='${p.id}';state.search='';render()">
    <strong>${esc(p.name)}</strong> <span class="pill">${p.id}</span> <span class="faint">${esc(opdAgeDisplay(p))}/${esc(p.sex)}</span>
  </div>`).join('');
}
function onGrowthPatientSearch(v){
  state.search = v;
  document.getElementById('growth-patient-results').innerHTML = growthPatientResultsHTML();
}

function growthRowHTML(label, valueStr, r){
  const bg = r.cls==='band-low' ? 'var(--danger-tint)' : r.cls==='band-mid' ? 'var(--accent-tint)' : 'var(--primary-tint)';
  const fg = r.cls==='band-low' ? 'var(--danger)' : r.cls==='band-mid' ? 'var(--accent)' : 'var(--primary-dark)';
  return `<div class="card" style="padding:12px 14px;margin-bottom:8px;">
    <div style="display:flex;justify-content:space-between;align-items:baseline;">
      <strong>${esc(label)}</strong><span class="faint">${esc(valueStr)}</span>
    </div>
    <div style="font-size:24px;font-family:'Source Serif 4',serif;color:var(--primary-dark);margin-top:4px;">${r.percentile.toFixed(0)}<span style="font-size:14px;">th percentile</span></div>
    <span class="pill" style="background:${bg};color:${fg};margin-top:4px;">${esc(r.label)}</span>
  </div>`;
}

let lastGrowthReading = null;
function calcGrowth(){
  const sex = document.getElementById('gc-sex').value;
  const years = parseFloat(document.getElementById('gc-years').value) || 0;
  const months = parseFloat(document.getElementById('gc-months').value) || 0;
  const ageMonths = years*12 + months;
  const weight = parseFloat(document.getElementById('gc-weight').value);
  const height = parseFloat(document.getElementById('gc-height').value);
  const hc = parseFloat(document.getElementById('gc-hc').value);
  const box = document.getElementById('growth-result');

  if(ageMonths < 0 || ageMonths > 60){
    box.innerHTML = `<p class="error-text">This calculator covers 0-5 years (0-60 months) only.</p>`;
    return;
  }
  let rows = '';
  const reading = {date: todayStr(), ageMonths, sex, weight:weight||null, height:height||null, hc:hc||null, weightPercentile:null, heightPercentile:null, hcPercentile:null};
  if(weight){ const r = growthPercentile('weight', sex, ageMonths, weight); if(r){ rows += growthRowHTML('Weight', weight+' kg', r) + growthChartCardHTML('weight', sex, ageMonths, weight); reading.weightPercentile = Math.round(r.percentile); } }
  if(height){ const r = growthPercentile('height', sex, ageMonths, height); if(r){ rows += growthRowHTML('Height / Length', height+' cm', r) + growthChartCardHTML('height', sex, ageMonths, height); reading.heightPercentile = Math.round(r.percentile); } }
  if(hc){ const r = growthPercentile('hc', sex, ageMonths, hc); if(r){ rows += growthRowHTML('Head circumference', hc+' cm', r) + growthChartCardHTML('hc', sex, ageMonths, hc); reading.hcPercentile = Math.round(r.percentile); } }
  if(!rows){ box.innerHTML = `<p class="muted">Enter at least one measurement.</p>`; return; }
  lastGrowthReading = reading;
  const saveBtn = state.pedLinkedPatientId
    ? `<button class="btn btn-sm" style="margin-top:8px;" onclick="saveGrowthToPatient()">+ Save this reading to patient record</button><span id="growth-save-msg" class="faint" style="margin-left:8px;"></span>`
    : `<p class="faint" style="margin-top:8px;">Link a patient above to save this reading to their record.</p>`;
  box.innerHTML = rows + saveBtn;
}
async function saveGrowthToPatient(){
  const p = state.data.patients.find(p=>p.id===state.pedLinkedPatientId);
  if(!p || !lastGrowthReading) return;
  if(!p.growthRecords) p.growthRecords = [];
  p.growthRecords.push(lastGrowthReading);
  logAudit('Saved growth reading', `${p.name} (${p.id})`);
  const ok = await saveData();
  const msg = document.getElementById('growth-save-msg');
  if(msg) msg.textContent = ok ? 'Saved to record ✓' : 'Could not save — try again';
}

// Most recent known weight for a linked child — prefers a saved growth
// reading, falls back to the last visit's recorded vitals.
function mostRecentPediatricWeight(p){
  // Prefer weight typed in the current OPD form (live dose suggestions)
  if(p && state.draftVisit && state.draftVisit.patientId===p.id){
    const live = parseFloat(state.draftVisit.vitals && state.draftVisit.vitals.weight);
    if(live && live > 0) return {value: live, source: 'current visit', date: todayStr()};
    const wEl = document.getElementById('v-weight');
    if(wEl){
      const w = parseFloat(wEl.value);
      if(w && w > 0) return {value: w, source: 'current visit', date: todayStr()};
    }
  }
  const gr = (p.growthRecords||[]).filter(r=>r.weight).slice().sort((a,b)=>(b.date||'').localeCompare(a.date||''))[0];
  if(gr) return {value: gr.weight, source: 'a growth reading', date: gr.date};
  const vv = (p.visits||[]).filter(v=>v.vitals && v.vitals.weight).slice().sort((a,b)=>(b.date||'').localeCompare(a.date||''))[0];
  if(vv) return {value: parseFloat(vv.vitals.weight), source: 'visit vitals', date: vv.date};
  return null;
}

function doseCalcHTML(){
  const linked = state.pedLinkedPatientId ? state.data.patients.find(p=>p.id===state.pedLinkedPatientId) : null;
  const linkedAge = (linked && linked.dob) ? ageFromDob(linked.dob) : null;
  const knownWeight = linked ? mostRecentPediatricWeight(linked) : null;
  return `
    <div class="card" style="max-width:520px;">
      <h2 style="margin-bottom:4px;">Pediatric Dose Calculator</h2>
      <p class="faint" style="margin-bottom:12px;">Reference only — cross-check against current formulary/BNF-C before prescribing, especially near the maximum dose.</p>
      <div class="field"><label>Link to a patient (optional — loads their date of birth and last recorded weight)</label>
        ${linked ? `<div class="banner banner-info">${esc(linked.name)} (${linked.id})${linked.dob ? ` — DOB ${fmtDate(linked.dob)}${linkedAge?' ('+linkedAge.display+')':''}` : ''}
            <button class="btn btn-ghost btn-sm" onclick="state.pedLinkedPatientId=null;render()">Unlink</button></div>`
          : `<input type="text" placeholder="Search by name, ID or phone" oninput="onGrowthPatientSearch(this.value)">
             <div id="growth-patient-results">${growthPatientResultsHTML()}</div>`}
      </div>
      <div class="row">
        <div class="field"><label>Child's weight (kg)</label><input id="dc-weight" type="number" step="0.1" inputmode="decimal" value="${knownWeight?knownWeight.value:''}" oninput="calcDose()" onchange="calcDose()"></div>
        <div class="field" style="flex:2;"><label>Medicine</label>
          <select id="dc-drug" onchange="calcDose()">
            <option value="">Select…</option>
            ${PEDIATRIC_DOSE_DB.map((d,i)=>`<option value="${i}">${esc(d.name)}</option>`).join('')}
          </select>
        </div>
      </div>
      ${knownWeight ? `<p class="faint" style="margin:-6px 0 10px;">Weight pulled from ${knownWeight.source} on ${fmtDate(knownWeight.date)} — update it if the child's been weighed since.</p>`
        : linked ? `<p class="faint" style="margin:-6px 0 10px;">No recorded weight found for ${esc(linked.name)} yet — enter it manually.</p>` : ''}
      <p class="faint" style="margin-bottom:8px;">Dose updates automatically when you change weight or medicine.</p>
      <button class="btn btn-primary" onclick="calcDose()">Calculate dose</button>
      <div id="dose-result" style="margin-top:14px;"></div>
    </div>`;
}

function calcDose(){
  const weightEl = document.getElementById('dc-weight');
  const drugEl = document.getElementById('dc-drug');
  const box = document.getElementById('dose-result');
  if(!box) return;
  const weight = weightEl ? parseFloat(weightEl.value) : NaN;
  const idx = drugEl ? drugEl.value : '';
  if(!weight || weight <= 0 || idx===''){
    box.innerHTML = `<p class="muted">Enter the child's weight and choose a medicine — result updates as you type.</p>`;
    return;
  }
  const d = PEDIATRIC_DOSE_DB[Number(idx)];
  if(!d){ box.innerHTML = `<p class="error-text">Unknown medicine.</p>`; return; }
  let doseMg = weight * d.mgPerKg;
  let capped = false;
  if(d.maxMg && doseMg > d.maxMg){ doseMg = d.maxMg; capped = true; }

  let volumeBlock;
  if(d.conc && d.conc.length){
    const rows = d.conc.map(mgPer5ml=>{
      const ml = (doseMg / mgPer5ml) * 5;
      return `<div class="sheet-section"><span class="lbl">${mgPer5ml}mg/5ml syrup</span><div><strong>${ml.toFixed(1)} ml</strong> per dose</div></div>`;
    }).join('');
    volumeBlock = rows;
  } else {
    volumeBlock = `<div class="sheet-section"><span class="lbl">Volume</span><div class="faint">${d.form==='Injection' ? 'Reconstitute per vial insert — concentration varies by product.' : 'Marketed concentration varies by brand — check the label to convert mg to ml.'}</div></div>`;
  }

  box.innerHTML = `
    <div class="card" style="padding:14px;">
      <strong>${esc(d.name)}</strong>
      <div style="font-size:24px;font-family:'Source Serif 4',serif;color:var(--primary-dark);margin:6px 0;">${doseMg.toFixed(1)} mg <span style="font-size:13px;">per dose</span></div>
      <div class="faint">${d.mgPerKg}mg/kg × ${weight}kg${capped?' — capped at max '+d.maxMg+'mg/dose':''}</div>
      ${volumeBlock}
      <div class="sheet-section" style="margin-top:10px;"><span class="lbl">Frequency</span><div>${esc(d.freq)}</div></div>
      <div class="sheet-section"><span class="lbl">Common form</span><div>${esc(d.form)}</div></div>
    </div>`;
}

function immunizationHTML(){
  const linked = state.pedLinkedPatientId ? state.data.patients.find(p=>p.id===state.pedLinkedPatientId) : null;
  const scheduleRows = IMMUNIZATION_SCHEDULE.map(r=>`<tr><td style="white-space:nowrap;"><strong>${esc(r.age)}</strong></td><td>${esc(r.vaccines)}</td></tr>`).join('');

  let patientBlock = `
    <div class="field"><label>Link a pediatric patient to record &amp; suggest vaccines by age</label>
      <input type="text" placeholder="Search by name, ID or phone" oninput="onGrowthPatientSearch(this.value)">
      <div id="growth-patient-results">${growthPatientResultsHTML()}</div>
    </div>`;

  if(linked){
    const items = vaccinationStatusForPatient(linked);
    const statusPill = s => s==='given' ? '<span class="pill">Given</span>'
      : s==='overdue' ? '<span class="pill" style="background:var(--danger-tint);color:var(--danger);">Overdue</span>'
      : s==='due' ? '<span class="pill" style="background:var(--accent-tint);color:var(--accent);">Due now</span>'
      : s==='upcoming' ? '<span class="pill" style="background:var(--primary-tint);color:var(--primary);">Upcoming</span>'
      : '<span class="faint">Later</span>';
    const statusRows = items.map((it,i)=>`
      <tr>
        <td>${esc(it.age)}</td>
        <td>${esc(it.vaccine)}</td>
        <td>${statusPill(it.status)}</td>
        <td>${it.status!=='given'
          ? `<button class="btn btn-sm btn-accent" onclick="quickAddVaccination('${linked.id}','${esc(it.vaccine).replace(/'/g,"\\'")}')">Mark given</button>`
          : '<span class="faint">—</span>'}</td>
      </tr>`).join('');
    const recorded = (linked.vaccinations||[]).slice().sort((a,b)=>(a.date||'').localeCompare(b.date||''));
    const recRows = recorded.map((v,i)=>`
      <tr><td>${esc(v.vaccine)}</td><td>${v.date?fmtDate(v.date):'—'}</td>
        <td><button class="btn btn-ghost btn-sm" onclick="removeVaccination('${linked.id}',${i})">Remove</button></td></tr>`).join('');
    patientBlock = `
      <div class="banner banner-info">${esc(linked.name)} (${linked.id}) — ${esc(opdAgeDisplay(linked))}
        <button class="btn btn-ghost btn-sm" style="margin-left:8px;" onclick="state.pedLinkedPatientId=null;render()">Unlink</button>
        <button class="btn btn-sm btn-accent" style="margin-left:6px;" onclick="go('newVisit',{patientId:'${linked.id}'})">Start OPD</button>
      </div>
      <h3 style="margin:12px 0 8px;">Suggested by age</h3>
      <p class="faint" style="margin-bottom:8px;">Based on IAP/UIP schedule and this child's age. Confirm clinically before recording.</p>
      <table><thead><tr><th>Age band</th><th>Vaccine</th><th>Status</th><th></th></tr></thead><tbody>${statusRows}</tbody></table>
      <h3 style="margin:18px 0 8px;">Recorded vaccinations</h3>
      ${recorded.length ? `<table><thead><tr><th>Vaccine</th><th>Date</th><th></th></tr></thead><tbody>${recRows}</tbody></table>` : '<p class="muted">None recorded yet.</p>'}
      <div class="row" style="margin-top:12px;">
        <div class="field" style="flex:2;"><label>Add vaccine</label>
          <select id="vac-name">${vaccineOptionsList().map(v=>`<option>${esc(v)}</option>`).join('')}</select>
        </div>
        <div class="field"><label>Date given</label><input id="vac-date" type="date" value="${todayStr()}"></div>
      </div>
      <button class="btn btn-sm" onclick="addVaccination('${linked.id}')">+ Add</button>`;
  }

  return `
    <div class="card" style="margin-bottom:18px;">
      <h2 style="margin-bottom:4px;">Vaccination status</h2>
      <p class="faint" style="margin-bottom:12px;">Track what has been given and see what is due for each child under 16.</p>
      ${patientBlock}
    </div>
    <div class="card">
      <h2 style="margin-bottom:4px;">Full IAP / UIP schedule (reference)</h2>
      <p class="faint" style="margin-bottom:12px;">Recommendations are revised periodically — confirm against the current IAP schedule.</p>
      <table><thead><tr><th>Age</th><th>Vaccines</th></tr></thead><tbody>${scheduleRows}</tbody></table>
    </div>`;
}
async function quickAddVaccination(patientId, vaccine){
  const p = state.data.patients.find(p=>p.id===patientId);
  if(!p) return;
  if(!p.vaccinations) p.vaccinations = [];
  p.vaccinations.push({vaccine, date: todayStr()});
  logAudit('Added vaccination', `${vaccine} — ${p.name} (${p.id})`);
  await saveData();
  render();
}

function pedReferenceHTML(){
  const vRows = PEDIATRIC_VITALS_RANGES.map(r=>`<tr><td>${esc(r.age)}</td><td>${esc(r.hr)}</td><td>${esc(r.rr)}</td><td>${esc(r.sbp)}</td></tr>`).join('');
  const mRows = DEVELOPMENTAL_MILESTONES.map(r=>`<tr><td style="white-space:nowrap;"><strong>${esc(r.age)}</strong></td><td>${esc(r.milestone)}</td></tr>`).join('');
  return `
    <div class="card" style="margin-bottom:18px;">
      <h2 style="margin-bottom:4px;">Normal Vital Signs by Age</h2>
      <p class="faint" style="margin-bottom:12px;">General reference ranges — always interpret alongside the child's clinical state.</p>
      <table><thead><tr><th>Age group</th><th>Heart rate</th><th>Resp. rate</th><th>Systolic BP</th></tr></thead><tbody>${vRows}</tbody></table>
    </div>
    <div class="card">
      <h2 style="margin-bottom:4px;">Developmental Milestones</h2>
      <p class="faint" style="margin-bottom:12px;">Typical ranges — individual variation is normal; persistent, marked delay warrants evaluation.</p>
      <table><thead><tr><th>Age</th><th>Milestone</th></tr></thead><tbody>${mRows}</tbody></table>
    </div>`;
}

/* ============================= BILLING ============================= */
function billingView(){
  const all = [];
  state.data.patients.forEach(p=>{
    (p.visits||[]).forEach(v=>{
      all.push({patient:p, visit:v});
    });
  });
  all.sort((a,b)=> (b.visit.date+b.visit.time).localeCompare(a.visit.date+a.visit.time));
  const q = state.search.trim().toLowerCase();
  let filtered = q ? all.filter(({patient})=> patient.name.toLowerCase().includes(q) || patient.id.toLowerCase().includes(q)) : all;
  if(state.billingUnpaidOnly) filtered = filtered.filter(({visit}) => !billingOf(visit).paid);
  const outstandingTotal = filtered.reduce((sum,{visit})=> !billingOf(visit).paid ? sum + billingTotal(billingOf(visit)) : sum, 0);
  const shown = filtered.slice(0,100);

  const rows = shown.map(({patient,visit})=>{
    const b = billingOf(visit);
    const total = billingTotal(b);
    return `
    <tr class="clickable" onclick="go('billingDetail',{patientId:'${patient.id}',visitId:'${visit.id}'})">
      <td>${fmtDate(visit.date)}</td>
      <td>${esc(patient.name)} <span class="faint">${patient.id}</span></td>
      <td>${total ? '₹'+total.toFixed(0) : '<span class="faint">Not set</span>'}</td>
      <td>${b.paid ? '<span class="pill">Paid</span>' : '<span class="pill" style="background:var(--accent-tint);color:var(--accent);">Unpaid</span>'}</td>
    </tr>`;
  }).join('');

  return `
    <div class="page-head"><h1>Billing</h1></div>
    <div class="card">
      <div class="row" style="align-items:flex-end;margin-bottom:10px;flex-wrap:wrap;gap:10px;">
        <div class="search-wrap" style="flex:1;min-width:180px;">
          <input type="text" placeholder="Search by patient name or ID" value="${esc(state.search)}" oninput="onBillingSearchInput(this.value)">
        </div>
        <button class="btn btn-sm ${state.billingUnpaidOnly?'btn-primary':''}" onclick="toggleBillingUnpaidOnly()">${state.billingUnpaidOnly ? '✓ Unpaid only' : 'Show unpaid only'}</button>
      </div>
      ${state.billingUnpaidOnly ? `<p class="muted" style="margin-bottom:10px;">${filtered.length} unpaid visit${filtered.length===1?'':'s'} · ₹${outstandingTotal.toFixed(0)} outstanding</p>` : ''}
      <div id="billing-table-container">
        ${shown.length ? `<table><thead><tr><th>Date</th><th>Patient</th><th>Total</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table>`
          : `<p class="muted">${state.billingUnpaidOnly ? 'No unpaid visits — nice.' : 'No visits found.'}</p>`}
      </div>
    </div>`;
}
function toggleBillingUnpaidOnly(){ state.billingUnpaidOnly = !state.billingUnpaidOnly; render(); }
function onBillingSearchInput(v){
  state.search = v;
  render();
}

function billingDetailView(patientId, visitId){
  const p = state.data.patients.find(p=>p.id===patientId);
  if(!p) return `<p class="error-text">Patient not found.</p>`;
  const v = (p.visits||[]).find(v=>v.id===visitId);
  if(!v) return `<p class="error-text">Visit not found.</p>`;
  const b = billingOf(v);
  if(!v.billing) v.billing = b;

  const chargeRows = (b.charges||[]).map((c,i)=>`
    <div class="row" data-charge-idx="${i}">
      <div class="field" style="flex:2;"><input data-cf="label" placeholder="e.g. Dressing" value="${esc(c.label)}"></div>
      <div class="field"><input data-cf="amount" type="number" step="0.01" placeholder="Amount" value="${esc(c.amount)}"></div>
      <button class="btn btn-ghost btn-sm" onclick="removeChargeRow(${i})">Remove</button>
    </div>`).join('');

  const ci = state.data.clinicInfo;
  const total = billingTotal(b);
  const receiptSheet = `
    <div class="print-sheet" id="sheet-receipt">
      ${letterheadHTML(ci)}
      <div class="sheet-title">RECEIPT</div>
      <div class="patient-strip">
        <span><strong>${esc(p.name)}</strong> (${p.id})</span>
        <span>${fmtDate(v.date)}</span>
      </div>
      <div class="sheet-section"><span class="lbl">Consultation fee</span><div>₹${(parseFloat(b.fee)||0).toFixed(2)}</div></div>
      ${(b.charges||[]).filter(c=>c.label).map(c=>`<div class="sheet-section"><span class="lbl">${esc(c.label)}</span><div>₹${(parseFloat(c.amount)||0).toFixed(2)}</div></div>`).join('')}
      <div class="sheet-divider"></div>
      <div class="sheet-section"><span class="lbl">Total</span><div style="font-size:20px;font-family:'Source Serif 4',serif;color:var(--primary-dark);">₹${total.toFixed(2)}</div></div>
      <div class="sheet-section" style="margin-top:14px;"><span class="lbl">Payment status</span><div>${b.paid?'Paid'+(b.mode?' — '+esc(b.mode):''):'Unpaid'}</div></div>
    </div>`;

  return `
    <div class="page-head">
      <div><h1>Billing — ${esc(p.name)}</h1><p class="muted">${p.id} · ${fmtDate(v.date)}</p></div>
      <button class="btn btn-ghost" onclick="go('billing')">Back to billing</button>
    </div>
    <div class="card stack" style="max-width:560px;margin-bottom:16px;">
      <div class="field"><label>Consultation fee (₹)</label><input id="bill-fee" type="number" step="0.01" value="${esc(b.fee)}"></div>
      <div>
        <div class="rx-row-head"><h3>Additional charges</h3><button class="btn btn-sm" onclick="addChargeRow()">+ Add charge</button></div>
        <div id="charge-rows">${chargeRows || '<p class="faint">None added.</p>'}</div>
      </div>
      <div class="row">
        <div class="field"><label>Payment status</label>
          <select id="bill-paid"><option value="false" ${!b.paid?'selected':''}>Unpaid</option><option value="true" ${b.paid?'selected':''}>Paid</option></select>
        </div>
        <div class="field"><label>Payment mode</label>
          <select id="bill-mode">
            <option value="" ${!b.mode?'selected':''}>—</option>
            <option ${b.mode==='Cash'?'selected':''}>Cash</option>
            <option ${b.mode==='UPI'?'selected':''}>UPI</option>
            <option ${b.mode==='Card'?'selected':''}>Card</option>
          </select>
        </div>
      </div>
      <div class="row">
        <button class="btn btn-primary" onclick="saveBilling('${p.id}','${v.id}')">Save</button>
        <button class="btn btn-accent" onclick="printSection('sheet-receipt')">Print receipt</button>
      </div>
      <div id="billing-saved-msg" class="faint"></div>
    </div>
    ${receiptSheet}`;
}
function addChargeRow(){
  const v = currentBillingVisit();
  if(!v) return;
  if(!v.billing.charges) v.billing.charges = [];
  v.billing.charges.push({label:'', amount:''});
  document.getElementById('charge-rows').innerHTML = chargeRowsHTML(v.billing.charges);
}
function removeChargeRow(i){
  const v = currentBillingVisit();
  if(!v) return;
  syncChargesFromDOM(v);
  const c = v.billing.charges[i];
  const label = c && (c.label || c.amount) ? ` "${c.label||'Untitled charge'}"${c.amount?' (₹'+c.amount+')':''}` : '';
  if(!confirm(`Remove this charge${label}?`)) return;
  v.billing.charges.splice(i,1);
  document.getElementById('charge-rows').innerHTML = chargeRowsHTML(v.billing.charges);
}
function chargeRowsHTML(charges){
  return (charges||[]).map((c,i)=>`
    <div class="row" data-charge-idx="${i}">
      <div class="field" style="flex:2;"><input data-cf="label" placeholder="e.g. Dressing" value="${esc(c.label)}"></div>
      <div class="field"><input data-cf="amount" type="number" step="0.01" placeholder="Amount" value="${esc(c.amount)}"></div>
      <button class="btn btn-ghost btn-sm" onclick="removeChargeRow(${i})">Remove</button>
    </div>`).join('') || '<p class="faint">None added.</p>';
}
function syncChargesFromDOM(v){
  document.querySelectorAll('[data-charge-idx]').forEach(row=>{
    const i = Number(row.getAttribute('data-charge-idx'));
    if(v.billing.charges[i]){
      v.billing.charges[i] = {
        label: row.querySelector('[data-cf="label"]').value.trim(),
        amount: row.querySelector('[data-cf="amount"]').value.trim()
      };
    }
  });
}
function currentBillingVisit(){
  const {patientId, visitId} = state.routeParams;
  const p = state.data.patients.find(p=>p.id===patientId);
  return p ? (p.visits||[]).find(v=>v.id===visitId) : null;
}

/* ============================= REPORTS ============================= */
function reportDateRange(preset){
  const iso = d => d.toISOString().slice(0,10);
  const now = new Date();
  const y = now.getFullYear(), m = now.getMonth();
  if(preset==='today'){ const t = todayStr(); return {from:t, to:t}; }
  if(preset==='week'){
    const day = now.getDay(); // 0=Sun
    const diffToMonday = (day===0?6:day-1);
    const start = new Date(now); start.setDate(now.getDate()-diffToMonday);
    return {from: iso(start), to: todayStr()};
  }
  if(preset==='lastMonth'){
    return {from: iso(new Date(y, m-1, 1)), to: iso(new Date(y, m, 0))};
  }
  if(preset==='all'){ return {from:'0000-01-01', to:'9999-12-31'}; }
  return {from: iso(new Date(y, m, 1)), to: todayStr()}; // 'month' default
}
function computeReportStats(from, to){
  let visitCount=0, revenue=0, paidRevenue=0, unpaidRevenue=0;
  const byDoctor = {};
  state.data.patients.forEach(p=>{
    (p.visits||[]).forEach(v=>{
      if(!v.date || v.date < from || v.date > to) return;
      visitCount++;
      const b = billingOf(v);
      const total = billingTotal(b);
      revenue += total;
      if(b.paid) paidRevenue += total; else unpaidRevenue += total;
      const doc = v.doctorName || 'Unassigned';
      if(!byDoctor[doc]) byDoctor[doc] = {visits:0, revenue:0};
      byDoctor[doc].visits++;
      byDoctor[doc].revenue += total;
    });
  });
  const newPatients = state.data.patients.filter(p=>p.registeredDate && p.registeredDate>=from && p.registeredDate<=to).length;
  const doctorRows = Object.entries(byDoctor).sort((a,b)=>b[1].visits-a[1].visits);
  return {visitCount, revenue, paidRevenue, unpaidRevenue, newPatients, doctorRows};
}
function setReportRange(preset){
  state.reportRange = preset;
  render();
}

/* ============================= MEDICAL CERTIFICATES ============================= */
function certificatesView(){
  const q = (state.search||'').trim().toLowerCase();
  const linked = state.certPatientId ? state.data.patients.find(p=>p.id===state.certPatientId) : null;
  const type = state.certType || 'sick';
  const types = [
    ['sick','Medical leave'],
    ['fitness','Fitness'],
    ['school','School / College'],
    ['general','General medical']
  ];
  const typeNav = types.map(([k,l])=>
    `<button class="btn btn-sm ${type===k?'btn-primary':''}" onclick="state.certType='${k}';render()">${l}</button>`
  ).join(' ');

  let searchBlock = '';
  if(!linked){
    const list = q ? state.data.patients.filter(p=>
      p.name.toLowerCase().includes(q) || p.id.toLowerCase().includes(q) || (p.phone||'').includes(q)
    ).slice(0,10) : [];
    searchBlock = `
      <div class="card" style="margin-bottom:18px;max-width:560px;">
        <h2 style="margin-bottom:6px;">Select patient</h2>
        <p class="faint" style="margin-bottom:12px;">Any registered patient can get a certificate. Search below, or open Certificate from their patient page or visit summary.</p>
        <div class="search-wrap"><input type="text" placeholder="Search by name, ID or phone" value="${esc(state.search||'')}" oninput="state.search=this.value;render()"></div>
        <div style="margin-top:10px;">
          ${list.map(p=>`<div class="rx-row" style="cursor:pointer;" onclick="state.certPatientId='${p.id}';state.search='';render()">
            <strong>${esc(p.name)}</strong> <span class="pill">${p.id}</span>
            <div class="faint">${esc(opdAgeDisplay(p))} / ${esc(p.sex)} ${p.phone?'· '+esc(p.phone):''}</div>
          </div>`).join('') || (q?`<p class="faint">No matches.</p>`:`<p class="faint">Type to search patients.</p>`)}
        </div>
      </div>`;
  } else {
    searchBlock = `<div class="banner banner-info" style="margin-bottom:14px;">
      Certificate for <strong>${esc(linked.name)}</strong> <span class="pill">${linked.id}</span> — ${esc(opdAgeDisplay(linked))} / ${esc(linked.sex)}
      <button class="btn btn-ghost btn-sm" style="margin-left:8px;" onclick="state.certPatientId=null;state.search='';render()">Change patient</button>
    </div>`;
  }

  const today = todayStr();
  const defaultDoctor = state.session.staffName || '';
  const qual = staffQualification(defaultDoctor);
  let form = '';
  if(linked){
    const lastVisit = (linked.visits||[]).slice().sort((a,b)=>(b.date+b.id).localeCompare(a.date+a.id))[0];
    const lastDx = lastVisit && lastVisit.diagnosis ? lastVisit.diagnosis : '';
    const commonFields = `
      <div class="row">
        <div class="field"><label>Certificate date</label><input id="cert-date" type="date" value="${today}"></div>
        <div class="field"><label>Certificate no. (optional)</label><input id="cert-no" placeholder="Auto if left blank"></div>
      </div>
      <div class="row">
        <div class="field"><label>Doctor name *</label><input id="cert-doctor" value="${esc(defaultDoctor)}"></div>
        <div class="field"><label>Qualification</label><input id="cert-qual" value="${esc(qual)}" placeholder="e.g. M.B.B.S."></div>
      </div>
      <div class="field"><label>Place of issue</label><input id="cert-place" value="${esc((state.data.clinicInfo&&state.data.clinicInfo.address)||'')}" placeholder="Clinic address / city"></div>`;

    if(type==='sick'){
      form = `
        <div class="card" style="margin-bottom:16px;max-width:640px;">
          <h2 style="margin-bottom:4px;">Medical leave / sick leave certificate</h2>
          <p class="faint" style="margin-bottom:14px;">Enter diagnosis and rest period. A formal certificate will be generated for print.</p>
          ${commonFields}
          <div class="row">
            <div class="field"><label>Leave from *</label><input id="cert-from" type="date" value="${today}"></div>
            <div class="field"><label>Leave to *</label><input id="cert-to" type="date" value="${today}"></div>
          </div>
          <div class="field"><label>Diagnosis / clinical condition *</label>
            <input id="cert-diagnosis" value="${esc(lastDx)}" placeholder="e.g. Acute febrile illness / Viral fever">
          </div>
          <div class="field"><label>Nature of illness (brief)</label>
            <textarea id="cert-nature" placeholder="e.g. Patient presented with high-grade fever and body ache">${esc(lastVisit&&lastVisit.complaints?lastVisit.complaints:'')}</textarea>
          </div>
          <div class="field"><label>Advice / treatment</label>
            <input id="cert-advice" value="Rest and medication as prescribed. Avoid strenuous activity.">
          </div>
          <div class="field"><label>Fit to resume duty / school from (optional)</label>
            <input id="cert-resume" type="date">
          </div>
          <div class="field"><label>Additional remarks</label>
            <textarea id="cert-remarks" placeholder="Optional"></textarea>
          </div>
          <div id="cert-error" class="error-text"></div>
          <button class="btn btn-primary" onclick="renderCertificatePreview('sick')">Generate medical certificate</button>
        </div>`;
    } else if(type==='fitness'){
      form = `
        <div class="card" style="margin-bottom:16px;max-width:640px;">
          <h2 style="margin-bottom:4px;">Fitness certificate</h2>
          <p class="faint" style="margin-bottom:14px;">For employment, sports, travel, or other fitness declarations.</p>
          ${commonFields}
          <div class="field"><label>Purpose *</label>
            <input id="cert-purpose" placeholder="e.g. Employment / Sports / Driving / Travel abroad">
          </div>
          <div class="field"><label>Examination findings *</label>
            <textarea id="cert-findings">General physical examination was carried out. The above-named person is medically fit for the stated purpose.</textarea>
          </div>
          <div class="row">
            <div class="field"><label>Height (cm)</label><input id="cert-height" placeholder="optional"></div>
            <div class="field"><label>Weight (kg)</label><input id="cert-weight" placeholder="optional"></div>
            <div class="field"><label>BP</label><input id="cert-bp" placeholder="optional"></div>
          </div>
          <div class="field"><label>Any known disability / limitation</label>
            <input id="cert-limitation" value="None" placeholder="None / or describe">
          </div>
          <div class="field"><label>Additional remarks</label><textarea id="cert-remarks" placeholder="Optional"></textarea></div>
          <div id="cert-error" class="error-text"></div>
          <button class="btn btn-primary" onclick="renderCertificatePreview('fitness')">Generate fitness certificate</button>
        </div>`;
    } else if(type==='school'){
      form = `
        <div class="card" style="margin-bottom:16px;max-width:640px;">
          <h2 style="margin-bottom:4px;">School / College medical certificate</h2>
          <p class="faint" style="margin-bottom:14px;">For attendance, leave, or fitness to join school/college activities.</p>
          ${commonFields}
          <div class="field"><label>School / College name *</label>
            <input id="cert-school" placeholder="Name of institution">
          </div>
          <div class="field"><label>Class / Course (optional)</label>
            <input id="cert-class" placeholder="e.g. Class 10 / B.Com I year">
          </div>
          <div class="field"><label>Purpose *</label>
            <select id="cert-purpose">
              <option>Medical leave / absence from class</option>
              <option>Fitness for attendance</option>
              <option>Fitness for sports / physical education</option>
              <option>General medical fitness</option>
            </select>
          </div>
          <div class="row">
            <div class="field"><label>Leave from (if leave)</label><input id="cert-from" type="date" value="${today}"></div>
            <div class="field"><label>Leave to (if leave)</label><input id="cert-to" type="date" value="${today}"></div>
          </div>
          <div class="field"><label>Diagnosis / findings *</label>
            <input id="cert-diagnosis" value="${esc(lastDx)}" placeholder="e.g. Upper respiratory tract infection / Fit on examination">
          </div>
          <div class="field"><label>Advice</label>
            <input id="cert-advice" value="Rest and treatment as advised. Fit to resume classes after the leave period.">
          </div>
          <div class="field"><label>Additional remarks</label><textarea id="cert-remarks" placeholder="Optional"></textarea></div>
          <div id="cert-error" class="error-text"></div>
          <button class="btn btn-primary" onclick="renderCertificatePreview('school')">Generate school certificate</button>
        </div>`;
    } else {
      form = `
        <div class="card" style="margin-bottom:16px;max-width:640px;">
          <h2 style="margin-bottom:4px;">General medical certificate</h2>
          <p class="faint" style="margin-bottom:14px;">Flexible certificate — fill diagnosis and statement as required.</p>
          ${commonFields}
          <div class="field"><label>Subject / title of certificate</label>
            <input id="cert-subject" value="MEDICAL CERTIFICATE" placeholder="e.g. MEDICAL CERTIFICATE">
          </div>
          <div class="field"><label>Diagnosis / clinical condition *</label>
            <input id="cert-diagnosis" value="${esc(lastDx)}" placeholder="Required">
          </div>
          <div class="field"><label>Certificate body / statement *</label>
            <textarea id="cert-body" rows="5" placeholder="Write the main statement of the certificate. Patient details will still appear in the formal header.">The above-named patient was examined by me. Based on clinical examination, the diagnosis and advice are as stated above.</textarea>
          </div>
          <div class="field"><label>Advice / recommendations</label>
            <textarea id="cert-advice" placeholder="Optional"></textarea>
          </div>
          <div class="field"><label>Additional remarks</label><textarea id="cert-remarks" placeholder="Optional"></textarea></div>
          <div id="cert-error" class="error-text"></div>
          <button class="btn btn-primary" onclick="renderCertificatePreview('general')">Generate certificate</button>
        </div>`;
    }
  }

  return `
    <div class="page-head">
      <div>
        <h1>Medical certificates</h1>
        <p class="muted">Issue formal leave, fitness, school or general medical certificates for any patient</p>
      </div>
    </div>
    ${searchBlock}
    ${linked?`<div class="row" style="margin-bottom:14px;flex-wrap:wrap;gap:8px;">${typeNav}</div>`:''}
    ${form}
    <div id="cert-preview"></div>`;
}

function certVal(id){
  const el = document.getElementById(id);
  return el ? el.value.trim() : '';
}
function nextCertificateNo(){
  if(!state.data.nextCertSeq) state.data.nextCertSeq = 1;
  const n = state.data.nextCertSeq;
  state.data.nextCertSeq = n + 1;
  return 'MC-' + todayStr().replace(/-/g,'') + '-' + String(n).padStart(3,'0');
}
function daysBetweenInclusive(from, to){
  if(!from || !to) return null;
  const a = new Date(from+'T00:00:00'), b = new Date(to+'T00:00:00');
  if(isNaN(a)||isNaN(b)||b < a) return null;
  return Math.round((b - a) / 86400000) + 1;
}
function pronounForSex(sex){
  if((sex||'').toLowerCase()==='male') return {subj:'He', obj:'him', poss:'his', HeShe:'He', hisHer:'his'};
  if((sex||'').toLowerCase()==='female') return {subj:'She', obj:'her', poss:'her', HeShe:'She', hisHer:'her'};
  return {subj:'They', obj:'them', poss:'their', HeShe:'They', hisHer:'their'};
}

function renderCertificatePreview(type){
  const p = state.data.patients.find(x=>x.id===state.certPatientId);
  if(!p) return;
  const err = document.getElementById('cert-error');
  const ci = state.data.clinicInfo;
  const doctor = certVal('cert-doctor');
  const qual = certVal('cert-qual') || staffQualification(doctor);
  const certDateRaw = certVal('cert-date') || todayStr();
  const certDate = fmtDate(certDateRaw);
  let certNo = certVal('cert-no');
  if(!certNo) certNo = nextCertificateNo();
  const place = certVal('cert-place') || (ci.address||'');
  const remarks = certVal('cert-remarks');
  const pr = pronounForSex(p.sex);

  if(!doctor){
    if(err) err.textContent = 'Doctor name is required.';
    return;
  }

  let title = 'MEDICAL CERTIFICATE';
  let bodyHtml = '';

  if(type==='sick'){
    const fromRaw = certVal('cert-from');
    const toRaw = certVal('cert-to');
    const diagnosis = certVal('cert-diagnosis');
    const nature = certVal('cert-nature');
    const advice = certVal('cert-advice');
    const resumeRaw = certVal('cert-resume');
    if(!fromRaw || !toRaw || !diagnosis){
      if(err) err.textContent = 'Leave from, leave to, and diagnosis are required.';
      return;
    }
    if(err) err.textContent = '';
    const days = daysBetweenInclusive(fromRaw, toRaw);
    title = 'MEDICAL LEAVE CERTIFICATE';
    bodyHtml = `
      <p>This is to certify that <strong>${esc(p.name)}</strong>, ${esc(opdAgeDisplay(p))} / ${esc(p.sex||'—')}, Patient ID <strong>${esc(p.id)}</strong>${p.address?', residing at '+esc(p.address):''}, was examined and treated under my care.</p>
      ${certPatientFacts(p)}
      <p><strong>Diagnosis:</strong> ${esc(diagnosis)}</p>
      ${nature?`<p><strong>Clinical notes:</strong> ${esc(nature)}</p>`:''}
      <p>${pr.HeShe} is advised medical leave from <strong>${fmtDate(fromRaw)}</strong> to <strong>${fmtDate(toRaw)}</strong>${days?` (${days} day${days===1?'':'s'})`:''}.</p>
      ${advice?`<p><strong>Advice:</strong> ${esc(advice)}</p>`:''}
      ${resumeRaw?`<p>${pr.HeShe} is fit to resume duty / school / college with effect from <strong>${fmtDate(resumeRaw)}</strong>.</p>`
        :`<p>${pr.HeShe} is advised to resume normal activity only after the leave period, or as further advised.</p>`}
      ${remarks?`<p><strong>Remarks:</strong> ${esc(remarks)}</p>`:''}
      <p style="margin-top:14px;">This certificate is issued on the patient's request for official / leave purposes.</p>`;
  } else if(type==='fitness'){
    const purpose = certVal('cert-purpose');
    const findings = certVal('cert-findings');
    const height = certVal('cert-height');
    const weight = certVal('cert-weight');
    const bp = certVal('cert-bp');
    const limitation = certVal('cert-limitation');
    if(!purpose || !findings){
      if(err) err.textContent = 'Purpose and examination findings are required.';
      return;
    }
    if(err) err.textContent = '';
    title = 'FITNESS CERTIFICATE';
    const vitalsBits = [height?`Height: ${esc(height)} cm`:'', weight?`Weight: ${esc(weight)} kg`:'', bp?`BP: ${esc(bp)}`:''].filter(Boolean).join(' · ');
    bodyHtml = `
      <p>This is to certify that <strong>${esc(p.name)}</strong>, ${esc(opdAgeDisplay(p))} / ${esc(p.sex||'—')}, Patient ID <strong>${esc(p.id)}</strong>${p.address?', residing at '+esc(p.address):''}, has been medically examined by me on <strong>${certDate}</strong>.</p>
      ${certPatientFacts(p)}
      <p><strong>Purpose:</strong> ${esc(purpose)}</p>
      ${vitalsBits?`<p><strong>Recorded measurements:</strong> ${vitalsBits}</p>`:''}
      <p><strong>Findings:</strong> ${esc(findings)}</p>
      ${limitation?`<p><strong>Disability / limitation:</strong> ${esc(limitation)}</p>`:''}
      ${remarks?`<p><strong>Remarks:</strong> ${esc(remarks)}</p>`:''}
      <p style="margin-top:14px;">In my opinion, the above-named person is <strong>medically fit</strong> for the stated purpose at the time of examination.</p>`;
  } else if(type==='school'){
    const school = certVal('cert-school');
    const klass = certVal('cert-class');
    const purpose = certVal('cert-purpose') || 'Medical leave / absence from class';
    const diagnosis = certVal('cert-diagnosis');
    const advice = certVal('cert-advice');
    const fromRaw = certVal('cert-from');
    const toRaw = certVal('cert-to');
    if(!school || !diagnosis){
      if(err) err.textContent = 'School/college name and diagnosis/findings are required.';
      return;
    }
    if(err) err.textContent = '';
    title = 'SCHOOL / COLLEGE MEDICAL CERTIFICATE';
    const days = daysBetweenInclusive(fromRaw, toRaw);
    const isLeave = /leave|absence/i.test(purpose);
    bodyHtml = `
      <p>This is to certify that <strong>${esc(p.name)}</strong>, ${esc(opdAgeDisplay(p))} / ${esc(p.sex||'—')}, Patient ID <strong>${esc(p.id)}</strong>, student of <strong>${esc(school)}</strong>${klass?' ('+esc(klass)+')':''}, was examined by me on <strong>${certDate}</strong>.</p>
      ${certPatientFacts(p)}
      <p><strong>Purpose:</strong> ${esc(purpose)}</p>
      <p><strong>Diagnosis / findings:</strong> ${esc(diagnosis)}</p>
      ${isLeave && fromRaw && toRaw
        ? `<p>${pr.HeShe} is advised medical leave from <strong>${fmtDate(fromRaw)}</strong> to <strong>${fmtDate(toRaw)}</strong>${days?` (${days} day${days===1?'':'s'})`:''}.</p>`
        : ''}
      ${advice?`<p><strong>Advice:</strong> ${esc(advice)}</p>`:''}
      ${remarks?`<p><strong>Remarks:</strong> ${esc(remarks)}</p>`:''}
      <p style="margin-top:14px;">This certificate is issued for submission to the school / college authorities.</p>`;
  } else {
    const subject = certVal('cert-subject') || 'MEDICAL CERTIFICATE';
    const diagnosis = certVal('cert-diagnosis');
    const body = certVal('cert-body');
    const advice = certVal('cert-advice');
    if(!diagnosis || !body){
      if(err) err.textContent = 'Diagnosis and certificate statement are required.';
      return;
    }
    if(err) err.textContent = '';
    title = subject.toUpperCase();
    bodyHtml = `
      <p>This is to certify that <strong>${esc(p.name)}</strong>, ${esc(opdAgeDisplay(p))} / ${esc(p.sex||'—')}, Patient ID <strong>${esc(p.id)}</strong>${p.address?', residing at '+esc(p.address):''}, was examined by me.</p>
      ${certPatientFacts(p)}
      <p><strong>Diagnosis:</strong> ${esc(diagnosis)}</p>
      <p>${esc(body)}</p>
      ${advice?`<p><strong>Advice:</strong> ${esc(advice)}</p>`:''}
      ${remarks?`<p><strong>Remarks:</strong> ${esc(remarks)}</p>`:''}`;
  }

  saveData();

  const html = `
    <div class="print-sheet opd-card cert-sheet" id="sheet-cert">
      ${letterheadHTML(ci)}
      <div class="opd-badge">${esc(title)}</div>
      <div class="cert-meta">
        <span>No. <strong>${esc(certNo)}</strong></span>
        <span>Date: <strong>${certDate}</strong></span>
      </div>
      <div class="cert-body">
        ${bodyHtml}
      </div>
      <div class="cert-footer">
        <div class="cert-place">
          ${place?`<div class="faint">Place</div><div>${esc(place)}</div>`:''}
          <div class="faint" style="margin-top:10px;">Date</div>
          <div>${certDate}</div>
        </div>
        <div class="cert-sign">
          <div class="opd-sign-space"></div>
          <div class="opd-sign-name">${esc(doctor)}</div>
          ${qual?`<div class="opd-doctor-qual" style="text-align:center;width:180px;">${esc(qual)}</div>`:''}
          <div class="opd-sign-label">Signature &amp; stamp</div>
        </div>
      </div>
    </div>
    <div class="row" style="margin-top:12px;gap:8px;">
      <button class="btn btn-primary" onclick="printSection('sheet-cert')">Print certificate</button>
      <button class="btn btn-ghost" onclick="document.getElementById('cert-preview').innerHTML=''">Clear preview</button>
    </div>`;
  const box = document.getElementById('cert-preview');
  if(box){
    box.innerHTML = html;
    box.scrollIntoView({behavior:'smooth', block:'start'});
  }
  logAudit('Generated certificate', `${type} ${certNo} — ${p.name} (${p.id})`);
}


function reportsView(){
  state.reportRange = state.reportRange || 'month';
  const range = reportDateRange(state.reportRange);
  const stats = computeReportStats(range.from, range.to);
  const presets = [['today','Today'],['week','This week'],['month','This month'],['lastMonth','Last month'],['all','All time']];
  const presetBtns = presets.map(([k,label])=>
    `<button class="btn btn-sm ${state.reportRange===k?'btn-primary':''}" onclick="setReportRange('${k}')">${label}</button>`
  ).join(' ');
  const doctorRows = stats.doctorRows.map(([name,d])=>
    `<tr><td>${esc(name)}</td><td>${d.visits}</td><td>₹${d.revenue.toFixed(0)}</td></tr>`
  ).join('');
  const periodLabel = state.reportRange==='all' ? 'All recorded visits' : `${fmtDate(range.from)} – ${fmtDate(range.to)}`;
  const ci = state.data.clinicInfo;
  const reportSheet = `
    <div class="print-sheet" id="sheet-report" style="max-width:680px;">
      ${letterheadHTML(ci)}
      <div class="sheet-title">CLINIC REPORT — ${esc(periodLabel.toUpperCase())}</div>
      <div class="sheet-section"><span class="lbl">Visits</span><div>${stats.visitCount}</div></div>
      <div class="sheet-section"><span class="lbl">New patients</span><div>${stats.newPatients}</div></div>
      <div class="sheet-section"><span class="lbl">Total revenue</span><div>₹${stats.revenue.toFixed(2)}</div></div>
      <div class="sheet-section"><span class="lbl">Collected</span><div>₹${stats.paidRevenue.toFixed(2)}</div></div>
      <div class="sheet-section"><span class="lbl">Outstanding</span><div>₹${stats.unpaidRevenue.toFixed(2)}</div></div>
      <div class="sheet-divider"></div>
      <div class="sheet-title">VISITS BY DOCTOR</div>
      ${doctorRows ? `<table><thead><tr><th>Doctor</th><th>Visits</th><th>Revenue</th></tr></thead><tbody>${doctorRows}</tbody></table>` : '<p>No visits in this period.</p>'}
      <p class="faint" style="margin-top:16px;">Generated ${fmtDate(todayStr())}</p>
    </div>`;
  return `
    <div class="page-head">
      <h1>Reports</h1>
      <div class="row">
        <button class="btn btn-sm" onclick="printSection('sheet-report')">🖶 Print report</button>
        <button class="btn btn-sm" onclick="exportReportCSV()">⬇ Export CSV</button>
      </div>
    </div>
    <div class="row" style="margin-bottom:12px;flex-wrap:wrap;gap:8px;">${presetBtns}</div>
    <p class="muted" style="margin-bottom:16px;">${periodLabel}</p>
    <div class="stat-grid" style="margin-bottom:20px;">
      <div class="stat-card"><div class="stat-num">${stats.visitCount}</div><div class="stat-label">Visits</div></div>
      <div class="stat-card"><div class="stat-num">₹${stats.revenue.toFixed(0)}</div><div class="stat-label">Total revenue</div></div>
      <div class="stat-card"><div class="stat-num">₹${stats.paidRevenue.toFixed(0)}</div><div class="stat-label">Collected</div></div>
      <div class="stat-card"><div class="stat-num">₹${stats.unpaidRevenue.toFixed(0)}</div><div class="stat-label">Outstanding</div></div>
      <div class="stat-card"><div class="stat-num">${stats.newPatients}</div><div class="stat-label">New patients</div></div>
    </div>
    <div class="card">
      <h2 style="margin-bottom:10px;">Visits by doctor</h2>
      ${doctorRows ? `<table><thead><tr><th>Doctor</th><th>Visits</th><th>Revenue</th></tr></thead><tbody>${doctorRows}</tbody></table>` : '<p class="muted">No visits in this period.</p>'}
    </div>
    ${reportSheet}`;
}
function csvCell(v){
  const s = String(v==null?'':v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g,'""')}"` : s;
}
function exportReportCSV(){
  state.reportRange = state.reportRange || 'month';
  const range = reportDateRange(state.reportRange);
  const stats = computeReportStats(range.from, range.to);
  const periodLabel = state.reportRange==='all' ? 'All time' : `${fmtDate(range.from)} to ${fmtDate(range.to)}`;
  const lines = [
    ['Clinic report', periodLabel],
    [],
    ['Metric','Value'],
    ['Visits', stats.visitCount],
    ['New patients', stats.newPatients],
    ['Total revenue', stats.revenue.toFixed(2)],
    ['Collected', stats.paidRevenue.toFixed(2)],
    ['Outstanding', stats.unpaidRevenue.toFixed(2)],
    [],
    ['Doctor','Visits','Revenue'],
    ...stats.doctorRows.map(([name,d])=>[name, d.visits, d.revenue.toFixed(2)])
  ];
  const csv = lines.map(row=>row.map(csvCell).join(',')).join('\n');
  const blob = new Blob([csv], {type:'text/csv'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `mmc-report-${state.reportRange}-${todayStr()}.csv`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
async function saveBilling(patientId, visitId){
  const p = state.data.patients.find(p=>p.id===patientId);
  const v = p && (p.visits||[]).find(v=>v.id===visitId);
  if(!v) return;
  if(!v.billing) v.billing = { fee:'', charges:[], paid:false, mode:'' };
  syncChargesFromDOM(v);
  v.billing.fee = document.getElementById('bill-fee').value.trim();
  v.billing.paid = document.getElementById('bill-paid').value === 'true';
  v.billing.mode = document.getElementById('bill-mode').value;
  logAudit('Updated billing', `${p.name} (${p.id}) — ₹${billingTotal(v.billing).toFixed(0)}${v.billing.paid?' (paid)':' (unpaid)'}`);
  const ok = await saveData();
  const msg = document.getElementById('billing-saved-msg');
  if(msg) msg.textContent = ok ? 'Saved ✓' : 'Could not save — try again';
}

function settingsView(){
  const ci = state.data.clinicInfo;
  const canManageStaff = isOwner();
  const editingName = state.ui.editingStaffName || null;
  const staffRows = state.data.staff.map(s=>{
    if(canManageStaff && editingName === s.name){
      return `<tr>
        <td colspan="5">
          <div class="card" style="padding:14px;margin:4px 0;background:var(--primary-tint,#E8F1F6);">
            <h3 style="margin-bottom:10px;">Edit profile — ${esc(s.name)}</h3>
            <div class="row">
              <div class="field"><label>Role</label>
                <select id="edit-st-role">
                  ${['Doctor','Receptionist','Staff'].map(r=>`<option ${s.role===r?'selected':''}>${r}</option>`).join('')}
                </select>
              </div>
              <div class="field" style="flex:2;"><label>Qualification / course</label>
                <input id="edit-st-qualification" value="${esc(s.qualification||'')}" placeholder="e.g. M.B.B.S., M.D. Paediatrics">
              </div>
            </div>
            <div class="row" style="gap:8px;">
              <button class="btn btn-primary btn-sm" onclick="saveStaffProfileEdit('${esc(s.name)}')">Save profile</button>
              <button class="btn btn-ghost btn-sm" onclick="cancelEditStaffProfile()">Cancel</button>
              <button class="btn btn-ghost btn-sm" onclick="resetStaffPin('${esc(s.name)}')">Reset PIN</button>
            </div>
          </div>
        </td>
      </tr>`;
    }
    return `<tr>
      <td>${esc(s.name)}${s.owner?' <span class="pill" title="Can manage all staff accounts">Admin</span>':''}</td>
      <td>${esc(s.role)}</td>
      <td>${esc(s.qualification)||'<span class="faint">—</span>'}</td>
      <td>••••</td>
      <td style="white-space:nowrap;">
        ${canManageStaff ? `
          <button class="btn btn-sm" onclick="startEditStaffProfile('${esc(s.name)}')">Edit</button>
          ${s.name!==state.session.staffName && !s.owner ? `<button class="btn btn-ghost btn-sm" onclick="removeStaff('${esc(s.name)}')">Remove</button>` : (s.name===state.session.staffName?'<span class="faint">(you)</span>':'')}
        ` : `<span class="faint">${s.name===state.session.staffName?'(you)':'—'}</span>`}
      </td></tr>`;
  }).join('');
  const meds = state.data.customMedicines||[];
  const medRows = meds.map((m,i)=>`
    <tr><td>${esc(m.name)}</td><td>${(m.dosages||[]).map(esc).join(', ')||'<span class="faint">—</span>'}</td>
      <td><button class="btn btn-ghost btn-sm" onclick="removeCustomMedicine(${i})">Remove</button></td></tr>`).join('');
  const templates = state.data.rxTemplates||[];
  const templateRows = templates.map((t,i)=>`
    <tr><td>${esc(t.name)}</td><td>${(t.prescriptions||[]).length} medicine(s)</td><td>${(t.investigations||[]).length} test(s)</td>
      <td><button class="btn btn-ghost btn-sm" onclick="removeRxTemplate(${i})">Remove</button></td></tr>`).join('');

  return `
    <div class="page-head"><h1>Settings</h1></div>
    <div class="card" style="margin-bottom:18px;max-width:520px;">
      <h2 style="margin-bottom:12px;">Clinic info</h2>
      <div class="field"><label>Clinic name</label><input id="ci-name" value="${esc(ci.name)}"></div>
      <div class="field"><label>Address (shown on printouts)</label><input id="ci-address" value="${esc(ci.address)}"></div>
      <div class="field"><label>Phone (shown on printouts)</label><input id="ci-phone" value="${esc(ci.phone)}"></div>
      <div class="field"><label>Clinic logo (shown on every printout)</label>
        <div class="row" style="align-items:center;gap:12px;">
          ${ci.logo ? `<img class="logo-preview" src="${esc(ci.logo)}" alt="Clinic logo">` : `<div class="letterhead-mark">MMC</div>`}
          <div>
            <input type="file" id="ci-logo-file" accept="image/*" style="display:none;" onchange="onClinicLogoFile(this.files[0])">
            <button class="btn btn-sm" onclick="document.getElementById('ci-logo-file').click()">Upload logo</button>
            ${ci.logo ? `<button class="btn btn-ghost btn-sm" onclick="clearClinicLogo()">Remove</button>` : ''}
            <p class="faint" style="margin:6px 0 0;">PNG or JPG, under 500 KB. A gold MMC mark is used if none is uploaded.</p>
          </div>
        </div>
      </div>
      <button class="btn btn-primary" onclick="saveClinicInfo()">Save</button>
    </div>

    <div class="card" style="margin-bottom:18px;max-width:520px;">
      <h2 style="margin-bottom:6px;">Backup &amp; export</h2>
      <p class="muted" style="font-size:12.5px;">Downloads every patient, visit, and staff record as a single JSON file — keep a copy somewhere safe periodically, especially before any database change.</p>
      <div class="row" style="gap:8px;flex-wrap:wrap;margin-bottom:8px;">
        <button class="btn btn-sm" onclick="downloadBackup()">⬇ Full backup (JSON)</button>
        <button class="btn btn-sm" onclick="exportPatientsCSV()">⬇ Patients list (CSV)</button>
        <button class="btn btn-sm" onclick="exportVisitsCSV()">⬇ Visits list (CSV)</button>
      </div>
      <div class="sheet-divider"></div>
      <p class="muted" style="font-size:12.5px;">Restoring replaces <strong>everything</strong> currently in the system with the contents of the backup file — use this to recover from an accidental "Erase all clinic data", a corrupted save, or to move records onto a new server.</p>
      <input type="file" id="restore-file-input" accept="application/json" style="display:none;" onchange="restoreBackup(this.files[0])">
      <button class="btn btn-sm btn-danger" onclick="document.getElementById('restore-file-input').click()">⬆ Restore from backup…</button>
      <div id="restore-msg" class="error-text"></div>
    </div>

    <div class="card" style="margin-bottom:18px;max-width:520px;">
      <h2 style="margin-bottom:6px;">Activity log</h2>
      <p class="muted" style="font-size:12.5px;">Who changed what, and when — patients, visits, billing, staff accounts and more.</p>
      <button class="btn btn-sm" onclick="go('auditLog')">View activity log</button>
    </div>

    <div class="card" style="margin-bottom:18px;max-width:640px;">
      <h2 style="margin-bottom:6px;">Saved medicines</h2>
      <p class="muted" style="font-size:12.5px;">Add here, or straight from a prescription with "+ Save this medicine to my list" — either way, they show up as suggestions when prescribing, alongside the built-in list.</p>
      ${meds.length ? `<table><thead><tr><th>Name</th><th>Dosages</th><th></th></tr></thead><tbody>${medRows}</tbody></table>` : `<p class="muted">None added yet.</p>`}
      <div class="row" style="margin-top:14px;">
        <div class="field" style="flex:2;"><label>Name (include Tab./Syp./Inj./IV Fluid etc.)</label><input id="cm-name" placeholder="e.g. Tab. Nimesulide"></div>
        <div class="field" style="flex:2;"><label>Dosages (comma-separated)</label><input id="cm-dosages" placeholder="e.g. 100mg, 200mg"></div>
      </div>
      <button class="btn btn-sm" onclick="addCustomMedicine()">+ Add medicine</button>
    </div>

    <div class="card" style="margin-bottom:18px;max-width:640px;">
      <h2 style="margin-bottom:6px;">Prescription templates</h2>
      <p class="muted" style="font-size:12.5px;">Save a whole combination of medicines and tests as one reusable template — from the Prescription section of a visit — for OPD cases that repeat the same standard Rx.</p>
      ${templates.length ? `<table><thead><tr><th>Name</th><th>Medicines</th><th>Tests</th><th></th></tr></thead><tbody>${templateRows}</tbody></table>` : `<p class="muted">None saved yet.</p>`}
    </div>

    <div class="card" style="margin-bottom:18px;max-width:720px;">
      <h2 style="margin-bottom:6px;">Staff accounts</h2>
      ${canManageStaff
        ? `<p class="muted" style="font-size:12.5px;margin-bottom:12px;">As clinic admin you can edit every profile — role, qualification (shown on OPD cards), and PIN.</p>`
        : `<p class="muted" style="font-size:12.5px;margin-bottom:12px;">Only the clinic admin can edit staff profiles. Contact them to update your qualification or role.</p>`}
      <table><thead><tr><th>Name</th><th>Role</th><th>Qualification</th><th>PIN</th><th></th></tr></thead><tbody>${staffRows}</tbody></table>
      ${canManageStaff ? `
      <div class="row" style="margin-top:14px;">
        <div class="field"><label>Name</label><input id="st-name"></div>
        <div class="field"><label>Role</label><select id="st-role"><option>Doctor</option><option>Receptionist</option><option>Staff</option></select></div>
        <div class="field"><label>Qualification / course</label><input id="st-qualification" placeholder="e.g. M.B.B.S."></div>
        <div class="field"><label>4-digit PIN</label><input id="st-pin" inputmode="numeric" maxlength="4"></div>
      </div>
      <div id="st-error" class="error-text"></div>
      <button class="btn btn-sm" onclick="addStaff()">+ Add staff</button>
      ` : ''}
    </div>

    <div class="card" style="max-width:520px;border-color:var(--danger);">
      <h2 style="color:var(--danger);margin-bottom:8px;">Danger zone</h2>
      <p class="muted">This permanently deletes every patient, visit and staff account. Type RESET to confirm.</p>
      <div class="field"><input oninput="onResetConfirmInput(this.value)" placeholder="RESET"></div>
      <button id="reset-btn" class="btn btn-danger" disabled onclick="doReset()">Erase all clinic data</button>
    </div>`;
}

function onAuditSearchInput(v){
  state.auditSearch = v;
  const el = document.getElementById('audit-log-container');
  if(el) el.innerHTML = auditLogTableHTML();
}
function auditLogTableHTML(){
  const q = (state.auditSearch||'').trim().toLowerCase();
  let entries = (state.data.auditLog||[]).slice().reverse(); // newest first
  if(q){
    entries = entries.filter(e =>
      (e.staff||'').toLowerCase().includes(q) ||
      (e.action||'').toLowerCase().includes(q) ||
      (e.details||'').toLowerCase().includes(q)
    );
  }
  const shown = entries.slice(0,200);
  if(!shown.length) return `<p class="muted">No activity recorded${q?' matching that search':' yet'}.</p>`;
  const rows = shown.map(e=>{
    const d = new Date(e.ts);
    const when = isNaN(d) ? (e.ts||'') : d.toLocaleString('en-IN',{day:'2-digit',month:'short',year:'numeric',hour:'2-digit',minute:'2-digit'});
    return `<tr><td style="white-space:nowrap;">${esc(when)}</td><td>${esc(e.staff)}</td><td>${esc(e.action)}</td><td>${esc(e.details)}</td></tr>`;
  }).join('');
  const note = entries.length > 200 ? `<p class="faint" style="margin-top:8px;">Showing the most recent 200 of ${entries.length} matching entries.</p>` : '';
  return `<table><thead><tr><th>When</th><th>Staff</th><th>Action</th><th>Details</th></tr></thead><tbody>${rows}</tbody></table>${note}`;
}
function auditLogView(){
  return `
    <div class="page-head">
      <div><h1>Activity log</h1><p class="muted">${(state.data.auditLog||[]).length} entries recorded</p></div>
      <button class="btn btn-ghost" onclick="go('settings')">Back to settings</button>
    </div>
    <div class="card">
      <div class="search-wrap" style="margin-bottom:14px;">
        <input type="text" placeholder="Search by staff, action or details" value="${esc(state.auditSearch||'')}" oninput="onAuditSearchInput(this.value)">
      </div>
      <div id="audit-log-container">${auditLogTableHTML()}</div>
    </div>`;
}

async function addCustomMedicine(){
  const name = document.getElementById('cm-name').value.trim();
  const dosagesRaw = document.getElementById('cm-dosages').value.trim();
  if(!name) return;
  const dosages = dosagesRaw ? dosagesRaw.split(',').map(s=>s.trim()).filter(Boolean) : [];
  if(!state.data.customMedicines) state.data.customMedicines = [];
  let entry = state.data.customMedicines.find(m=>m.name.toLowerCase()===name.toLowerCase());
  if(entry){ dosages.forEach(d=>{ if(!entry.dosages.includes(d)) entry.dosages.push(d); }); }
  else { state.data.customMedicines.push({name, dosages}); }
  logAudit('Added medicine to library', name);
  await saveData();
  render();
}
async function removeCustomMedicine(idx){
  const m = (state.data.customMedicines||[])[idx];
  if(!m) return;
  if(!confirm(`Remove "${m.name}" from your saved medicines list?`)) return;
  state.data.customMedicines.splice(idx,1);
  logAudit('Removed medicine from library', m.name);
  await saveData();
  render();
}

function connectionErrorView(){
  return `<div class="center-screen"><div class="auth-card" style="text-align:center;">
    <div class="brand-mark" style="margin:0 auto 12px auto;">MMC</div>
    <h1 style="font-size:18px;">Can't reach the clinic server</h1>
    <p class="muted" style="font-size:13px;">${esc(state.loadError)}</p>
    <button class="btn btn-primary btn-block" onclick="retryLoad()">Try again</button>
  </div></div>`;
}
function retryLoad(){ state.loading = true; render(); loadData(); }

/* ============================= ROOT RENDER ============================= */
function render(){
  resetIdleTimer();
  const app = document.getElementById('app');
  if(state.loading){ app.innerHTML = loadingView(); return; }
  if(state.loadError && !state.data){ app.innerHTML = connectionErrorView(); return; }
  if(!state.session.staffName){
    app.innerHTML = state.data.staff.length===0 ? setupView() : loginView();
    return;
  }
  app.innerHTML = shellView();
}

restoreSessionFromStorage();
loadData();
