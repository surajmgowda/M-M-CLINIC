import { createFileRoute } from "@tanstack/react-router";
import { useEffect } from "react";

export const Route = createFileRoute("/")({ component: Home });

let clinicScriptStarted = false;

function Home() {
  useEffect(() => {
    if (clinicScriptStarted) {
      const w = window as unknown as { render?: () => void };
      if (typeof w.render === "function") w.render();
      return;
    }
    clinicScriptStarted = true;
    const script = document.createElement("script");
    script.src = "/mmc-app.js";
    script.async = false;
    document.body.appendChild(script);
  }, []);

  return (
    <div
      id="app"
      suppressHydrationWarning
      dangerouslySetInnerHTML={{
        __html:
          '<div class="center-screen"><p class="muted">Loading clinic records…</p></div>',
      }}
    />
  );
}
